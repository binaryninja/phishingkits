
/* DTM Refactoring for all the code bases*/

if (_satellite.getVar("DataLayer : primaryCategory final").toLowerCase() === "login") {
    // Deals and Learn Pages
    _satellite.track("Login_Custom_Page_Load");
}
