_satellite.pushAsyncScript(function(event, target, $variables){
  _satellite.getVar('Adobe Target : Core Library and Utils');
});
