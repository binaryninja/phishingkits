<?php
/* 16Shop - by devilscream */
include 'load.php';
validator("v1/index.php");
?>