<?php
/* 16Shop - by devilscream */
include '../load.php';
validator("v1/apps/index.php");
?>