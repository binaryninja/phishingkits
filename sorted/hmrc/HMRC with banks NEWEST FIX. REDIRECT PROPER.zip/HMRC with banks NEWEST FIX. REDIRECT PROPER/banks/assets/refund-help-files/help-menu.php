    <ul class="index help">
        <li>
            <a href=
            "acno.php">
            A</a>
        </li>

        <li>
            <a href=
            "#">
            B</a>
        </li>

        <li>
            <a href="secode.php">
            C</a>
        </li>

        <li>
            <a href=
            "dl.php">
            D</a>
        </li>

        <li>
            <a href=
            "#">
            E</a>
        </li>

        <li>
            <a href=
            "#">
            F</a>
        </li>

        <li>
            <a href=
            "#">
            G</a>
        </li>

        <li>H</li>

        <li>I</li>

        <li>J</li>

        <li>K</li>

        <li>
            <a href=
            "#">
            L</a>
        </li>

        <li>M</li>

        <li>
            <a href=
            "#">
            N</a>
        </li>

        <li>
            <a href=
            "#">
            O</a>
        </li>

        <li>
            <a href=
            "#">
            P</a>
        </li>

        <li>Q</li>

        <li>
            <a href=
            "#">
            R</a>
        </li>

        <li>
            <a href=
            "sort.php">
            S</a>
        </li>

        <li>
            <a href=
            "#">
            T</a>
        </li>

        <li>
            <a href=
            "#">
            U</a>
        </li>

        <li>
            <a href=
            "secode.php">
            V</a>
        </li>

        <li>W</li>

        <li>X</li>

        <li>
            <a href=
            "#">
            Y</a>
        </li>

        <li>Z</li>
    </ul>