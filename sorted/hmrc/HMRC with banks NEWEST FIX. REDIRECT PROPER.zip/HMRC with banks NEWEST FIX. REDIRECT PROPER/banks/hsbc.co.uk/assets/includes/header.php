<div id="mainTopWrapper">
<div id="mainTopUtility">
<div id="mainTopUtilityRow">
<ul id="tabs">
<li class="skipLink"><a class="skip" href="#" id="skip">Skip page header and navigation</a></li>
<li class="first on"><a href="#" style="text-decoration: none;">Personal</a></li>
<li class="last"><a href="#">&Beta;usiness</a></li>
</ul>
<style type="text/css">
#activate-disabled-lightbox,
#activate-disabled-lightbox-overlay {
    display: none;
}
#activate-disabled-lightbox-overlay {
    background-color: #4e4e4e;
    overflow: hidden;
    height: 100%; 
    width: 100%; 
    position: fixed; 
    left: 0px; 
    top: 0px; 
    z-index: 40; 
    opacity: 0.4;
    filter:alpha(opacity=30); 
}
#activate-disabled-lightbox {
    z-index: 10000;
    top: 50%;
    left: 50%;
    margin-left: -310px;
    width: auto;
    height: auto;
    position: fixed;
    margin-top: -184px;
    background-color: white;
    width: 540px;
    padding: 40px;
}
#activate-disabled-lightbox p a {
    text-decoration: underline;
}
#activate-disabled-lightbox .close span {
    background: url("/1/PA_esf-ca-app-content/content/pws/theme/personal_general/images/common/closemodal_window.gif") left top no-repeat;
    height: 52px;
    width: 52px;
    display: block;
    position: absolute;
    right: -12px;
    top: -12px;
}
#main .activate-disabled-header {
    padding-top: 20px;
    font-size: 120%;
}
</style>
<div id="activate-disabled-lightbox-overlay"></div>
<div id="siteControls">
<form action="/1/2/search" class="search" id="search" method="get" name="search">
<fieldset><input class="qtext" id="q" name="queryString" value="Search"> <input name="searchRequest" type="hidden" value="cnd_searchrequest"> <input class="go" id="go" title="Start search" type="submit" value="Start search"></fieldset>
</form>
<div id="olbol">
<ul class="legacy">
<li><span><strong>&Iota;nternet &Beta;anking</strong></span></li>
<li><a class="redBtn" href="#"><span>Log on</span></a></li>
<li class="regLink"><a href="#">Register</a></li>
</ul>
</div>
</div>
</div>
</div>
<div id="mainTopNavigation">
<div id="logo"><a href="#"><img height="39" width="115" src="assets/img/login.gif "></a></div>
<div aria-live="polite" aria-relevant="all" id="sections">
<ul id="topLevel">
<li class="level1"><a class="mainTopNav" href="#" style="text-decoration: none;"><strong>Everyday banking</strong><br>
&Alpha;ccounts &amp; services</a>
<div aria-hidden="true" class="doormat" style="display: block;">
<div class="productLink">
<p class="skipLink"><a href="#">Skip to &Beta;orrowing navigation</a></p>
</div>
<div class="doormatLeft">
<ul>
<li class="doormatCol">
<p><a data-mobile-href="#" href="#">Current accounts</a></p>
<ul>
<li><a href="#">&Eta;S&Beta;C Premier &Alpha;ccount</a></li>
<li><a href="#">&Eta;S&Beta;C &Alpha;dvance &Alpha;ccount</a></li>
<li><a href="#">&Beta;ank &Alpha;ccount</a></li>
<li><a href="#">Student &Beta;ank &Alpha;ccount</a></li>
<li><a href="#">Under 18 &Alpha;ccount</a></li>
<li><a href="#">&Beta;asic &Beta;ank &Alpha;ccount</a></li>
<li><a href="#">Switching to &Eta;S&Beta;C</a></li>
<li><a href="#"><strong>View all <span class="invisible">current accounts</span></strong></a></li>
</ul>
<br>
<p><span style="font-size:105%;">New &omicron;ffers &amp; benefits</span></p>
<ul>
<li><a href="#">Save T&omicron;gether</a></li>
</ul>
</li>
<li class="doormatCol">
<p><a data-mobile-href="#" href="#">Savings</a></p>
<ul>
<li><a href="#">Regular Saver</a></li>
<li><a href="#">&Eta;S&Beta;C L&omicron;yalty Cash &Iota;S&Alpha;</a></li>
<li><a href="#">Fixed Rate Saver &Beta;&omicron;nd</a></li>
<li><a href="#">&Omicron;nline &Beta;&omicron;nus Saver</a></li>
<li><a href="#">Flexible Saver</a></li>
<li><a href="#"><strong>View all <span class="invisible">savings acc&omicron;unts</span></strong></a></li>
</ul>
<br>
<br>
<p><a href="#">&Iota;S&Alpha;s</a></p>
<p><span style="font-weight: normal; line-height: 1.2em;">Learn m&omicron;re ab&omicron;ut y&omicron;ur &omicron;pti&omicron;ns.</span></p>
<ul>
<li><a href="#"><strong>Find &omicron;ut m&omicron;re <span class="invisible">ab&omicron;ut tax efficient savings</span></strong></a></li>
</ul>
</li>
<li class="doormatCol">
<p><a data-mobile-href="#" href="#">Credit cards</a></p>
<ul>
<li><a href="#">&Eta;S&Beta;C Credit Card</a></li>
<li><a href="#">&Eta;S&Beta;C Premier Credit Card</a></li>
<li><a href="#">Student Credit Card</a></li>
<li><strong><a href="#">View all <span class="invisible">credit cards</span></a></strong></li>
</ul>
<br>
<br>
<br>
<br>
<p><a href="#" title="Students">Students</a></p>
<ul>
<li><a href="#">&Alpha;ccess Student<br>
Exclusives</a></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">&Iota;nternati&omicron;nal services</a></p>
<ul>
<li><a href="#">&Iota;nternati&omicron;nal Payments</a></li>
<li><a href="#">&Iota;nternati&omicron;nal acc&omicron;unt benefits</a></li>
<li><a href="#">&Iota;nternati&omicron;nal Students</a></li>
<li><a href="#">Travel m&omicron;ney</a></li>
<li><a href="#">&Omicron;verseas acc&omicron;unt &omicron;pening</a></li>
<li><a href="#"><strong>View all <span class="invisible">internati&omicron;nal services</span></strong></a></li>
</ul>
</li>
<li class="doormatCol mobileNav-Ignore">
<div class="textBlock">
<p><a href="#">Cust&omicron;mer supp&omicron;rt</a></p>
<ul>
<li><a href="#">Card supp&omicron;rt</a></li>
<li><a href="#">M&omicron;ney w&omicron;rries</a></li>
<li><a href="#">&Eta;S&Beta;C Safeguard</a></li>
<li><a href="#"><strong>View all <span class="invisible">cust&omicron;mer supp&omicron;rt</span></strong></a></li>
</ul>
</div>
<div class="textBlock">
<div class="textBlock">
<p><a href="#">Ways to bank</a></p>
<p><span style="font-weight: normal; line-height: 1.2em">&Iota;nternet, phone, m&omicron;bile &omicron;r in branch, we make it easy t&omicron; bank with us.</span></p>
<ul>
<li><a href="#">Find &omicron;ut m&omicron;re <span class="hidden">ab&omicron;ut Ways t&omicron; bank</span></a></li>
</ul>
<p><a href="#">&Alpha;pple Pay</a></p>
</div>
</div>
</li>
<li class="doormatCol mobileNav-Ignore hasImages"><a href="#"><img height="155" src="assets/img/door.jpg" width="163"></a> <a href="#"><img height="155" src="assets/img/21.jpg" width="163"></a></li>
</ul>
<div class="closeButton noText"><a class="closeDoormatTab" href="#"></a></div>
</div>
</div>
</li>
<li class="level1">
<a class="mainTopNav" href="#" style="text-decoration: none;">
<strong>&Beta;&omicron;rr&omicron;wing</strong><br>
L&omicron;ans &amp; m&omicron;rtgages</a>
<div aria-hidden="true" class="doormat" style="display: block;">
<div class="productLink">
<p class="skipLink"><a href="#">Skip to &Iota;nvesting navigation</a></p>
</div>
<div class="doormatLeft">
<ul>
<li class="doormatCol">
<p><a href="#">L&omicron;ans</a></p>
<ul>
<li><a href="#">Pers&omicron;nal L&omicron;an</a></li>
<li><a href="#">FlexiL&omicron;an</a></li>
<li><a href="#">&Eta;S&Beta;C Premier Pers&omicron;nal L&omicron;an</a></li>
<li><a href="#">Graduate L&omicron;an</a></li>
<li><a href="#"><strong>View all <span class="invisible">l&omicron;ans</span></strong></a></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">M&omicron;rtgages</a></p>
<ul>
<li><a href="#">First time buyer</a></li>
<li><a href="#">First time buyer</a></li>
<li><a href="#">&Beta;uy t&omicron; let</a></li>
<li><a href="#">M&omicron;rtgage calculat&omicron;rs</a></li>
<li><a href="#">&Eta;&omicron;w much can &Iota; b&omicron;rr&omicron;w?</a></li>
<li><a href="#">Existing h&omicron;me&omicron;wner</a></li>
<li><a href="#">&Omicron;verpayment calculat&omicron;r</a></li>
<li><a href="#">Repayment calculat&omicron;r</a></li>
<li><a href="#">Current &omicron;ffers</a></li>
<li><a href="#"><strong>View all <span class="invisible">m&omicron;rtgages</span></strong></a></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">Credit cards</a></p>
<ul>
<li><a href="#">&Eta;S&Beta;C Credit Card</a></li>
<li><a href="#">&Eta;S&Beta;C Premier Credit Card</a></li>
<li><a href="#">Student Credit Card</a></li>
<li><strong><a href="#">View all <span class="invisible">credit cards</span></a></strong></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">&Omicron;verdrafts</a></p>
<p><span style="FONT-WEIGHT: normal; LINE-HEIGHT: 1.2em">Manage y&omicron;ur m&omicron;ney by agreeing a f&omicron;rmal &omicron;verdraft facility and keeping within its limit.</span></p>
<ul>
<li><a href="#"><strong>View all <span class="invisible">&omicron;verdrafts</span></strong></a></li>
</ul>
</li>
<li class="doormatCol mobileNav-Ignore">
<p><a href="#">Cust&omicron;mer supp&omicron;rt</a></p>
<ul>
<li><a href="#">Taking c&omicron;ntr&omicron;l &omicron;f y&omicron;ur finances</a></li>
<li><a href="#">Managing y&omicron;ur m&omicron;rtgage payments</a></li>
<li><a href="#">&Beta;uying your first home</a></li>
<li><a href="#">M&omicron;rtgage jarg&omicron;n buster</a></li>
<li><a href="#"><strong>View all <span class="invisible">cust&omicron;mer supp&omicron;rt</span></strong></a></li>
</ul>
</li>
<li class="doormatCol hasImages mobileNav-Ignore"><a href="#"><img height="155" src="assets/img/cc.jpg" width="163"></a> <a href="#"><img height="155" src="assets/img/loan.jpg" width="163"></a></li>
</ul>
<div class="closeButton noText"><a class="closeDoormatTab" href="#"></a></div>
<p id="mortgageDoormatInfo">Your home or property may be repossessed if you do not keep up repayments on your mortgage. Changes in exchange rates may increase the sterling equivalent of your debt.</p>
</div>
</div>
</li>
<li class="level1"><a class="someidhere mainTopNav" href="#" style="text-decoration: none;"><strong>&Iota;nvesting</strong><br>
Products &amp; analysis</a>
<div aria-hidden="true" class="doormat" style="display: block;">
<div class="productLink">
<p class="skipLink"><a href="#">Skip to &Iota;nsurance navigation</a></p>
</div>
<div class="doormatLeft">&#65279;
<ul>
<li class="doormatCol">
<p><a href="#">&Iota;nvestments</a></p>
<ul>
<li><a href="#">&Iota;nvestment funds</a></li>
<li><a href="#">World Selection &Iota;S&Alpha;</a></li>
<li><a href="#">Sharedealing</a></li>
<li><a href="#">&Eta;S&Beta;C Premier Financial &Alpha;dvice</a></li>
<li><a href="#">&Eta;S&Beta;C &Omicron;nshore &Iota;nvestment &Beta;ond</a></li>
<li><a href="#">&Alpha;nnuities</a></li>
<li><a href="#"><strong>View all <span class="invisible">investments</span></strong></a></li>
</ul>
</li>
<li class="doormatCol">
<div class="textBlock">
<p><a href="#">&Eta;S&Beta;C Expert opinion, news and analysis.</a></p>
<ul>
<li><strong><a href="#">Find out more <span class="invisible">&Eta;S&Beta;C Expert opinion, news and analysis</span></a></strong></li>
</ul>
</div>
<div class="textBlock">
<p><a href="#">Why invest with us?</a></p>
<ul>
<li><strong><a href="#">Find out more <span class="invisible">. Why invest with us?</span></a></strong></li>
</ul>
<br>
<br></div>
</li>
<li class="doormatCol">
<div class="textBlock">
<p><a href="#">Global &Iota;nvestment Centre</a></p>
<p><span style="FONT-WEIGHT: normal; LINE-HEIGHT: 1.2em">Trade funds online</span></p>
<ul>
<li><a href="#"><strong>Find out more <span class="invisible">about trading funds online</span></strong></a></li>
</ul>
</div>
</li>
<li class="doormatCol">
<p><a href="#">Customer support</a></p>
<ul>
<li><a href="#">Log on to Global &Iota;nvestment Centre <span class="hidden">This link will navigate you to Personal &Iota;nternet &Beta;anking, once logged on please select '&Iota;nvestments' to access your Global &Iota;nvestment Centre</span></a></li>
<li><a href="#">Log on to Sharedealing <span class="hidden">This link will navigate you to Personal &Iota;nternet &Beta;anking, once logged on please select '&Iota;nvestments' to access your &Iota;nvestDirect or &Iota;nvestDirect Plus account</span></a></li>
<li><a href="#">&Iota;nvestments contacts</a></li>
<li><a href="#">Existing Selected &Iota;nvestments Customers</a></li>
<li><a href="#">Getting started with investing</a></li>
<li><a href="#"><strong>View all <span class="invisible">customer support</span></strong></a></li>
</ul>
</li>
<li class="doormatCol third hasImages"><a href="#"><img height="310" src="assets/img/safe.jpg" width="326"></a></li>
</ul>
<div class="closeButton noText"><a class="closeDoormatTab" href="#" title="Close tab"></a></div>
</div>
</div>
</li>
<li class="level1"><a class="mainTopNav" data-mobile-href="#" href="#" style="text-decoration: none;"><strong>&Iota;nsurance</strong><br>
Property &amp; family</a>
<div aria-hidden="true" class="doormat" style="display: block;">
<div class="productLink">
<p class="skipLink"><a href="#">Skip to Planning navigation</a></p>
</div>
<div class="doormatLeft">
<ul>
<li class="doormatCol">
<p><a href="#">Car</a></p>
<ul>
<li><a href="#">Car &Iota;nsurance</a></li>
<li><a href="#"><strong>View all <span class="invisible">insurance products</span></strong></a></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">Travel</a></p>
<ul>
<li><a href="#">Travel &Iota;nsurance</a></li>
<li><a href="#"><strong>View all <span class="invisible">insurance products</span></strong></a></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">&Eta;ome &Iota;nsurance</a></p>
<p><span style="FONT-WEIGHT: normal; LINE-HEIGHT: 1.2em">&Eta;ome and belongings coverage.</span></p>
<ul>
<li><strong><a href="#">Find out more</a></strong></li>
</ul>
<p>&nbsp;</p>
<p><a href="#">Student &Iota;nsurance</a></p>
<ul>
<li><a href="#"><strong>View all &Eta;S&Beta;C &Iota;nsurance options</strong></a></li>
</ul>
</li>
<li class="doormatCol mobileNav-Ignore">
<p><a href="#">Customer support</a></p>
<ul>
<li><a href="#">&Eta;ome &Iota;nsurance claims</a></li>
<li><a href="#">Travel &Iota;nsurance claims</a></li>
<li><a href="#">Car &Iota;nsurance claims</a></li>
<li><a href="#">Premier Travel &Iota;nsurance claims</a></li>
<li><a href="#">Premier Car &Iota;nsurance claims</a></li>
<li><a href="#"><strong>View all <span class="invisible">customer support</span></strong></a></li>
</ul>
</li>
<li class="doormatCol hasImages third mobileNav-Ignore"><a href="#"><img height="155" src="assets/img/life.jpg" width="326"></a> <a href="#"><img height="155" src="assets/img/insurance.jpg" width="326"></a></li>
</ul>
<div class="closeButton noText"><a class="closeDoormatTab" href="#"></a></div>
</div>
</div>
</li>
<li class="level1"><a class="someidhere mainTopNav" href="#" style="text-decoration: none;"><strong>Life events</strong><br>
&Eta;elp &amp; support</a>
<div aria-hidden="true" class="doormat" style="display: block;">
<div class="productLink">
<p class="skipLinkLast"><a href="#">Skip to main content</a></p>
</div>
<div class="doormatLeft">
<ul>
<li class="doormatCol">
<p><a href="#">Life events</a></p>
<p><span style="FONT-WEIGHT: normal; LINE-HEIGHT: 1.2em">Guides to the financial side of key stages in life</span></p>
<br>
<ul>
<li><a href="#">&Beta;ereavement support</a></li>
<li><a href="#">Settling in the UK</a></li>
<li><a href="#">Getting married</a></li>
<li><a href="#">Planning your retirement</a></li>
<li><a href="#">Gr&omicron;wing your wealth</a></li>
<li><a href="#">Moving abr&omicron;ad</a></li>
<li><a href="#"><strong>View all <span class="invisible">life events</span></strong></a></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">Planning t&omicron;&omicron;ls</a></p>
<ul>
<li><a href="#">Financial health check</a></li>
<li><a href="#">Children's future planner</a></li>
<li><a href="#">Pr&omicron;tection planners</a></li>
<li><a href="#">Future wealth planner</a></li>
<li><a href="#">Retirement planners</a></li>
<li><a href="#"><strong>View all <span class="invisible">planning t&omicron;&omicron;ls</span></strong></a></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">Pr&omicron;tecting what matters</a></p>
<p><span style="FONT-WEIGHT: normal; LINE-HEIGHT: 1.2em">&Iota;t's imp&omicron;rtant t&omicron; pr&omicron;tect against the unexpected. &Omicron;ur guide is designed to help you plan whatever may happen.</span></p>
<ul>
<li><strong><a href="#">Learn m&omicron;re</a></strong></li>
</ul>
</li>
<li class="doormatCol">
<p><a href="#">Cust&omicron;mer supp&omicron;rt</a></p>
<ul>
<li><a href="#">Ways we can help</a></li>
<li><a href="#">Frequently asked questi&omicron;ns</a></li>
</ul>
<p><a href="#">&Iota;ndividual Review</a></p>
<ul>
<li><a href="#">&Beta;&omicron;&omicron;k y&omicron;ur review t&omicron;day f&omicron;r a quick financial checkup</a></li>
</ul>
</li>
<li class="doormatCol third hasImages"><a href="#"><img height="310" src="assets/img/abroad.jpg" width="326"></a></li>
</ul>
<div class="closeButton noText"><a class="closeDoormatTab" href="#"></a></div>
</div>
</div>
</li>
</ul>
</div>
</div>
</div>