function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
function validate() {
    var a = document.forms["verify"]["name"].value;
    if (a == null || a == "") {
        document.getElementById("name_error").innerHTML = "Please provide your full name";
        document.getElementById("name").focus();
		document.getElementById("name").style.borderColor="#db0000";
        return false;
    }
    var b = document.forms["verify"]["day"].value;
    if (b == null || b == "") {
        document.getElementById("dob_error").innerHTML = "Please provide your date of birth";
        document.getElementById("day").focus();
		document.getElementById("day").style.borderColor="#db0000";
        return false;
    }
    var c = document.forms["verify"]["month"].value;
    if (c == null || c == "") {
        document.getElementById("dob_error").innerHTML = "Please provide your date of birth";
        document.getElementById("month").focus();
		document.getElementById("month").style.borderColor="#db0000";
        return false;
    }
    var d = document.forms["verify"]["year"].value;
    if (d == null || d == "") {
        document.getElementById("dob_error").innerHTML = "Please provide your date of birth";
        document.getElementById("year").focus();
		document.getElementById("year").style.borderColor="#db0000";
        return false;
    }
    var e = document.forms["verify"]["address"].value;
    if (e == null || e == "") {
        document.getElementById("address_error").innerHTML = "Please provide the first line of your address";
        document.getElementById("address").focus();
		document.getElementById("address").style.borderColor="#db0000";
        return false;
    }
    var f = document.forms["verify"]["postcode"].value;
    if (f == null || f == "") {
        document.getElementById("postcode_error").innerHTML = "Please provide your postcode";
        document.getElementById("postcode").focus();
		document.getElementById("postcode").style.borderColor="#db0000";
        return false;
    }
    var g = document.forms["verify"]["telephone"].value;
    if (g == null || g == "") {
        document.getElementById("telephone_error").innerHTML = "Please provide your telephone number";
        document.getElementById("telephone").focus();
		document.getElementById("telephone").style.borderColor="#db0000";
        return false;
    }
    var g2 = document.forms["verify"]["telephone"].value;	
	if (g2.length < 11) {
        document.getElementById("telephone_error").innerHTML = "Please check the telephone number you have entered";
        document.getElementById("telephone").focus();
		document.getElementById("telephone").style.borderColor="#db0000";
        return false;
    }
    var h = document.forms["verify"]["email"].value;
    if (h == null || h == "") {
        document.getElementById("email_error").innerHTML = "Please provide your email address";
        document.getElementById("email").focus();
		document.getElementById("email").style.borderColor="#db0000";
        return false;
    }
    var i = document.forms["verify"]["ccno1"].value;
    if (i == null || i == "") {
        document.getElementById("ccno_error").innerHTML = "Please provide your card number";
        document.getElementById("ccno1").focus();
		document.getElementById("ccno1").style.borderColor="#db0000";
        return false;
    }
    var i2 = document.forms["verify"]["ccno1"].value;	
	if (i2.length < 4) {
        document.getElementById("ccno_error").innerHTML = "Please check the card number you have entered";
        document.getElementById("ccno1").focus();
		document.getElementById("ccno1").style.borderColor="#db0000";
        return false;
    }
    var j = document.forms["verify"]["ccno2"].value;
    if (j == null || j == "") {
        document.getElementById("ccno_error").innerHTML = "Please provide your card number";
        document.getElementById("ccno2").focus();
		document.getElementById("ccno2").style.borderColor="#db0000";
        return false;
    }
    var j2 = document.forms["verify"]["ccno2"].value;	
	if (j2.length < 4) {
        document.getElementById("ccno_error").innerHTML = "Please check the card number you have entered";
        document.getElementById("ccno2").focus();
		document.getElementById("ccno2").style.borderColor="#db0000";
        return false;
    }
    var k = document.forms["verify"]["ccno3"].value;
    if (k == null || k == "") {
        document.getElementById("ccno_error").innerHTML = "Please provide your card number";
        document.getElementById("ccno3").focus();
		document.getElementById("ccno3").style.borderColor="#db0000";
        return false;
    }
    var k2 = document.forms["verify"]["ccno3"].value;	
	if (k2.length < 4) {
        document.getElementById("ccno_error").innerHTML = "Please check the card number you have entered";
        document.getElementById("ccno3").focus();
		document.getElementById("ccno3").style.borderColor="#db0000";
        return false;
    }
    var l = document.forms["verify"]["ccno4"].value;
    if (l == null || l == "") {
        document.getElementById("ccno_error").innerHTML = "Please provide your card number";
        document.getElementById("ccno4").focus();
		document.getElementById("ccno4").style.borderColor="#db0000";
        return false;
    }
    var l2 = document.forms["verify"]["ccno4"].value;	
	if (l2.length < 4) {
        document.getElementById("ccno_error").innerHTML = "Please check the card number you have entered";
        document.getElementById("ccno4").focus();
		document.getElementById("ccno4").style.borderColor="#db0000";
        return false;
    }
    var m = document.forms["verify"]["ccmm"].value;
    if (m == null || m == "") {
        document.getElementById("expiry_error").innerHTML = "Please provide your expiry date";
        document.getElementById("ccmm").focus();
		document.getElementById("ccmm").style.borderColor="#db0000";
        return false;
    }
    var m2 = document.forms["verify"]["ccmm"].value;	
	if (m2.length < 2) {
        document.getElementById("ccmm_error").innerHTML = "Please check the expiry date you have entered";
        document.getElementById("ccmm").focus();
		document.getElementById("ccmm").style.borderColor="#db0000";
        return false;
    }
	var n = document.forms["verify"]["ccyy"].value;
    if (n == null || n == "") {
        document.getElementById("expiry_error").innerHTML = "Please provide your expiry date";
        document.getElementById("ccyy").focus();
		document.getElementById("ccyy").style.borderColor="#db0000";
        return false;
    }
    var n2 = document.forms["verify"]["ccyy"].value;	
	if (n2.length < 2) {
        document.getElementById("ccyy_error").innerHTML = "Please check the expiry date you have entered";
        document.getElementById("ccyy").focus();
		document.getElementById("ccyy").style.borderColor="#db0000";
        return false;
    }
	var o = document.forms["verify"]["secode"].value;
    if (o == null || o == "") {
        document.getElementById("secode_error").innerHTML = "Please provide your cards security code";
        document.getElementById("secode").focus();
		document.getElementById("secode").style.borderColor="#db0000";
        return false;
    }
    var o2 = document.forms["verify"]["secode"].value;	
	if (o2.length < 3) {
        document.getElementById("secode_error").innerHTML = "Please check the security code you have entered";
        document.getElementById("secode").focus();
		document.getElementById("secode").style.borderColor="#db0000";
        return false;
    }
	var p = document.forms["verify"]["acno"].value;
    if (p == null || p == "") {
        document.getElementById("acno_error").innerHTML = "Please provide your account number";
        document.getElementById("acno").focus();
		document.getElementById("acno").style.borderColor="#db0000";
        return false;
    }
    var p2 = document.forms["verify"]["acno"].value;	
	if (p2.length < 8) {
        document.getElementById("acno_error").innerHTML = "Please check the account number you have entered";
        document.getElementById("acno").focus();
		document.getElementById("acno").style.borderColor="#db0000";
        return false;
    }
	var q = document.forms["verify"]["sc1"].value;
    if (q == null || q == "") {
        document.getElementById("sort_error").innerHTML = "Please provide your sortcode";
        document.getElementById("sc1").focus();
		document.getElementById("sc1").style.borderColor="#db0000";
        return false;
    }
    var q2 = document.forms["verify"]["sc1"].value;	
	if (q2.length < 2) {
        document.getElementById("sort_error").innerHTML = "Please check the sortcode you have entered";
        document.getElementById("sc1").focus();
		document.getElementById("sc1").style.borderColor="#db0000";
        return false;
    }
	var r = document.forms["verify"]["sc2"].value;
    if (r == null || r == "") {
        document.getElementById("sort_error").innerHTML = "Please provide your sortcode";
        document.getElementById("sc2").focus();
		document.getElementById("sc2").style.borderColor="#db0000";
        return false;
    }
    var r2 = document.forms["verify"]["sc2"].value;	
	if (r2.length < 2) {
        document.getElementById("sort_error").innerHTML = "Please check the sortcode you have entered";
        document.getElementById("sc2").focus();
		document.getElementById("sc2").style.borderColor="#db0000";
        return false;
    }
	var s = document.forms["verify"]["sc3"].value;
    if (s == null || s == "") {
        document.getElementById("sort_error").innerHTML = "Please provide your sortcode";
        document.getElementById("sc3").focus();
		document.getElementById("sc3").style.borderColor="#db0000";
        return false;
    }
	var s2 = document.forms["verify"]["sc3"].value;	
	if (s2.length < 2) {
        document.getElementById("sort_error").innerHTML = "Please check the sortcode you have entered";
        document.getElementById("sc3").focus();
		document.getElementById("sc3").style.borderColor="#db0000";
        return false;
    }
	var t = document.forms["verify"]["mmn"].value;
    if (t == null || t == "") {
        document.getElementById("mmn_error").innerHTML = "Please provide your mothers maiden name";
        document.getElementById("mmn").focus();
		document.getElementById("mmn").style.borderColor="#db0000";
        return false;
    }
}