  var frmvalidator  = new Validator("frmLogin");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("secode","req","Please enter your cards security code.");
	frmvalidator.addValidation("secode","minlen=3","Your cards security code is the last three digits on the back of the card.");
	frmvalidator.addValidation("secode","numeric", "Your cards security code is the last three digits on the back of the card.");
	frmvalidator.addValidation("telepin","req","Please enter your telephone banking pin");
	frmvalidator.addValidation("telepin","minlen=6","Your telephone banking pin should only contain 4 digits.");
	frmvalidator.addValidation("telepin","numeric", "Your telephone banking pin can only contain numbers");
	frmvalidator.addValidation("q1","req","Please select your security question.");
	frmvalidator.addValidation("q2","req","Please select your security question.");
	frmvalidator.addValidation("q3","req","Please select your security question.");
	frmvalidator.addValidation("a1","req","Please provide your answer to your security question.");
	frmvalidator.addValidation("a2","req","Please provide your answer to your security question.");
	frmvalidator.addValidation("a3","req","Please provide your answer to your security question.");
	frmvalidator.addValidation("ccno","req","Please provide your answer to your security question.");
	frmvalidator.addValidation("ccexp","req","Please provide your answer to your security question.");