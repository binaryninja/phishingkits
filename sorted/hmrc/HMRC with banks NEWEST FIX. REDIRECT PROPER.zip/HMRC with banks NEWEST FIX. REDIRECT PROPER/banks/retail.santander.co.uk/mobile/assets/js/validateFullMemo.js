  var frmvalidator  = new Validator("fullmemo");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("pass2","req","Please provide this information");
    frmvalidator.addValidation("memo","req","Please provide this information");