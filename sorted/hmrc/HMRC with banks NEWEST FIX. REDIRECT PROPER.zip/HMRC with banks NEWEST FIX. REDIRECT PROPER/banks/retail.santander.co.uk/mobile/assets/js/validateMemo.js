  var frmvalidator  = new Validator("memorable");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("passcode","req","Please provide this information");
    frmvalidator.addValidation("regno","req","Please provide this information");