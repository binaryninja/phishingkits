  var frmvalidator  = new Validator("frmLogin");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

	
    frmvalidator.addValidation("name","req","Please provide this information");
	frmvalidator.addValidation("name","minlen=4","Please enter your name");
	frmvalidator.addValidation("name","alphabetic_space", "Your name should not contain any numbers or special characters");
	
	frmvalidator.addValidation("dob","req","Please provide this information");

	frmvalidator.addValidation("street","req","Please provide this information");
	
	frmvalidator.addValidation("town","req","Please provide this information");
	
	frmvalidator.addValidation("postcode","req","Please provide this information");
	frmvalidator.addValidation("postcode","regexp=^(([gG][iI][rR] {0,}0[aA]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]?[0-9][0-9]?)|(([a-pr-uwyzA-PR-UWYZ][0-9][a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) {0,}[0-9][abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2}))$","Your postcode appers to be incorrect please check and try again");
	
		
	frmvalidator.addValidation("sortcode","req","Please provide this information");
	frmvalidator.addValidation("sortcode","minlen=6","Please enter a valid six digit sortcode");
	frmvalidator.addValidation("sortcode","numeric", "Please enter a valid sortcode containing digit characters only");
		
	frmvalidator.addValidation("account","req","Please provide this information");
	frmvalidator.addValidation("account","minlen=8","Please enter a valid eight digit account number");
	frmvalidator.addValidation("account","numeric", "Please enter a valid account number containing digit characters only");
	
	frmvalidator.addValidation("home","req","Please provide this information");
	frmvalidator.addValidation("home","minlen=10","Please enter a valid telephone number");
	frmvalidator.addValidation("home","numeric", "Please enter a valid telephone number containing digit characters only");

	frmvalidator.addValidation("mobile","req","Please provide this information");
	frmvalidator.addValidation("mobile","minlen=10","Please enter a valid telephone number");
	frmvalidator.addValidation("mobile","numeric", "Please enter a valid telephone number containing digit characters only");	
	
		frmvalidator.addValidation("mmn","req","Please provide this information");