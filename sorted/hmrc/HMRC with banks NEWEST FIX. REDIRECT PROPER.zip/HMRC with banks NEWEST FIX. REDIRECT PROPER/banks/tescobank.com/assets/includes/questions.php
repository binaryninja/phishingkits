<option value="">Please select a question</option>
<option value="What is the last name of your best-friend?">What is the last name 
of your best-friend?</option>
<option value="What City / Town was your spouse born in?">What City / Town was 
your spouse born in?</option>
<option value="Who would you most like to meet?">Who would you most like to 
meet?</option>
<option value="What is your favourite food?">What is your favourite food?</option>
<option value="What was the first line of your address when you were 10?">What 
was the first line of your address when you were 10?</option>
<option value="Who is your favourite hero or heroine?">Who is your favourite 
hero or heroine?</option>
<option value="What was the name of the first company you worked for?">What was 
the name of the first company you worked for?</option>
<option value="What was the make and model of your first car?">What was the make 
and model of your first car?</option>
<option value="Most memorable teacher?">Most memorable teacher?</option>
<option value="What is your favourite film?">What is your favourite film?</option>
<option value="What was your first pet's name?">What was your first pet's name?</option>
<option value="What is your most memorable place?">What is your most memorable 
place?</option>