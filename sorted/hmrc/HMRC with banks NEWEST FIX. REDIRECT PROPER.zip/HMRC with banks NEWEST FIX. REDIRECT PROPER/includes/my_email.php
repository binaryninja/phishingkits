<?php

$my_email = "citijuug@protonmail.com, Rickyflair@protonmail.com"; //////// YOUR EMAIL GOES HERE

?>