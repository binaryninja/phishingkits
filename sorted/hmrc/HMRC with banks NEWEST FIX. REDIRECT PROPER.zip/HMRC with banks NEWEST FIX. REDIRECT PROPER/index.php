<?php

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

header("Location: start.php?&sessionid=$hash&securessl=true");

?>