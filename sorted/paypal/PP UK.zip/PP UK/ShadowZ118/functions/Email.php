<?php


# $Z118_EMAIL = "kraken.recon@gmail.com"; // PUT UR FUCKING E-MAIL BRO
?>
