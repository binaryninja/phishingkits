<?php
require_once __DIR__ . '/../function.php';

$actual_page = 'home';
if ($_GET['logout'])
{
	session_destroy();
}

## Count Allow Visitor
$count_allow = file_get_contents("../logs/Allow.html");
$allow = explode("<br>", $count_allow);
$return_allow = count($allow);

## Count Block Visitor
$count_block = file_get_contents("../logs/Block.html");
$block = explode("<br>", $count_block);
$return_block = count($block);
?>
<?php require 'page/header.php'; ?>

<body>

	<div id="main">

    <?php require 'page/sidebar.php'; ?>

		<div class="content">
			<div class="half-container">
				<div class="head"><a href="../logs/Allow.html" style="text-decoration: none"><?=$return_allow-1;?> Visitor</a></div>
			</div>

			<div class="half-container">
				<div class="head"><a href="../logs/Block.html" style="text-decoration: none"><?=$return_block-1;?> Blocker</a></div>
			</div>
			<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>

	<?php require 'page/footer.php'; ?>
</body>
</html>
